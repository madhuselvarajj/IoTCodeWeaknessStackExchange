#define CLK 2 // to MM5451 pin 21
#define DATA  3 // to MM5451 pin 22

void setup() 
{
    pinMode(CLK, OUTPUT);
    pinMode(DATA, OUTPUT);
    digitalWrite(CLK, 0);
    digitalWrite(DATA, 0); 
    Serial.begin(1200);
}

// the loop routine runs over and over again forever:
void loop() 
{
    for( byte led=0; led<35; led++ )
    {

        lightLed(led);


        delay(1000);    
    }
}

void lightLed(byte index)
{
    //always send a one first
    sendOne();
    // turn off all leds preceding index
    for( byte i=0; i<index; i++ )
        sendZero();
    // one led on
    sendOne();
    // pad with leds off
    for( byte i=index+1; i<35; i++ )
        sendZero();
}

void sendOne()
{
    digitalWrite(DATA, HIGH);
    digitalWrite(CLK, HIGH);
    digitalWrite(CLK, LOW);
}
void sendZero()
{
    digitalWrite(DATA, LOW);
    digitalWrite(CLK, HIGH);
    digitalWrite(CLK, LOW);
}
