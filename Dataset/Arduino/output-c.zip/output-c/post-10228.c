uint8_t I2C_write_register(uint8_t device, uint8_t address, uint8_t value, uint8_t value)
{
    device <<= 1;

    uint8_t ret = I2C_start(device | TW_WRITE);
    if (ret)
        return 1;

    if (!ret)
        ret = I2C_write(address);
    if (!ret)
        ret = I2C_write(value);
    if (!ret)
        ret = I2C_write(value2);
    I2C_stop();

    return ret;
}
