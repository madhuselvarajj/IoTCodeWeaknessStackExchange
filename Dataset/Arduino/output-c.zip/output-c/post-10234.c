if(reading < 1023/4){
    //Action 1
}else if(reading < (1023/4)*2){
    //Action 2
}else if(reading < (1023/4)*3){
    //Action 3
}else{
    //Action 4
}
