const int ledPin2=2;
const int ledPin3=3;
const int ledPin4=4;
int serialVal;

void setup()
{

  pinMode(ledPin2, OUTPUT);
  pinMode(ledPin3, OUTPUT);
  pinMode(ledPin4, OUTPUT);

 Serial.begin(9600);
}

void loop() 
{
  // If data is available, then read it!
  if (serial.available() > 0) 
  {
      serialVal = serial.read()-'0';
  }

  // If serial val is 1, turn on LEd4, turn off Led3
  if (serialVal == '1')
  {
      digitalWrite(ledPin3, LOW);
      digitalWrite(ledPin4,HIGH); 
  }

  // If serial val is 0, 
  // turn on LED2. Turn off Led3
  // delay for 100ms
  // turn of LED2, turn on LED3
  // delay for 100 ms
  if (serialVal == '0')
  {
      digitalWrite(ledPin4,LOW);   
      digitalWrite(ledPin2, HIGH);
      digitalWrite(ledPin3, LOW);

      delay(100);

      digitalWrite(ledPin3, HIGH);
      digitalWrite(ledPin2, LOW);

      delay(100);
  }

}
