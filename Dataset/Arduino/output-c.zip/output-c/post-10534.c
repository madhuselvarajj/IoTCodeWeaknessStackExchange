// CLAP switch using an electret microphone
// switches ie. a relais or led with a certain
// clap-melody

// sound parameters
const int THRESHOLD = 20;
const int VAL_MEAN = 507;

// trigger characteristics
const int CLAPS_TO_TRIGGER = 2; // number of claps
const int DEBOUNCE_TIME = 150; // ms to ignore double-clapping
const int SILENCE_T = 40; // ms between claps, otherwise reset
const int MELODY_INTERVAL = 800; // ms max time for the claps
const int PAUSE_TIME = 2000; // wait after switch, or noise

// pin-layout
const int analogPin = 0;
const int OUTPUT_PIN = 13;


int output_state = LOW;
uint32_t pause_t = 0;
uint32_t debounce_t = 0;
uint32_t start_time = 0; // timestamp of first clap-start
uint8_t claps = 0;
int sensorVal = 0;
int amp = 0;


void setup() {
  Serial.begin(115200);
  pinMode(OUTPUT_PIN,OUTPUT);
}


void loop() {
  sensorVal = analogRead(analogPin);
  amp = abs(sensorVal-VAL_MEAN);

  // Serial.print(F("sensed: ")); Serial.println(sensorVal);
  // Serial.print(F("amp: ")); Serial.println(amp);

  // at the end of an interval check the number of claps
  if (millis()-start_time > MELODY_INTERVAL & claps != 0) {
    if (claps == CLAPS_TO_TRIGGER & millis()-pause_t > PAUSE_TIME) {
      output_state = !output_state;
      pause_t = millis();
      digitalWrite(OUTPUT_PIN,output_state);
      Serial.print(F("Triggered "));
      Serial.println(output_state);
    }
    if (claps>CLAPS_TO_TRIGGER) { Serial.print(F("- too many")); }
    reset();
  }

  // noise/clap detected
  if (amp > THRESHOLD &\
      millis()-debounce_t > DEBOUNCE_TIME &\
      millis()-pause_t > PAUSE_TIME) {
    // there has to be silence between claps
    if (millis()-debounce_t < SILENCE_T+DEBOUNCE_TIME) {
      claps = 0;
      debounce_t = millis();
      Serial.print(F("reset - silence interrupted"));
      Serial.print(F(" amp "));Serial.println(amp);
    } else {
      claps++;
      debounce_t = millis();
      Serial.print(F("claps "));Serial.print(claps);
      Serial.print(F(" amp "));Serial.println(amp);
      if (claps == 1) { start_time = debounce_t; }
    }
  }
  delay(1);
}


void reset() {
  // time has expired
  start_time = 0;
  claps = 0;
  debounce_t = 0;
  Serial.println(F("reset"));
}
