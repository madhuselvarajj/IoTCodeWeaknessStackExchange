String sourceCoords = "12,47,292,85";
int x1 = sourceCoords.chomp(",").toInt();
int y1 = sourceCoords.chomp(",").toInt();
int x2 = sourceCoords.chomp(",").toInt();
int y2 = sourceCoords.chomp(",").toInt();
