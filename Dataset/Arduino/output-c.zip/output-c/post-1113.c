#include <Process.h>
#define MIN 0
#define MAX 100

int i;

void setup() {
  i = MIN;

  // Initialize Bridge
  Bridge.begin();

  // Initialize Serial
  Serial.begin(9600);

  // Wait until a Serial Monitor is connected.
  while (!Serial);
  Serial.println("Ready");

  // run various example processes

}

void loop() {
   if (i<=MAX) {
     runCurl();  
     i = i+1; 
   }
   delay(10000);
}

void runCurl() {
  // Launch "curl" command and get Arduino ascii art logo from the network
  // curl is command line program for transferring data using different internet protocols
  Process p;        // Create a process and call it "p"
  p.begin("curl");  // Process that launch the "curl" command
  String myUrl = "student.cs.hioa.no/~s180343/updatedb.php?verdi=";
  p.addParameter(myUrl+i); // Add the URL parameter to "curl"
  p.run();      // Run the process and wait for its termination

  // A process output can be read with the stream methods
  while (p.available()>0) {
    char c = p.read();
    Serial.print(c);
  }
  // Ensure the last bit of data is sent.
  Serial.flush();
}
