if (!Esplora.readButton(SWITCH_3)) {
  Keyboard.press(KEY_PAGE_UP)
  delay(100);
  Keyboard.releaseAll();
  }
