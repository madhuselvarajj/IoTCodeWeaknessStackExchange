#define F_CPU   16000000UL
#include <avr/delay.h>
#include <avr/io.h>
#include <string.h>
#include <avr/interrupt.h>
#include <LiquidCrystal.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);


const short buttonPin = 5;
volatile unsigned char seconds;
volatile unsigned char minutes;
volatile unsigned char hours;
void update_clock()
{
    seconds++;
    if (seconds == 60)
    {
        seconds = 0;
        minutes++;
    }
    if(minutes==60)
    {
      minutes=0;
      hours++;
    }
    if(hours>23)
    {
      hours=0;
    }


}

ISR(TIMER1_COMPA_vect)
{

  update_clock(); 

}

void setup() 
{                



  // initialize Timer1
  pinMode(A5, INPUT_PULLUP);
  cli();          // disable global interrupts
  TCCR1A = 0;     // set entire TCCR1A register to 0
  TCCR1B = 0;     // same for TCCR1B

  // set compare match register to desired timer count:
  OCR1A = 15624;
  // turn on CTC mode:
  TCCR1B |= (1 << WGM12);
  // Set CS10 and CS12 bits for 1024 prescaler:
  TCCR1B |= (1 << CS10);
  TCCR1B |= (1 << CS12);
  // enable timer compare interrupt:
  TIMSK1 |= (1 << OCIE1A);
  sei();          // enable global interrupts
  lcd.begin(16, 2);
  lcd.print("HH:MM:SS");
  Serial.begin(9600); 


}

void display_on_lcd()
{

  lcd.setCursor(0, 1);
  lcd.print(hours);
  lcd.setCursor(2,1);
  lcd.print(":");
  lcd.setCursor(3,1);  
  lcd.print(minutes);
  lcd.setCursor(5,1);
  lcd.print(":");
  lcd.setCursor(6,1);
  lcd.print(seconds);


}


void loop()
{

  display_on_lcd();

  Serial.println(analogRead(5));
  if(analogRead(buttonPin)<1000)
  {
    if(minutes==59)
    {
      minutes=0;
      if(hours==23)
        hours=0;
      else
        hours++;
    }
    else
    {
      minutes++;
    }
  }


}
