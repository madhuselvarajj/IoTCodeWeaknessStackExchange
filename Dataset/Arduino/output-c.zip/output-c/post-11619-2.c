read (newSample);
sum += newSample;
sum -= oldestSample;
average = sum/numSamples;
update pointers to the memory for oldest sample and for the feature sample;
