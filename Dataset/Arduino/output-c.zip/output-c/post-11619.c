volatile bool pressed = false;
int main(void)
   {
   MCUCR |= (1<<ISC01 |1<<ISC00);       // set INT0 to interrupt on rising edge of pin7
   sei();                               // enable global interrupts

   while(1){
      if (pressed) then do something; //You can disable interrupts here so your code is not interrupted by cli();
      pressed = false; // reset the state
      else do something else;
   // you can re-enable your interrupts here by sei();
   }        
}

// only happens when the change on pin 7 is from LOW to HI 
ISR(INT0_vect){
pressed = true; // update the pressed status
}
