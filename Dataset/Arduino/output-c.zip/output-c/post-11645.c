 #include <IRremote.h>

int RECV_PIN = 11;

IRrecv irrecv(RECV_PIN);

decode_results results;
//int main = 0;
//int left = 0;
//int right = 0;

void setup()
{
  Serial.begin(9600);
  irrecv.enableIRIn(); // Start the receiver
}

void loop() {
  if (irrecv.decode(&results)) {
    Serial.println(results.value, HEX);
        switch (results.value) {
      case 0xB9F56762:
        Serial.println("MARNIX IS RIGHT");
        break;
        case 0x8C2921D6:
//        left = 1;
        Serial.println("LEFT: on");
        break;
      case 0x226270DA:
//        right = 1;
        Serial.println("RIGHT: on");
        break;
    }
    irrecv.resume();


  }
   delay(100);
}
