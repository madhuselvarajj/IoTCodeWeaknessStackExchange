void shiftOutFast(volatile uint8_t &dataPort, uint8_t dataBit,
                  volatile uint8_t &clkPort, uint8_t clkBit, 
                  uint8_t bitOrder, uint8_t val) {
....
}
