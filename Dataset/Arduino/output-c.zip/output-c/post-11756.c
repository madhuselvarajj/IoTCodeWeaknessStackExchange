// Make a pointer to your array
someType *A;

// The size of your array, may be changed programmatically.
int arraySize = 5;

// Reserve memory for your array.
A = malloc(arraySize * sizeof(someType));

// Use Array
A[0] = someData;

// Release A's memory when complete.
free(A);
