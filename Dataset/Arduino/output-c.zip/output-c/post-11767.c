/*
 * Test non local return from ISR:
 *   - wire a pushbutton between digital 2 and GND
 *   - monitor the serial port at 9600/8N1
 *   - pressing the button should skip "func() ending" and immediately
 *     write "func() returned"
 */

#include <setjmp.h>

jmp_buf saved_context;

/*
 * ISR triggered by low level of INT0 = PD2 = Arduino digital 2.
 * Should only be allowed to trigger while inside loop().
 */
ISR(INT0_vect) {
    EIMSK &= ~_BV(INT0);        // disable further interrupts
    longjmp(saved_context, 1);  // return to loop()
}

void func() {
    Serial.println("  func() beginning");
    EIMSK |= _BV(INT0);   // enable INT0 interrupt
    delay(3e3);           // wait 3 s for an interrupt
    EIMSK &= ~_BV(INT0);  // disable INT0 interrupt
    Serial.println("  func() ending");
}

void setup() {
    pinMode(2, INPUT_PULLUP);  // pin 2 is INT0
    Serial.begin(9600);
}

void loop() {
    Serial.println("Calling func()");
    if (setjmp(saved_context) == 0) func();
    Serial.println("func() returned");
    Serial.println();
    delay(2e3);
}
