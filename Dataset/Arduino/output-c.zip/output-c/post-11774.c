#include <avr/sleep.h>

#define LDR_THRESHOLD_RES 25e3  // 25 kOhm
#define LDR_PULLUP_RES    10e3  // 10 kOhm
#define LDR_CHECK_DELAY    200  // 200 ms
#define LDR_DRIVE_PIN        2  // digital 2
#define LDR_SENSE_PIN        0  // analog 0

#define LDR_THRESHOLD_RATIO (1.0*LDR_PULLUP_RES/LDR_THRESHOLD_RES)
#define LDR_THRESHOLD_READING ((int)(1024 / (1 + LDR_THRESHOLD_RATIO)))

/* Sleep until the light is on. */
void wait_for_lights() {
    for (;;) {
        // Sense light level.
        digitalWrite(LDR_DRIVE_PIN, HIGH);
        int reading = analogRead(LDR_SENSE_PIN);
        digitalWrite(LDR_DRIVE_PIN, LOW);

        // Low reading means the light is on.
        if (reading < LDR_THRESHOLD_READING) return;

        // Wait for a few milliseconds.
        unsigned long start = millis();
        do sleep_mode();
        while (millis() - start < LDR_CHECK_DELAY);
    }
}
