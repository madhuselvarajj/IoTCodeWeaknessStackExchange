#define SENSOR_ADDRESS 0xEA 
#include <Wire.h> 
#include <I2cMaster.h> 
TwiMaster AIRSPEED_SENSOR(true); 

void setup() { 
  Serial.begin(9600); 
}

long airspeed_update(void) { 
  static struct { 
    union { int16_t val; uint8_t raw[2]; 
    } airspeed16; 
  } airspeedv3; 

  long airsp;    

  if(AIRSPEED_SENSOR.start(SENSOR_ADDRESS | I2C_WRITE)) { 
    delay(10);   
    AIRSPEED_SENSOR.write(0x07);  
    delay(10); 
    AIRSPEED_SENSOR.stop(); 
  } 

  if(AIRSPEED_SENSOR.restart(SENSOR_ADDRESS | I2C_READ)) { 
    delay(10);  
    airspeedv3.airspeed16.raw[0]=AIRSPEED_SENSOR.read(false); 
    delay(10); 
    airspeedv3.airspeed16.raw[1]=AIRSPEED_SENSOR.read(true); 
    delay(10); 
    AIRSPEED_SENSOR.stop();
  } 

  airsp=airspeedv3.airspeed16.val; 
  return airsp; 
}

void loop() {    
  int airspeed = airspeed_update(); Serial.println(airspeed); 
  delay(50);
}
