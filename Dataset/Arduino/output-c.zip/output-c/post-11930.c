TargetBrightness = SensorValue
if LEDBrightness < TargetBrightness
    increment LEDBrightness
    set LED to LEDBrightness
if LEDBrightness > TargetBrightness
    decrement LEDBrightness
    set LED to LEDBrightness
