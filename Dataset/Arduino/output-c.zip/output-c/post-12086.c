// Include EEPROM library
#include <EEPROM.h>

// location is an int from 0-511 using Arduino Uno with 1KB of EEPROM
void SaveValue(unsigned int location, unsigned int value)
{
    // Find addresses to store each half of the integer
    unsigned int saveLocationLower = location * 2;
    unsigned int saveLocationUpper = saveLocationLower + 1;

    // Split the integer into two parts
    byte lowerValue = value;
    byte upperValue = (value >> 8);

    // Save both parts
    EEPROM.write(saveLocationLower, lowerValue);
    EEPROM.write(saveLocationUpper, upperValue);
}

int LoadValue(unsigned int location) 
{
    // Find both locations to read using same method as above
    unsigned int saveLocationLower = location * 2;
    unsigned int saveLocationUpper = saveLocationLower + 1;

    // Read both locations
    byte lowerValue = EEPROM.read(saveLocationLower);
    byte upperValue = EEPROM.read(saveLocationUpper);

    // Assemble both halves and return value
    return lowerValue + (upperValue << 8);
}
