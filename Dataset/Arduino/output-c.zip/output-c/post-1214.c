static uint8_t 
SPITransfer(uint8_t out)
{
    uint8_t in = 0;
    for (int i=0; i<8; ++i) {
        digitalWrite(MOSI, (out & 0x80) != 0);
        out <<= 1;
        digitalWrite(SCK, HIGH);
        in = (in << 1) | digitalRead(MISO);
        digitalWrite(SCK, LOW);
    }
    return in;
}
