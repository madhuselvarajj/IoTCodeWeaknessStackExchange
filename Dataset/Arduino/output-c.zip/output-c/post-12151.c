$.ajax({
    url: 'yourApiMethodAddress',
    type: 'get',
    error: function (jqXHR, status, ex) {
        /* Something went wrong. Maybe you could stop 
           the update process and show a message and
           a retry button. */
        console.log("Error: " + status);
        console.log(ex);
    },
}).done(function (data) {
    // Update page with information stored in 'data'. View console for hints
    console.log(data);
});
