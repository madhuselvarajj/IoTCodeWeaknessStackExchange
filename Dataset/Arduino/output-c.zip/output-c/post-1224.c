void loop(){
   while(counter< 360*5){
     analogWrite(motor,255);
   }
   analogWrite(motor, 0); //add something like this or whatever could stop it
   //you may want to disable the counter now too
}
