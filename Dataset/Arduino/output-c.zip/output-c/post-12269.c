void lookforsun() {
  while ((targetElevation + 3) < realElevation | (targetElevation - 3) > realElevation) {

    Serial.println("Elevation is not correct");

    while (realElevation < targetElevation)
    { Serial.println("Moving to south");
      digitalWrite(south, LOW);
      lookposition();
    }
    digitalWrite(south, HIGH);

    while (realElevation > targetElevation)
    { Serial.println("Moving to north");
      digitalWrite(north, LOW);
      lookposition();
    }
    digitalWrite(north, HIGH);
  }


  while ((targetHourangle+3) < realHourangle |  (targetHourangle-3) > realHourangle  ) {

    Serial.print("Hour angle is not correct");
    while (realHourangle > targetHourangle)
    { Serial.println("Moving to east");
      digitalWrite(east, LOW);
      lookposition();
    }
    digitalWrite(east, HIGH);

    while (realHourangle < targetHourangle)
    { Serial.println("Moving to west");
      digitalWrite(west, LOW);
      lookposition();
    }
    digitalWrite(west, HIGH);
  }
