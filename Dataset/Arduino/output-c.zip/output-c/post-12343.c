static const char key[] = "\"action_status\"";
const char *p, *q;
char action_status[16];

for (p = response; ; p = q) {
    p = strstr(p, key);    // find key
    if (!p) break;         // not found
    p = strchr(p, ':');    // find ':' between key and value
    p = strchr(p, '"');    // find opening quotes for the value
    q = strchr(p+1, '"');  // find closing quotes

    // Report finding.
    strncpy(action_status, p+1, q-p-1);
    action_status[q-p-1] = '\0';
    Serial.print("Found action status: ");
    Serial.println(action_status);
}
