<type> <name_of_variable> [<number_of_elements>];

or:

long turns[15];
