class cSpeedOfSound {
public:
    cSpeedOfSound(float *i,float *C);

private:
    float roundto(float x, float dp);

    float *C;
    float *a;
    float *i;
};
