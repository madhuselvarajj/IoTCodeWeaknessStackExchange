var response = [] ; // get response here
int response_length = 4; //Put length of the response array here
StaticJsonBuffer<200> jsonBuffer;

String action_ids[] = new String[response_length];
String action_types[] = new String[response_length];
String action_statuses[] = new String[response_length];
String ramp_ids[] = new String[response_length];
String user_ids[] = new String[response_length];

for (int i=0; i < response_length ; i++) {
    JsonObject& data = jsonBuffer.parseObject(response[i]);
    // Note the '&' above

    action_ids[i] = data["action_id"];
    action_types[i] = data["action_type"];
    action_statuses[i] = data["action_status"];
    ramp_ids[i] = data["ramp_id"];
    user_ids[i] = data["user_id"];
}
