int number = 1;
int number1 = 1;

int leda = 2;
int ledb = 3;
int ledc = 4;
int ledd = 5;
int lede = 6;
int ledf = 7;
int ledg = 8;
int ledh = 9;

int leda1 = A0;
int ledb1 = A1;
int ledc1 = A2;
int ledd1 = A3;
int lede1 = A4;
int ledf1 = A5;
int ledg1 = A6;
int ledh1 = A7;

void setup() {
    Serial.begin(9600);

    pinMode(leda, OUTPUT);
    pinMode(ledb, OUTPUT);
    pinMode(ledc, OUTPUT);
    pinMode(ledd, OUTPUT);
    pinMode(lede, OUTPUT);
    pinMode(ledf, OUTPUT);
    pinMode(ledg, OUTPUT);
    pinMode(ledh, OUTPUT);

    pinMode(leda1, OUTPUT);
    pinMode(ledb1, OUTPUT);
    pinMode(ledc1, OUTPUT);
    pinMode(ledd1, OUTPUT);
    pinMode(lede1, OUTPUT);
    pinMode(ledf1, OUTPUT);
    pinMode(ledg1, OUTPUT);
    pinMode(ledh1, OUTPUT);

    pinMode(12, INPUT);
    digitalWrite(12, HIGH);
}
void loop() {

    // turn off all leds
    digitalWrite(leda, LOW);
    digitalWrite(ledb, LOW);
    digitalWrite(ledc, LOW);
    digitalWrite(ledd, LOW);
    digitalWrite(lede, LOW);
    digitalWrite(ledf, LOW);
    digitalWrite(ledg, LOW);
    digitalWrite(ledh, LOW);

    digitalWrite(leda1, LOW);
    digitalWrite(ledb1, LOW);
    digitalWrite(ledc1, LOW);
    digitalWrite(ledd1, LOW);
    digitalWrite(lede1, LOW);
    digitalWrite(ledf1, LOW);
    digitalWrite(ledg1, LOW);
    digitalWrite(ledh1, LOW);


    if (number == 1)
    {
        digitalWrite(leda, HIGH);
        digitalWrite(ledf, HIGH);
        delay(200);
    }
    else if (number == 2)
    {
        digitalWrite(ledb, HIGH);
        digitalWrite(leda, HIGH);
        digitalWrite(ledd, HIGH);
        digitalWrite(ledh, HIGH);
        digitalWrite(ledg, HIGH);
        delay(200);
    }
    else if (number == 3)
    {
        digitalWrite(ledb,HIGH);
        digitalWrite(leda,HIGH);
        digitalWrite(ledd,HIGH);
        digitalWrite(ledf,HIGH);
        digitalWrite(ledg,HIGH);
        delay(200);
    }
    else if (number == 4)
    {
        digitalWrite(ledc,HIGH);
        digitalWrite(ledd,HIGH);
        digitalWrite(leda,HIGH);
        digitalWrite(ledf,HIGH);
        delay(200);
    }
    else if (number == 5)
    {
        digitalWrite(ledb,HIGH);
        digitalWrite(ledc,HIGH);
        digitalWrite(ledd,HIGH);
        digitalWrite(ledf,HIGH);
        digitalWrite(ledg,HIGH);
        delay(200);
    }
    else if (number == 6)
    {
        digitalWrite(ledb,HIGH);
        digitalWrite(ledc,HIGH);
        digitalWrite(ledd,HIGH);
        digitalWrite(ledf,HIGH);
        digitalWrite(ledg,HIGH);
        digitalWrite(ledh,HIGH);
        delay(200);
    }

    if (number1 == 1)
    {
        digitalWrite(A4, HIGH);
        digitalWrite(A1, HIGH);
        delay(200);
    }
    else if (number1 == 2)
    {
        digitalWrite(A5, HIGH);
        digitalWrite(A4, HIGH);
        digitalWrite(A7, HIGH);
        digitalWrite(A0, HIGH);
        digitalWrite(A2, HIGH);
        delay(200);
    }
    else if (number1 == 3)
    {
        digitalWrite(A5,HIGH);
        digitalWrite(A4,HIGH);
        digitalWrite(A7,HIGH);
        digitalWrite(A1,HIGH);
        digitalWrite(A2,HIGH);
        delay(200);
    }
    else if (number1 == 4)
    {
        digitalWrite(A6,HIGH);
        digitalWrite(A7,HIGH);
        digitalWrite(A4,HIGH);
        digitalWrite(A2,HIGH);
        delay(200);
    }
    else if (number1 == 5)
    {
        digitalWrite(A5,HIGH);
        digitalWrite(A6,HIGH);
        digitalWrite(A7,HIGH);
        digitalWrite(A1,HIGH);
        digitalWrite(A2,HIGH);
        delay(200);
    }
    else if (number1 == 6)
    {
        digitalWrite(A5,HIGH);
        digitalWrite(A6,HIGH);
        digitalWrite(A7,HIGH);
        digitalWrite(A0,HIGH);
        digitalWrite(A1,HIGH);
        digitalWrite(A2,HIGH);
        delay(200);
    }

    number = (number%6) + 1;//show next number the next loop
}
