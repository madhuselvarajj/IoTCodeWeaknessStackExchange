// Pin assignments.
int leds[][7] = {
   /*                A     B     C     D     E     F     G  */
   /* 1st die */  {  2,    3,    4,    5,    6,    7,    8 },
   /* 2nd die */  { A0,   A1,   A2,   A3,   A4,   A5,   A6 }
};

// 7-segment "font".
int digits[][7] = {
         /*          A     B     C     D     E     F     G  */
         /* 1 */  { LOW, HIGH, HIGH,  LOW,  LOW,  LOW,  LOW},
         /* 2 */  {HIGH, HIGH,  LOW, HIGH, HIGH,  LOW, HIGH},
         /* 3 */  {HIGH, HIGH, HIGH, HIGH,  LOW,  LOW, HIGH},
         /* 4 */  { LOW, HIGH, HIGH,  LOW,  LOW, HIGH, HIGH},
         /* 5 */  {HIGH,  LOW, HIGH, HIGH,  LOW, HIGH, HIGH},
         /* 6 */  {HIGH,  LOW, HIGH, HIGH, HIGH, HIGH, HIGH}
};

void setup()
{
    for (int die = 0; die < 2; die++) {
        for (int segment = 0; segment < 7; segment++) {
            pinMode(leds[die][segment], OUTPUT);
        }
    }
}

void loop() {
    for (int die = 0; die < 2; die++) {
        int number = random(1, 7);
        for (int segment = 0; segment < 7; segment++)
            digitalWrite(leds[die][segment], digits[number][segment]);
    }
    delay(200);
}
