const int LED1 = 1, 
          LED2 = 3, 
          LED3 = 5;

void setup() {
    Serial.begin(9600);
    pinMode (LED1, OUTPUT);
    pinMode (LED2, OUTPUT);
    pinMode (LED3, OUTPUT);
}

void loop() {
    if (Serial.available()) {
        int x = Serial.read();
        x = x - '0';
        digitalWrite(LED1, x & 0x01);
        digitalWrite(LED2, x & 0x02);
        digitalWrite(LED3, x & 0x04);
        Serial.print(x);
    }
}
