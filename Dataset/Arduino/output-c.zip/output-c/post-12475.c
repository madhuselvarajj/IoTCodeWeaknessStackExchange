int A0, A1,A2,A3,A4;
delay(200);
A0= analogRead(A0);
A1= analogRead(A1);
A2= analogRead(A2);
A3= analogRead(A3);
A4= analogRead(A4);
