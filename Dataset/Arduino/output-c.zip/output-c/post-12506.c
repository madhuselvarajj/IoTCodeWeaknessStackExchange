String GPSLine;

bool checkGPS()
{
  while(serialGPS.available())
  {
    char c = serialGPS.read();
    if(c == '\n') return true;
    if(c == '\r') continue;

    GPSLine += c;
  }
  return false;
}

void loop()
{
  if(checkGPS())
  {
    Serial.println(GPSLine);
    GPSLine = "";
  }
}
