int pin = 7;
unsigned long period;

void setup(){
  Serial.begin(9600); 
  pinMode(pin, INPUT);
  Serial.println("Getting started");
}

void loop(){
  delay(100);
  period = pulseIn(pin, HIGH);
  Serial.println(period);

}
