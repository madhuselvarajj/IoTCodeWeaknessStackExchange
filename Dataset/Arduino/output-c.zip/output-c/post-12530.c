void loop() {
    static char buffer[256];
    static size_t pos;              // position of next write

    while (Serial.available() && pos < sizeof buffer - 1) {

        // Read incoming byte.
        char c = Serial.read();
        buffer[pos++] = c;

        // Echo received message.
        if (c == '\n') {            // \n means "end of message"
            buffer[pos] = '\0';     // terminate the buffer
            Serial.print(buffer);   // send echo
            pos = 0;                // reset to start of buffer
        }
    }
}
