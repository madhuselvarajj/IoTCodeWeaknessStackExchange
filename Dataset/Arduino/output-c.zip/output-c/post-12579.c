if (reedState == HIGH) {
   // do something
   while(digitalRead(reed) == HIGH) {
      // do nothing
   }
}
