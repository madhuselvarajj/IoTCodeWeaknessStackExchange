// fill in your Domain Name Server address here:
IPAddress myDns(192,168,1,1);

// initialize the library instance:
EthernetClient client;

char server[] = "www.arduino.cc";

unsigned long lastConnectionTime = 0;
// last time you connected to the server, in milliseconds
boolean lastConnected = false;
// state of the connection last time through the main loop
const unsigned long postingInterval = 14*1000;
// delay between updates, in milliseconds

void setup() {
  pinMode (pin, OUTPUT);
  digitalWrite (pin, LOW);

  // start serial port:
  Serial.begin(9600);
  // give the ethernet module time to boot up:
  delay(1000);
  // start the Ethernet connection using a fixed IP address and DNS server:
  Ethernet.begin(mac, ip, myDns);
  // print the Ethernet board/shield's IP address:
  Serial.print("My IP address: ");
  Serial.println(Ethernet.localIP());
}

void loop() {
  // if there's incoming data from the net connection.
  // send it out the serial port.  This is for debugging
  // purposes only:
  if (client.available()) {
    Serial.println ("1"); delay(500);
    char c = client.read();
    Serial.print(c);
    } else {Serial.println ("11");delay (500);}
  // if there's no net connection, but there was one last time
  // through the loop, then stop the client:
  if (!client.connected() && lastConnected) {
    Serial.println(2); delay(500);
    Serial.println();
    Serial.println("disconnecting.");
    client.stop();
  } else {Serial.println ("22");delay (500);}

  // if you're not connected, and ten seconds have passed since
  // your last connection, then connect again and send data:
  if(!client.connected() && (millis() - lastConnectionTime > postingInterval)) {
    Serial.println(3); delay(500);
    httpRequest();
    Serial.println ("4");delay (100);
  } else {Serial.println ("33");delay (500);}
  // store the state of the connection for next time through
  // the loop:
  lastConnected = client.connected();
  Serial.println ("end loop");
}

// this method makes a HTTP connection to the server:
void httpRequest() {
  // if there's a successful connection:
  Serial.println ("httpRequest"); delay(500);
  if (client.connect(server, 80)) {
     Serial.println ("H1"); delay(500);
    Serial.println("connecting...");
    // send the HTTP PUT request:
    client.println("GET /latest.txt HTTP/1.1");
    client.println("Host: www.arduino.cc");
    client.println("User-Agent: arduino-ethernet");
    client.println("Connection: close");
    client.println();

    // note the time that the connection was made:
    lastConnectionTime = millis();
  } else {
    Serial.println ("H11"); delay(500);
    // if you couldn't make a connection:
    Serial.println("connection failed");
    Serial.println("disconnecting.");
    client.stop();
  }
}
