distAve   1   2   1   3   4   5
            ^   ^   ^   ^   ^
start       |   |   |   |   |    dir = 0
increase   -'   |   |   |   |    dir = 1
decrease       -'   |   |   |    dir = 0
increase           -'   |   |    dir = 1
increase               -'   |    dir = 2
increase                   -'    dir = 3

dir > 0 therefore INCREASE.
