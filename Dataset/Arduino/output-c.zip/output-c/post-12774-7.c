int distance(int * DIST)
{
    int overallDistance = 0;
    for (int x=1; x<MAX_AVRG; x++)
        overallDistance += (DIST[x] - DIST[x-1]);
    return overallDistance;
}
