#define MAX_PINGS 3       // Put this at the start of your code somewhere

int pings[MAX_PINGS];     // When you come to declare 'pings'
for (int x=0; x<MAX_PINGS; x++)
    pings[x] = -1;        // Whatever each element is initialised to.


// Your 'increasing' function
//   (... and the same for 'decreasing', if you decide to use it!)
bool increasing(int *pingArray)
{
    // CODE GOES HERE
    // and it doesn't matter how long pingArray / pings is
    // because you have 'MAX_PINGS' defined.
    return true;
}

// You call the 'increasing' function as you'd expect:
if (increasing(pings))
{ /* stuff */ }
