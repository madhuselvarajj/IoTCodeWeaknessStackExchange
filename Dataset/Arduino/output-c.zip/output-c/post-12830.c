int sensorPin = 0;
int sensorValue = 0;
int ledPin1 = 4;
int ledPin2 = 8;

void setup() {

  pinMode(ledPin1, OUTPUT);
  pinMode(ledPin2, OUTPUT);
}

void loop() {

  sensorValue = analogRead(sensorPin);

  if (sensorValue < 512)
{
    digitalWrite(ledPin1,HIGH);
    digitalWrite(ledPin2,LOW);
}

  else
{
    digitalWrite(ledPin2,HIGH);
    digitalWrite(ledPin1,LOW);
}
}
