psuedo code;
void loop()
{
  int btn = analogRead(pin);
  if (btn > pin1Level) 
  {
    if (btn > pin5level) DoPin5();  
    else if (btn > pin3level) DoPin3();
    else DoPin1();
  }
  doOtherStuff();
}
