String retunedStr = "";
for(;;) {
    char c = esp8266.read();
    if (c == ' ')
        break;
    retunedStr += c;
}
