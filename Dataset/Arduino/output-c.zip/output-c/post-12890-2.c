const int micPin = A0;

// We want to be able to store 10 int values here.
Average <int>sounds(10);

void setup() {
  Serial.begin(9600);
}

void loop() {
    // Push 10 values into the Average buffer.  Any old values will drop
    // off the bottom.
    for (int i = 0; i < 10; i++) {
        sounds.push(analogRead(micPin));
    }
    Serial.print("Mode value is: ");
    Serial.println(sounds.mode());
    delay(1000);
}
