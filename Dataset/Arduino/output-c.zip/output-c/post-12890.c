most = _store[0];
mostcount = 1;
for(pos = 0; pos < _count; pos++) {
    current = _store[pos];
    currentcount = 0;
    for(inner = pos + 1; inner < _count; inner++) {
        if(_store[inner] == current) {
            currentcount++;
        }
    }
    if(currentcount > mostcount) {
        most = current;
        mostcount = currentcount;
    }
    // If we have less array slices left than the current
    // maximum count, then there is no room left to find
    // a bigger count.  We have finished early and we can
    // go home.
    if(_count - pos < mostcount) {
        break;
    }
}
return most;
