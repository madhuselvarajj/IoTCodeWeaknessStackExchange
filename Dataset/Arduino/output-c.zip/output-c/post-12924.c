char c = Serial.read();
if (c != '\r' || c != '\n') { // <- This line interesting 
    mAnswer[mAnswerLength] = c;
    mAnswerLength++;
}
