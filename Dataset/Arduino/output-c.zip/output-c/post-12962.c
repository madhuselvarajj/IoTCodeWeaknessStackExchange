#include <Arduino.h>
void foo ()
{
PORTD = bit (1);
}
