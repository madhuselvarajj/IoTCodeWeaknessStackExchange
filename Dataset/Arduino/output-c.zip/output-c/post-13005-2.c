if (TDCycle == true && CamAngle >= TDC[i])  
{
...
} else if (BDCycle == true && CamAngle >= BDC[i]) 
{
...
}
else if (Cycle == true && CamAngle < (PrevCamAngle + 1))  
{
...
}
