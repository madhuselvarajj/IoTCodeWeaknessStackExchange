    char byteSend = RS485Serial.read();    // Read received byte
    String str = String(byteSend);
     if (str == "<")  {      //  beginning of the transmission
   // does stuff here
  }
