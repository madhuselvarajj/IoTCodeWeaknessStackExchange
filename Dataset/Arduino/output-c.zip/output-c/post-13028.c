#include <avr/wdt.h>

void setup ()
  {
  Serial.begin (115200);
  Serial.println ();
  Serial.println (F("Code starting ..."));
  wdt_enable(WDTO_8S);
  }  // end of setup

void loop()
{
//   wdt_reset();// make sure this gets called at least once every 8 seconds!
}
