00007e00 <.sec1>:
    7e00:       11 24           eor     r1, r1
    7e02:       84 b7           in      r24, 0x34       ; 52
    7e04:       14 be           out     0x34, r1        ; 52
    7e06:       81 ff           sbrs    r24, 1
    7e08:       f0 d0           rcall   .+480           ;  0x7fea
    7e0a:       85 e0           ldi     r24, 0x05       ; 5
    7e0c:       80 93 81 00     sts     0x0081, r24
    7e10:       82 e0           ldi     r24, 0x02       ; 2
    7e12:       80 93 c0 00     sts     0x00C0, r24
    7e16:       88 e1           ldi     r24, 0x18       ; 24
    7e18:       80 93 c1 00     sts     0x00C1, r24
    7e1c:       86 e0           ldi     r24, 0x06       ; 6
    7e1e:       80 93 c2 00     sts     0x00C2, r24
    7e22:       80 e1           ldi     r24, 0x10       ; 16
    7e24:       80 93 c4 00     sts     0x00C4, r24
    7e28:       8e e0           ldi     r24, 0x0E       ; 14
    7e2a:       c9 d0           rcall   .+402           ;  0x7fbe
    7e2c:       25 9a           sbi     0x04, 5 ; 4
