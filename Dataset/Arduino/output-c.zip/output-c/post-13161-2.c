class I2C_graphical_LCD_display : public Print
{
...
    size_t write(uint8_t c);
};
