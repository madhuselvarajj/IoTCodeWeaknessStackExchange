char *p = I2CinBuffer; // The data to be parsed e.g. 6,100
int count = 0;  

char *str = strtok(p, ",");
while (str != NULL)    // seperate at each "," delimiter
{ 
    inParse[count] = str;      // Add chunk to array  
    count++;      
    str = strtok(NULL, ",");
}
