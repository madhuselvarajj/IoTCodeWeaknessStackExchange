int main ()
  {
  DDRB = bit (5);
  while (true)
    PINB = bit (5);
  }
