int var1;

void setup()
{
    int var2;

    var1 = 123; // global
    var2 = 123; // local
}
