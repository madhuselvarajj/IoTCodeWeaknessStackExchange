/*
 * Tell the client how we understood the requested frequency.
 */
static void send_response(int freq) {
    char freq_str[12];
    itoa(freq, freq_str, 10);
    Serial.print(F("HTTP/1.1 200 OK\r\n"
                   "Content-Type: text/html\r\n"
                   "Content-Length: "));
    Serial.print(84 + strlen(freq_str));
    Serial.print(F("\r\nConnection: close\r\n\r\n"
                   "<!DOCTYPE html>\n"
                   "<html><head><title>Blink</title></head>\n"
                   "LED frequency: "));
    Serial.print(freq_str);
    Serial.print(F(" Hz.\n</html>\n"));
}
