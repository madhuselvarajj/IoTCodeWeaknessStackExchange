static void blink_led(unsigned long toggle_time) {
    static uint8_t led_state;
    static unsigned long last_toggle;
    unsigned long now = millis();
    if (now - last_toggle > toggle_time) {
        led_state = !led_state;
        digitalWrite(led_pin, led_state);
        last_toggle = now;
    }
}
