/*
 * Non-blocking read. Returns the first bytes of the request in a static
 * buffer, or NULL if we do not have a complete request yet.
 */
static char * read_request() {
    static char buffer[32];
    static uint8_t pos;
    static uint8_t crlf_bytes;  // bytes of "\r\n\r\n" received

    while (Serial.available()) {
        char c = Serial.read();

        // Store the received byte if there is enough room.
        if (pos < sizeof buffer - 1)
            buffer[pos++] = c;

        // Update the count of consecutive CRLF bytes received.
        if ((c == '\r' && crlf_bytes % 2 == 0)
         || (c == '\n' && crlf_bytes % 2 == 1))
            crlf_bytes++;
        else
            crlf_bytes = 0;

        // Return the buffer if we have a complete request.
        if (crlf_bytes == 4) {
            buffer[pos] = '\0';  // terminate the string
            pos = 0;
            crlf_bytes = 0;
            return buffer;
        }
    }
    return NULL;
}
