#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

// Comparator function
int intCompare(const void *va, const void *vb) {
  const int a = *(int*)va, b = *(int*)vb;
  // (a>b) is 1 if a>b, else 0.  (b>a) is 1 if b>a, else 0.
  // So the following expression has value 1, 0, or -1.
  return (b>a) - (a>b); // To sort descending
}

int main () {
  int someNumbers [] = { 481,  1041, 107,  279,  809, 2052,  2961, 557, 
             2534, 2968, 89,   839,  2720,  85,  2115, 898, 
             1931, 655,  2631, 1897, 2322, 1115, 2815, 674,
             2259, 176,  598,  525,  600,  1088, 1885, 313,
             1175, 2654, 915,  536,  978,  2052, 798, 1979,
             2571, 2154, 1138, 259, 9662  };
  enum { NumTop = 6, NumNum = (sizeof someNumbers)/sizeof(int) };
  int i, j, tot, largestSoFar[NumTop];

  for (i = 0; i < NumTop; ++i)
    largestSoFar[i] = INT_MIN;  // Init. largestSoFar[] to smallest numbers

  // Process all the numbers
  for (j = 0; j < NumNum; ++j) {
    if (someNumbers[j] <= largestSoFar[0])
      continue;
    // Install number into largestSoFar[] and bubble it up
    largestSoFar[0] = someNumbers[j];
    for (i = 1; i < NumTop; ++i) {
      if (largestSoFar[i] < largestSoFar[i-1]) {
        int t = largestSoFar[i];
        largestSoFar[i] = largestSoFar[i-1];
        largestSoFar[i-1] = t;
      }
      else break;
    }
  }
  printf ("Linear result:  ");
  for (i = tot = 0; i < NumTop; ++i) {
    printf ("%5d ", largestSoFar[i]);
    tot += largestSoFar[i];
  }
  printf ("   Total: %d\n", tot);

  // sort the array descending, for comparison
  qsort (someNumbers, NumNum, sizeof(int), intCompare);
  printf ("Sorting result: ");
  for (i = tot = 0; i < NumTop; ++i) {
    printf ("%5d ", someNumbers[i]);
    tot += someNumbers[i];
  }
  printf ("   Total: %d\n", tot);
  return 0;
}
