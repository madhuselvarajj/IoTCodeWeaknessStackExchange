// Comparator function for integers
int compareInt (const void *a, const void *b) {
  // Return -, 0, or + if first value is <, =, or > second value.
  return *(int*)a - *(int*)b;
}
