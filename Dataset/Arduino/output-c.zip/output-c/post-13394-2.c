#ifdef __AVR_ATmega2560__
- receiver functions
#else
- transmitter functions
#endif
