#include "share.h"
#define TX
#ifdef TX
#define setup_tx() setup()
#define loop_tx() loop()
#else
#define setup_rx() setup()
#define loop_rx() loop()
#endif

void setup_tx(){...}
void loop_tx(){...}

void setup_rx(){...}
void loop_rx(){...}
