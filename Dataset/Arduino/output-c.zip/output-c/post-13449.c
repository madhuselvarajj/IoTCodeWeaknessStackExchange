void loop() {
  // This is to record to our computer the states of
  // the trigger sensor
  digitalWrite(TriggerSensorOut, digitalRead(TriggerSensorIn));  

  // This is to record to our computer the states of
  // the reward sensor
  digitalWrite(RewardSensorOut, digitalRead(RewardSensorIn));  


  int msin1 = digitalRead(ModeStateIn1);
  int msin2 = digitalRead(ModeStateIn2);

  if (msin1 == LOW)
      if (msin2 == LOW)
          mode1();
      else
          mode2();
  else if (msin2 == LOW)
    mode3();
}
