const int KEY_SIZE = 32;
const int BLOCK_SIZE = 16;
const char message [] = "Unlimited characters text here that can be used by the library to encrypt this plain message variable";
const byte key [KEY_SIZE] = "32 characters plain text here";

void encrypt_it (const byte plaintext [BLOCK_SIZE], const byte cipherkey [KEY_SIZE]);  // prototype
void encrypt_it (const byte plaintext [BLOCK_SIZE], const byte cipherkey [KEY_SIZE])
  {
  // encrypt here
  }

void setup ()
  {
  Serial.begin (115200);
  Serial.println ();

  const char * p = message;

  while (strlen (p) > 0)
    {
    byte plain [BLOCK_SIZE];
    memset (plain, 0, BLOCK_SIZE);  // ensure trailing zeros
    // copy block into plain array
    memcpy (plain, p, min (strlen (p), BLOCK_SIZE));
    // encrypt it
    encrypt_it (plain, key);
    // advance past this block
    p += min (strlen (p), BLOCK_SIZE);
    }
  Serial.println ("Done");
  }  // end of setup

void loop ()
  {
  }  // end of loop
