#define MAX_MESSAGE_SIZE 256
uint8_t key[] = "32 characters plain text here";
uint8_t plain[MAX_MESSAGE_SIZE+1] = "Unlimited characters text here that can be used by the library to encrypt this plain message variable";
aes256_init(&ctxt, key);
aes256_encrypt_ecb(&ctxt, plain);
// plain is now encrypted.
