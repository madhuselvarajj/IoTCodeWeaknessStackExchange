   digitalWrite (ledPin1 = HIGH); 
   digitalWrite (ledPin2 = LOW); 
   digitalWrite (ledPin3 = LOW); 
   digitalWrite (ledPin4 = LOW); 
   digitalWrite (ledPin5 = LOW); 
   digitalWrite (ledPin6 = LOW); 
   digitalWrite (ledPin7 = LOW); 
   digitalWrite (ledPin8 = LOW); 
