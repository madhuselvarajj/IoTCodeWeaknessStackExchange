const byte X1 = bit (2);   // D2 on Uno
const byte X2 = bit (3);   // D3 on Uno
const byte X3 = bit (4);   // D4 on Uno

const byte patterns [7] [2] = {
// PORT DDR
  { 0,   0, }, // all off
  { X1, X1 | X2 }, // LED1: X1 on,  X2 off, X3 HiZ
  { X2, X1 | X2 }, // LED2: X1 off, X2 on,  X3 HiZ
  { X2, X2 | X3 }, // LED3: X2 on,  X3 off, X1 HiZ
  { X3, X2 | X3 }, // LED4: X2 off, X3 on,  X1 HiZ
  { X1, X1 | X3 }, // LED5: X1 on,  X3 off, X2 HiZ
  { X3, X1 | X3 }, // LED6: X3 on,  X1 off, X2 HiZ
};

void setup ()
  {
  }  // end of setup

void loop ()
  {
  for (int i = 0; i < 7; i++)
    {
    DDRD = patterns [i] [1];
    PORTD = patterns [i] [0];
    delay (500);
    }  // end of for loop
  }  // end of loop
