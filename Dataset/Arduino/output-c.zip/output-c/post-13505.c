  char indata[32] = "1.0 2.0 3.0 4.0";

  int len = strlen (indata);
  for (int i = 0; i < len; i++)
    if (isspace (indata [i]))
      indata [i] = ',';

  Serial.println (indata);   // prints: 1.0,2.0,3.0,4.0
