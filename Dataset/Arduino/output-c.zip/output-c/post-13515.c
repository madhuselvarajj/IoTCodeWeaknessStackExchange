if (Serial.available()) {
  int inByte = Serial.read();
  if (inByte == ' ')
    Serial1.write(',');
  else
    Serial1.write(inByte); 
}
