if (count == 16) {
        count = -1; /* <<<<<<<<<<<<<<<<<<<<<<<<<<<<Here is the problem*/       
        Serial.println("Counter equals 16 NOW");
        printScreen();
        delay(200);


        for (int i = 0; i < sizeof(drawNo);  i++) {
            drawNo[i] = (char)0;
        }
