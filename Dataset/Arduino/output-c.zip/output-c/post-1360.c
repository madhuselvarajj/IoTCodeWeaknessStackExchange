#import <Arduino.h>
#include <OBD.h>

int kphValue = 0;
int rpmValue = 0;

COBD obd;

//array of character arrays, see http://arduino.cc/en/Reference/string
const char* rpmStrings[] = {    ",N,N,255,000,255,000", 
                                ",N,N,255,255,030,000", 
                                ",N,N,255,255,000,000" }; 

void setup(){
    Serial2.begin(9600);
    obd.begin();

    //Initiate OBD-II connection until success
    while ( !obd.init() ) {
        Serial2.print("$0,Y,Y,255,255,000,000$0,Y,Y,255,255,000,000!");
        delay(1000);
        Serial2.print("$0,Y,Y,000,000,000,000$0,Y,Y,000,000,000,000!");
        delay(1000);
    }
}

void loop() {
    if ( obd.read(PID_RPM, rpmValue) && obd.read(PID_SPEED, kphValue) )
    {
        int rpmStringIndex = determineRpmIndex(rpmValue);
        int mphValue = kphToMPH(kphValue);

        //payloadString = "$" + onesString + rpmString + "$" + tensString + "rpmString" + "!";
        //using Arduino String objects is generally not a good idea due to memory constraints
        //it's probably ok, but I'd rather use character arrays and/or print a bit at a time rather than trying to assemble a giant string 
        Serial2.print("$");
        Serial2.print(mphValue % 10); //ones
        Serial2.print(rpmStrings[rpmStringIndex]);
        Serial2.print("$");
        Serial2.print(mphValue / 10); //tens - integer division, don't need modulo

        //do you really want to append the string "rpmString!" or did you want the contents of the variabe rmpString+"!" ?
        //I'm pretty sure you meant the latter
        Serial2.print(rpmStrings[rpmStringIndex]);
        Serial2.print("!");
    }
    else 
    {
        //obd read error
        //add debugging output here to see if obd failed to respond correctly/on time
    }
}

int kphToMph( int kphValue ) {
    //return a value rather than updating a global variable
    return ( int ) ( kphValue * 0.621371 );
}

int determineRpmIndex( int rpmValue ) {
    if ( rpmValue >= 5000 )
        return 2;

    if ( rpmValue >= 3000 )
        return 1;

    return 0;
}
