GPS.end();

aprs_send(); 
while (afsk_busy());

GPS.begin(GPS_BAUDRATE);
