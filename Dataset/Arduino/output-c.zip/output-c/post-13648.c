  uint8_t sendbuffernew_x[20];
  char buff_x[20] = "";
  String xorient = "";
  dtostrf(event.orientation.x, 4, 1, buff_x);  //4 is mininum width, 6 is precision
  xorient += buff_x;


  xorient.getBytes(sendbuffernew_x, 20);
  char sendbuffersizenew_x = min(20, xorient.length());


  // write the data
  BTLEserial.write(sendbuffernew_x, sendbuffersizenew_x);
  memset(sendbuffernew_x, 0, sizeof(sendbuffernew_x));

  uint8_t sendbuffernew_y[20];
  char buff_y[20]= "";
  String yorient = "";
  dtostrf(event.orientation.y, 4, 1, buff_y);  //4 is mininum width, 6 is precision
  yorient += buff_y;


  yorient.getBytes(sendbuffernew_y, 20);
  char sendbuffersizenew_y = min(20, yorient.length());


  // write the data
  BTLEserial.write(sendbuffernew_y, sendbuffersizenew_y);
  memset(sendbuffernew_y, 0, sizeof(sendbuffernew_y));

  uint8_t sendbuffernew_z[20];
  char buff_z[20]="";
  String zorient = "";
  dtostrf(event.orientation.z, 4, 1, buff_z);  //4 is mininum width, 6 is precision
  zorient += buff_z;


  zorient.getBytes(sendbuffernew_z, 20);
  char sendbuffersizenew_z = min(20, zorient.length());


  // write the data
  BTLEserial.write(sendbuffernew_z, sendbuffersizenew_z);
  memset(sendbuffernew_z, 0, sizeof(sendbuffernew_z));
