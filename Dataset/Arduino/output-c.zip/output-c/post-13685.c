// Stop Motor
void stopmotor(int which)
{
  digitalWrite(motorPins [which],LOW);
}
