#include <Wire.h>

void setup()
{
  Wire.begin(2);                
  Wire.onRequest(requestEvents);
  Wire.onReceive(receiveEvents);
}

void loop(){}

volatile byte n = 0;

void requestEvents()
{
  Wire.write(n);
}

void receiveEvents(int howMany)
{  
  n = Wire.read();
}
