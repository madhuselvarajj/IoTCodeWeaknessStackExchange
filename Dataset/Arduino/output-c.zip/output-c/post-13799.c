74HC4051  Arduino   Meaning
    11       D2        A
    10       D3        B
     9       D4        C
     3       A2        O/I
