const int buttonPin = 6;
const int buttonPin1 = 7;

int previousReading = HIGH;
int previousReading1 = HIGH; 

void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(buttonPin1, INPUT_PULLUP);
  Serial.begin(9600); 
}

void loop() {
  int reading = digitalRead(buttonPin);
  int reading1 = digitalRead(buttonPin1);

  if (previousReading == HIGH && reading == LOW) {
     Serial.println(HIGH);         
  }

  if (previousReading1 == HIGH && reading1 == LOW) {
     Serial.println(LOW);
  }

  previousReading = reading;
  previousReading1 = reading1;

}
