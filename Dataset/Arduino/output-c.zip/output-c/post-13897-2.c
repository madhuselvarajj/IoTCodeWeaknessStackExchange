  if (Serial.available() > 0) {
    delay(100);
    // look for the next word 
    int cmd = Serial.parseInt();
    clearBuffer();
