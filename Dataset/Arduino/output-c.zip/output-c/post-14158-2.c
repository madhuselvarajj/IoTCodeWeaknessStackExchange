#include <SPI.h>
#include <Mirf.h>
#include <MirfHardwareSpiDriver.h>
#include <MirfSpiDriver.h>
#include <nRF24L01.h>

unsigned long lasttime;
unsigned long delaytime;
unsigned long time;
const int ledPin = 3;

void setup(){
  Serial.begin(9600);

  //RADIO  
  Mirf.spi = &MirfHardwareSpi;
  Mirf.init();
  Mirf.setRADDR((byte *)"serv1"); 
  Mirf.payload = 1;
  Mirf.channel = 90;
  Mirf.config();
  Mirf.configRegister(RF_SETUP,0x06);

  //LED 
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, HIGH);   
  Serial.println("Listening ... ");
}

void loop() {
  byte c;

  if( Mirf.dataReady() ) {
    Mirf.getData(&c);
    Serial.write(c);

    if (c == 'X') {
      digitalWrite(ledPin, HIGH);    
    }
  } else {
      digitalWrite(ledPin, LOW);
  }
}
