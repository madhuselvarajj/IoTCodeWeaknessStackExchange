const byte ledPin = 13; 
const byte inPin = 7; 

const unsigned long MAX_PUSH_TIME = 2000;  // ms
const unsigned long DEBOUNCE_TIME = 20;    // ms
unsigned long whenPushed;

bool switchState; 
bool awaitingRelease;

void setup() 
  {
  pinMode(ledPin, OUTPUT); 
  pinMode(inPin, INPUT_PULLUP); 
  }  // end of setup

void switchPushed ()
  {
  // we want them to let go now, ignore it
  if (awaitingRelease) 
    return;

  // is LED already on?
  if (digitalRead (ledPin) == HIGH)
    {
    // held for too long? turn off LED, remember it 
    if (millis () - whenPushed >= MAX_PUSH_TIME)
      {
      awaitingRelease = true;
      digitalWrite(ledPin, LOW); 
      }  
    return;  // all done
    }

  // turn LED on, remember when    
  digitalWrite(ledPin, HIGH); 
  whenPushed = millis (); 
  delay (DEBOUNCE_TIME);
  }  // end of switchPushed

void switchReleased ()
  {
  digitalWrite(ledPin, LOW); 
  awaitingRelease = false;  // they released it! 
  delay (DEBOUNCE_TIME);
  }  // end of switchReleased

void loop()
  {
  switchState = digitalRead(inPin);
  if (switchState == LOW) 
    switchPushed ();
  else
    switchReleased ();
  }  // end of loop
