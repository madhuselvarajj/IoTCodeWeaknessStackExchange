void sendPI(){
     int values[] = {(int)out, (int)outReversed  };

     Wire.write(values[count]);
     count++;
     if(count > 1){
     count = 0;

     }
 }
