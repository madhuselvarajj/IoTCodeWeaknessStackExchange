const byte pin = 13; 
volatile bool detected; 

void setup() { 
  pinMode(pin, OUTPUT); 
  attachInterrupt(1, blink, RISING); 
} 

void loop() { 
  if (detected)
    {
    delay(10);
    digitalWrite(pin, LOW);
    detected = false;
    }

} 

void blink() { 
  digitalWrite(pin, HIGH);
  detected = true; 
}
