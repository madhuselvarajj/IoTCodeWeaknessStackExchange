void loop() {
    static state=state_off;
    if (button_1_pushed) {
        state=state_1;
    } elseif (button_2_pushed) {
        state=state_2;
    }
    if (state==state_off) {
        turn_all_leds_off();
    } elseif (state==state_2) {
        shownextframe_rainbow();
    } elseif (state==state_2) {
        shownextframe_chaser();
    }
    delay(1);
}
