Volt_s = analogRead(analogInPin) - analogRead(analogInPin1);
t_s = millis();
deltaT = t_s - t_r;
area += deltaT*(Volt_r + Volt_s)/2;
t_r = t_s;
Volt_r = Volt_s;
