 // give up if switches pressed
  if (digitalRead (inPin(1)) == HIGH || 
         digitalRead (inPin(2)) == HIGH ||
         digitalRead (inPin(3)) == HIGH ||
         digitalRead (inPin(4)) == HIGH || 
         digitalRead (inPin(6)) == HIGH ||
         digitalRead (inPin(7)) == HIGH || 
         digitalRead (inPin(8)) == HIGH ||
         digitalRead (inPin(9)) == HIGH || 
         digitalRead (inPin(10)) == HIGH ||
         digitalRead (inPin(11)) == HIGH || 
         digitalRead (inPin(12)) == HIGH ||
         digitalRead (inPin(13)) == HIGH || 
         digitalRead (inPin(14)) == HIGH ||
         digitalRead (inPin(15)) == HIGH || 
         digitalRead (inPin(16)) == HIGH ||
         digitalRead (inPin(17)) == HIGH || 
         digitalRead (inPin(18)) == HIGH ||
         digitalRead (inPin(19)) == HIGH || 
         digitalRead (inPin(20)) == HIGH ||
         digitalRead (inPin(21)) == HIGH ||
         digitalRead (inPin(22)) == HIGH || 
         digitalRead (inPin(23)) == HIGH ||
         digitalRead (inPin(24)) == HIGH)
           return;
