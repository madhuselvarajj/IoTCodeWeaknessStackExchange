volatile bool counting;
volatile unsigned long events;

unsigned long startTime;
const unsigned long INTERVAL = 50;  // ms

void eventISR ()
  {
  if (counting)
    events++;    
  }  // end of eventISR

void setup ()
  {
  Serial.begin (115200);
  Serial.println ();
  pinMode (2, INPUT_PULLUP);
  attachInterrupt (0, eventISR, RISING);
  }  // end of setup

void showResults ()
  {
  Serial.print ("I counted ");
  Serial.println (events);
  }  // end of showResults

void loop ()
  {
  if (counting)
    {
    // is time up?
    if (millis () - startTime < INTERVAL)
      return;  
    counting = false;
    showResults ();
    }  // end of if

  noInterrupts ();
  events = 0;
  startTime = millis ();
  EIFR = bit (INTF0);  // clear flag for interrupt 0
  counting = true;
  interrupts ();
  }  // end of loop
