const byte TESTPIN = 2;

const byte test [6] = { 
    0b00000011,
    0b01111011,
    0b01010100,
    0b00010100,
    0b01001010,
    0b10111111 };

void setup ()
  {
  pinMode (TESTPIN, INPUT);
  delay (100);
  }  // end of setup

void loop ()
  {
  // wait for host to pull pin low
  while (digitalRead (TESTPIN) == HIGH)
    { }
  // wait for host to release it
  while (digitalRead (TESTPIN) == LOW)
    { }
  digitalWrite (TESTPIN, HIGH);
  pinMode (TESTPIN, OUTPUT);
  for (byte i = 0; i < 6; i++)
    for (byte j = 0; j < 8; j++)
      {
      delayMicroseconds (1100);
      digitalWrite (TESTPIN, test [i] & bit (7 - j));
      }
  pinMode (TESTPIN, INPUT);
  }  // end of loop
