// Linear rise in wave period
int x = 10;
for (int x=80; x < 2668; ++x){
  OCR1A = x; 
  delay(10); // 10ms delay
}
