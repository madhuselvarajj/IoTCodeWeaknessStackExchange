char dataBuffer [80];
strcpy (dataBuffer, "Hello, world");

File dataFile = SD.open("datalog.txt", FILE_WRITE);
if (dataFile) {
  dataFile.println(dataBuffer);
  dataFile.close();
}
