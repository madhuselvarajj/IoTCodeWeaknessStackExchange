class Esp8266 {

  public:
    Esp8266();
    void begin(HardwareSerial *wifiCom, HardwareSerial *debugCom);
  private:

    HardwareSerial *wifiCom;
    HardwareSerial *debugCom;

};

Esp8266::Esp8266() {
}

void Esp8266::begin(HardwareSerial *wifiCom, HardwareSerial *debugCom) {
  this->wifiCom = wifiCom;
  this->debugCom = debugCom;

  this->debugCom->begin(115200);
  while (!this->debugCom) {
  ;
  }
}

Esp8266 esp;

void setup ()
  {
  esp.begin (&Serial, &Serial1);
  }  // end of setup

void loop ()
  {
  }  // end of loop
