    if(distance <= 60 && distance >= 45)// the distance is too large
    {
    digitalWrite(motorPin, HIGH);

    delay(200);// I increase the delay to make the motor vibrate slowly

    digitalWrite(motorPin, LOW);

    delay(200);

    } 

    else if(distance < 45 && distance >= 30)
    {
    digitalWrite(motorPin, HIGH);

    delay(100);

    digitalWrite(motorPin, LOW);

    delay(100);

   }
    else if(distance < 30){

    digitalWrite(motorPin, HIGH);

    delay(50);

    digitalWrite(motorPin, LOW);

    delay(50); 

  } 
  else 
  {
    digitalWrite(motorPin, LOW);// If the distance is too large the motor will be off
  }
