// For Mega2560

const int BUTTONS = 4;
const int FIRST_SWITCH = 18;
const int FIRST_RELAY =  41;  
const int CLICKS = 5;
const unsigned long DEBOUNCE_TIME = 20;  // ms

int retardo  = 300;
int finBoton = 1000;

volatile byte counts [BUTTONS];
unsigned long lastPress [BUTTONS];

void doInterrupts (const int which)
 {
 // debounce
 if (millis () - lastPress [which] < DEBOUNCE_TIME)
   return;

 lastPress [which] = millis ();
 counts [which]++;
 }  // end of doInterrupts

void pin18Pressed ()
  {
  doInterrupts (0);  
  }  // end of pin18Pressed

void pin19Pressed ()
  {
  doInterrupts (1);  
  }  // end of pin19Pressed

void pin20Pressed ()
  {
  doInterrupts (2);  
  }  // end of pin20Pressed

void pin21Pressed ()
  {
  doInterrupts (3);  
  }  // end of pin21Pressed

void setup() 
  {
  // configure inputs / outputs
  for (int i = 0; i < BUTTONS; i++)
    {
    pinMode (FIRST_SWITCH + i, INPUT_PULLUP);
    pinMode (FIRST_RELAY + i, OUTPUT);
    }

  attachInterrupt (5, pin18Pressed, FALLING);
  attachInterrupt (4, pin19Pressed, FALLING);
  attachInterrupt (3, pin20Pressed, FALLING);
  attachInterrupt (2, pin21Pressed, FALLING);

  } // end of setup

// turn relay on for a particular switch
void handleSwitchPress (const int which)
  {
  for (int i = 0; i < CLICKS; i++)
  {
    digitalWrite(FIRST_RELAY + which, HIGH);
    delay(retardo);
    digitalWrite(FIRST_RELAY + which, LOW);
    delay(retardo);
  }
  delay(finBoton);
  } // end of handleSwitchPress

// main loop
void loop()
  {
 for (int i = 0; i < BUTTONS; i++)
   if (counts [i] > 0)
     {
     handleSwitchPress (i);
     counts [i]--;  
     }
  }  // end of loop
