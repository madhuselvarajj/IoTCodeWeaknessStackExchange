Serial.write('\n');
Serial.print(ID);
Serial.write('\n');
Serial.print(|LT2|LP3|LM5|LR4|LI6);
Serial.write('\n');
