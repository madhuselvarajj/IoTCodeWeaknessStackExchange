# *** Initialiation ***
Note - GPIO pinA reads Bit 0, GPIO pinB reads Bit 0

import GPIO module
set GPIO pinA and pinB to input mode
declare 16 elements dataBitList to store card number

# *** Read a pulse from either pinA or PinB ***
Note - wait for pulse coming at PinA or pinB

while (pinA OR pinB) NOT Low 
  sleep 100uS

read pinA         
  if pinA Low
    return 0
  else                    
    return 1               

# *** Main program ***
Note - just read one card number, no parity checked.

initialize pinA, pinB, dataBitList
loop 26 times
  read start pulse
  loop to read  8 factory data bits and discard
  loop to read 16 card number bits and store in dataBitlist
  read partity pulse
  sleep 100mS

print card number in the dataBitList 
