$ wpa_passphrase yournetwork yournetworkkey
network={
  ssid="yournetwork"
  #psk="yournetworkkey"
  psk=70989c22e6ea590184d5def213278204e50a7eb52a00a122f430083b882deadc
}
