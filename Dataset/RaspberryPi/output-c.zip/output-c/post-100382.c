ctrl_interface=DIR=/var/run/wpa_supplicant

network={
    ssid="yourSSID"
    key_mgmt=WPA-PSK
    psk="yourpasscode"
    priority=1
    id_str="dhcp_client"
}

network={
    ssid="Hotspot"
    mode=2
    key_mgmt=WPA-PSK
    psk="password"
    frequency=2437
    id_str="dhcp_server"
}
