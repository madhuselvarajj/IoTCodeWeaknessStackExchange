function status(){
    rpio.open(15, rpio.INPUT, rpio.PULL_UP);
    setInterval(function(){
        var status = rpio.read(15)
        console.log(status)
    },1000)
}
