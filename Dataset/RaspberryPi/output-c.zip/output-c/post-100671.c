void servo_open(int servo) {
switch (servo) {
    case 0:
        pullUpDnControl(SERVO_0, PUD_OFF);
        pinMode(SERVO_0, PWM_OUTPUT);
        pwmSetMode(PWM_MODE_MS);
        pwmSetClock(PWM_CHANNEL_0_CLOCK);
        pwmSetRange(PWM_CHANNEL_0_RANGE);
        break;
    case 1:
        pullUpDnControl(SERVO_1, PUD_OFF);
        pinMode(SERVO_1, PWM_OUTPUT);
        pwmSetMode(PWM_MODE_MS);
        pwmSetClock(PWM_CHANNEL_0_CLOCK);
        pwmSetRange(PWM_CHANNEL_0_RANGE);
        break;  
    default:

        break;
}}
