var params = [
    '-i', 'pipe:0', // Tell avconv to expect an input stream (via its stdin)
    '-f', 'flv',  
    '-vcodec', 'copy',
    '-strict', 'experimental',
    URL
];
