Relocatable heap version 4 found at 0x30000000
total space allocated is 236M, with 234M relocatable, 2.3M legacy and 0 offline
1 legacy blocks of size 2359296

free list at 0x3ad9aaa0
352 free memory in 2 free block(s)
largest free block is 320 bytes

0x30000000: legacy block 2.3M
0x30240000: free 320
[  80] 0x30240140: used  608 (refcount 1 lock count 0, size      540, align    4, data 0x30240160, d0rual) 'GLXX_TEXTURE_T'
[  78] 0x302403a0: used  192 (refcount 1 lock count 0, size      128, align    4, data 0x302403c0, D1rual) 'GLXX_BUFFER_INNER_T.storage'
