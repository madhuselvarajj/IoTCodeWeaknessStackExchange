- Original Installation
Raspberry Pi reference 2019-06-20
- Current OS
Distributor ID: Raspbian
Description:    Raspbian GNU/Linux 10 (buster)
Release:    10
Codename:   buster
- Kernel
4.19.58-v7l+
- Model
Raspberry Pi 4 Model B Rev 1.1
