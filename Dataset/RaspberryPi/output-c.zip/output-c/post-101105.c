#include <stdio.h>
#include <pigpio.h>
#include <unistd.h>

int main() {

    // 2, 3, 4, 14, 15, 18, 17
    int gpio_colums[] = {15, 18, 17};
    int gpio_rows[] = {2, 3, 4, 14};

    if (gpioInitialise() < 0) {
        fprintf(stderr, "pigpio initialisation failed\n");
        return -1;
    }

    for (int i = 0; i < 3; i++) {
        gpioSetMode(gpio_colums[i], PI_INPUT);
        gpioSetPullUpDown(gpio_colums[i], PI_PUD_UP);
    }

    for (int i = 0; i < 4; i++) {
        gpioSetMode(gpio_rows[i], PI_INPUT);
        if (gpioSetPullUpDown(gpio_rows[i], PI_PUD_UP) < 0) {
            fprintf(stderr, "pigpio initialisation failed\n");
            return -1;
        }
    }

    while (1) {
        // power every colomn
        for (int i = 0; i < 3; i++) {
            gpioSetMode(gpio_colums[i], PI_OUTPUT);
            gpioWrite(gpio_colums[i], 0);
            usleep(10); // give the electronic components a bit time
            // find pressed button
            for (int j = 0; j < 4; j++) {
                //printf("gpioRead retunrned %d\n", gpioRead(gpio_rows[i]));
                if (gpioRead(gpio_rows[j]) == 0) {
                    printf("column gpio pin %d, row gpio pin %d\n", gpio_colums[i], gpio_rows[j]);
                    printf("column %d row %d\n", i, j);
                    usleep(200000);         
                }
            }

            gpioWrite(gpio_colums[i], 1);
            gpioSetMode(gpio_colums[i], PI_INPUT);
        }

        usleep(10000);          
    }

    return 0;
}
