    /**
     * Handler for sigint signals
     *
     * @param signal_number ID of incoming signal.
     *
     */
    static void signal_handler(int signal_number)
    {
        // Going to abort on all signals
        vcos_log_error("Aborting program\n");

        // TODO : Need to close any open stuff...how?

       exit(255);
    }
