rpi ~$ file vpnsecure-2.0.8/vpnsecure
vpnsecure-2.0.8/vpnsecure: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux.so.2, for GNU/Linux 2.6.24, BuildID[sha1]=00902f79beef7f688bf765c81ad98323be1f3ed6, stripped

rpi ~$ file vpnsecure-2.1.7/vpnsecure
vpnsecure-2.1.7/vpnsecure: ELF 64-bit LSB shared object, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, for GNU/Linux 2.6.32, stripped
