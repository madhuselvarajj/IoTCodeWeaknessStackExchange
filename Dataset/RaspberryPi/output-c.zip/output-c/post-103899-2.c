rpi ~$ iw dev
phy#0
        Interface p2p-wlan0-0
                ifindex 4
                wdev 0x3
                addr d2:3d:c9:4f:6b:fb
                type P2P-GO
                channel 36 (5180 MHz), width: 20 MHz, center1: 5180 MHz
                txpower 31.00 dBm
        Unnamed/non-netdev interface
                wdev 0x2
                addr d2:3d:c9:4f:eb:fb
                type P2P-device
                txpower 31.00 dBm
        Interface wlan0
                ifindex 3
                wdev 0x1
                addr dc:a6:32:01:db:ed
                ssid wlan@hoeft-online.de
                type managed
                channel 1 (2412 MHz), width: 20 MHz, center1: 2412 MHz
                txpower 31.00 dBm
