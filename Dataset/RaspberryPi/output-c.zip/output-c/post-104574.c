#include <boost/multiprecision/gmp.hpp>
#include <iostream>

using namespace boost;
using namespace multiprecision;

int main()
{
    std::cout.precision(std::numeric_limits<mpf_float_50>::digits10);
    std::cout << mpf_float_50(acos(-1.0)) << std::endl;
    return 0;
}
