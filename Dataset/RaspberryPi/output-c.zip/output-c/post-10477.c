> sudo iptables -t nat -L -n -v
Chain PREROUTING (policy ACCEPT 5 packets, 637 bytes)
 pkts bytes target     prot opt in     out     source               destination
    5   300 REDIRECT   tcp  --  *      *       0.0.0.0/0            192.168.42.1             tcp dpt:80 redir ports 8080

Chain INPUT (policy ACCEPT 7 packets, 725 bytes)
 pkts bytes target     prot opt in     out     source               destination

Chain OUTPUT (policy ACCEPT 14 packets, 1026 bytes)
 pkts bytes target     prot opt in     out     source               destination

Chain POSTROUTING (policy ACCEPT 1 packets, 60 bytes)
 pkts bytes target     prot opt in     out     source               destination
   16  1178 MASQUERADE  all  --  *      ppp0    0.0.0.0/0            0.0.0.0/0
