if arch="armv6l" then
  FROM arm32v6/alpine
else
  FROM alpine
end if
