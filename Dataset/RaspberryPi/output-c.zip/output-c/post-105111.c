char data[]={0x80, 75};

dimmer = wiringPiI2CSetup(0x27);

write(dimmer, data, 2);
