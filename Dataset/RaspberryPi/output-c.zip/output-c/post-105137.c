if (SerIn=='Got') { 
  Serial.println('I got it');
}else{
  Serial.println('Oopz');
} 
