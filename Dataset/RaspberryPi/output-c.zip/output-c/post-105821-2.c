FLASK THREAD                     RPI WORKER THREAD
------------                     -----------------

-->REQUEST 
FLASK CALLBACK
SERIAL EVENT -----------------------> WAKE
<--RESPONSE (Not yet available)       READ SERIAL
                                      PROCESS DATA
                                      POPULATE RESPONSE BUFFER
                                      SLEEP

-->REQUEST
FLASK CALLBACK
<--RESPONSE (BUFFER)
