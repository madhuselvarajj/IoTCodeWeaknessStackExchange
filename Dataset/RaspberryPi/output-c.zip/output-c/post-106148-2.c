KeyPress event, serial 25, synthetic NO, window 0x1e00001,
    root 0x369, subw 0x0, time 2252742, (107,658), root:(1462,769),
    state 0x0, keycode 80 (keysym 0xff97, KP_Up), same_screen YES,
    XLookupString gives 0 bytes: 
    XmbLookupString gives 0 bytes: 
    XFilterEvent returns: False
