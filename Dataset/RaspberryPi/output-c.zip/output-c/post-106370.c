module (
        load="builtin:omfile"
        template="RSYSLOG_TraditionalFileFormat"
)

if $programname == 'kernel' then {
        if $msg contains 'iptables:'
        then {
                action (type="omfile" file="/var/log/iptables.log" sync="off")
                & stop
        }
}
