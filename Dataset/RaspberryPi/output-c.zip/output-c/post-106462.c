0: under-voltage
1: arm frequency capped
2: currently throttled
3: Soft Temp limit reached  3
16: under-voltage has occurred
17: arm frequency capped has occurred
18: throttling has occurred
19: Soft Temp limit has occurred
