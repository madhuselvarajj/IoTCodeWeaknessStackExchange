pi@raspberrypi:~ $ sudo systemctl status wpa_supplicant.service 
● wpa_supplicant.service - WPA supplicant
   Loaded: loaded (/lib/systemd/system/wpa_supplicant.service; enabled; vendor preset: enabled)
   Active: failed (Result: exit-code) since Sun 2019-12-22 21:36:14 GMT; 53s ago
  Process: 355 ExecStart=/sbin/wpa_supplicant -u -s -c /etc/wpa_supplicant/wpa_supplicant.conf -i wlan0 (code=exited, status=255/EXCEPTION)
 Main PID: 355 (code=exited, status=255/EXCEPTION)

Dec 22 21:36:13 raspberrypi systemd[1]: Starting WPA supplicant...
Dec 22 21:36:14 raspberrypi wpa_supplicant[355]: Successfully initialized wpa_supplicant
Dec 22 21:36:14 raspberrypi systemd[1]: Started WPA supplicant.
Dec 22 21:36:14 raspberrypi wpa_supplicant[355]: ctrl_iface exists and seems to be in use - cannot override it
Dec 22 21:36:14 raspberrypi wpa_supplicant[355]: Delete '/var/run/wpa_supplicant/wlan0' manually if it is not used anymore
Dec 22 21:36:14 raspberrypi wpa_supplicant[355]: Failed to initialize control interface '/var/run/wpa_supplicant'.
                                                 You may have another wpa_supplicant process already running or the file was
                                                 left by an unclean termination of wpa_supplicant in which case you will need
                                                 to manually remove this file before starting wpa_supplicant again.
Dec 22 21:36:14 raspberrypi wpa_supplicant[355]: nl80211: deinit ifname=wlan0 disabled_11b_rates=0
Dec 22 21:36:14 raspberrypi systemd[1]: wpa_supplicant.service: Main process exited, code=exited, status=255/EXCEPTION
Dec 22 21:36:14 raspberrypi systemd[1]: wpa_supplicant.service: Failed with result 'exit-code'.
