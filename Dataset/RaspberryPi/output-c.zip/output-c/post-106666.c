app.get('/api/ping', (req, res) => {
    return res.send('pong');
}); 

app.all('*', (req, res) => {
    res.redirect('http://192.168.1.1:7070/api/ping');
});

app.listen(7070, '192.168.1.1');
