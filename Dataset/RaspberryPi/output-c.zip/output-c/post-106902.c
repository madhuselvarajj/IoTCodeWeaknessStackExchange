    // accept one connection
    client = accept(s, (struct sockaddr *)&rem_addr, &opt);

    // read data from the client (Rx)
    bytes_read = read(client, buf, sizeof(buf));
    if( bytes_read > 0 ) {
        printf("received [%s]\n", buf);
        if(strncmp(buf[0], 'A', 1) == 0){    
            /* send a response to the client (Tx)
            At this time the client must be listening with the read() function 
            that you will have placed after the Tx function
            */
            write(client, "I receive 'A' char", 18);
        }else if(strncmp(buf[0], 'B', 1) == 0){ 
            /* send a response to the client (Tx)
            At this time the client must be listening with the read() function 
            that you will have placed after the Tx function
            */
            write(client, "I receive 'B' char", 18);
        }else{
            //...
        }
    }
