-c, --console=VTNUMBER
              Use the given VT number and not the first available. Note you
              must have write access to the supplied VT for this to work;
-f, --force
              Force opening a VT without checking whether it is already in
              use;
--     end of options to openvt. If openvt is compiled with a getopt_long() and you wish to set
       options to the command to be run, then you must supply the end of
       options -- flag before the command.
