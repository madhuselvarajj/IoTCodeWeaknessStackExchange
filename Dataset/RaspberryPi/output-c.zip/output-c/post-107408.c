#dtoverlay=spi1-1cs
#dtoverlay=spi2-1cs
dtoverlay=spi3-1cs
dtoverlay=spi4-1cs
dtoverlay=spi5-1cs
dtoverlay=spi6-1cs
