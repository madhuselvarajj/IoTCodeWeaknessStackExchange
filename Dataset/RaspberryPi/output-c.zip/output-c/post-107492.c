hostapd_logger: STA 98:0c:82:ba:7a:aa - sending 3/4 msg of 4-Way Handshake
WPA: Send EAPOL(version=2 secure=0 mic=1 ack=1 install=1 pairwise=1 kde_len=28 keyidx=0 encr=0)
WPA: Replay Counter - hexdump(len=8): 00 00 00 00 00 00 00 02
WPA: EAPOL-Key MIC using HMAC-SHA1
WPA: Use EAPOL-Key timeout of 1000 ms (retry counter 1)
l2_packet_receive: src=98:0c:82:ba:7a:aa len=99
wlan0: RX EAPOL from 98:0c:82:ba:7a:aa
IEEE 802.1X: 99 bytes from 98:0c:82:ba:7a:aa
   IEEE 802.1X: version=1 type=3 length=95
WPA: Received EAPOL-Key from 98:0c:82:ba:7a:aa key_info=0x10a type=254 mic_len=16 key_data_length=0
WPA: Received Key Nonce - hexdump(len=32): 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
WPA: Received Replay Counter - hexdump(len=8): 00 00 00 00 00 00 00 02
hostapd_logger: STA 98:0c:82:ba:7a:aa - received EAPOL-Key frame (4/4 Pairwise)
WPA: EAPOL-Key MIC using HMAC-SHA1
WPA: 98:0c:82:ba:7a:aa WPA_PTK entering state PTKINITDONE
