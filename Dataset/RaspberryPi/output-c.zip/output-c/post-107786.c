7.3.3 System Clock

The PCM1802 supports 256 fS, 384 fS, 512 fS, and 768 fS as the system clock, where fS is the audio sampling frequency. The system clock must be supplied on SCKI.

The PCM1802 has a system clock detection circuit which automatically senses if the system clock is operating at 256 fS, 384 fS, 512 fS, or 768 fS in slave mode. 

In master mode, the system clock frequency must be selected by MODE0 and MODE1, and 768 fS is not available. For system clock inputs of 384 fS, 512 fS, and 768 fS, the
system clock is divided to 256 fS automatically, and the 256 fS clock operates the delta-sigma modulator and the digital filter.
