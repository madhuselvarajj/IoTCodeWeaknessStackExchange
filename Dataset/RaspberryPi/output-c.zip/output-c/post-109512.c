   Author = {Derek Molloy},
   Title = {Exploring Raspberry Pi: Interfacing to the Real World with Embedded Linux},
   Publisher = {Wiley},
   Year = {2016},
   ISBN = {978-1-119-1868-1},
   URL = {http://www.exploringrpi.com/}
