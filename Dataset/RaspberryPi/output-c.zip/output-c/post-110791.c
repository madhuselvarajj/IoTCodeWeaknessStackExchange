def main():
    initSpiBusNameListMode00Speed100kHz('SpiFiveBusNameList')
    testReadMfrc522RegByName('SpiBus10', 'VersionReg')
    testReadMfrc522RegByName('SpiBus11', 'VersionReg')
    return

Sample Output
Run fnfc310.py    
     Begin Execute Function testReadMfrc522RegByName  2020-04-07 21:08               
       Function Name                           = testReadMfrc522RegByName
       Spi Bus Name                            = SpiBus10
       Dev Reg Name                            = VersionReg
       Dev Reg Addr                            = 0x37
       Dev Reg Contents                        = 0x92
     End   Execute Function testReadMfrc522RegByName  2020-04-07 21:08
     Begin Execute Function testReadMfrc522RegByName  2020-04-07 21:08
       Function Name                           = testReadMfrc522RegByName
       Spi Bus Name                            = SpiBus11
       Dev Reg Name                            = VersionReg
       Dev Reg Addr                            = 0x37
       Dev Reg Contents                        = 0x12
     End   Execute Function testReadMfrc522RegByName  2020-04-07 21:08  
