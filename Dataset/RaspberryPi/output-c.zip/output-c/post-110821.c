import cv2

cap = cv2.VideoCapture(0)

cap.set(3, 640)  # Set horizontal resolution
cap.set(4, 480)  # Set vertical resolution

_, img = cap.read()
cv2.imwrite("lower_res.jpeg", img)
