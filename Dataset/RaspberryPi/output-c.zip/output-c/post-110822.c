network={
        ssid="mywifi1"
        psk="psswd"
        key_mgmt=WPA-PSK
    id_str = "wlan1"

}

network={
        ssid="mywifi2"
        psk="passwd"
        key_mgmt=WPA-PSK
    id_str = "wlan2"

}
