if (setuid(getuid()) < 0)
{
        printf("Privilege change failed\n");
        exit(EXIT_FAILURE);
}
