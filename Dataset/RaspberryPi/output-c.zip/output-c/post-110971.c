network={
       ssid="Best Western Hotel"
       #psk="Room112passwd"
       psk=88aeedbf2750015a5a2ed81e6d71202f606aea4d646d03df6fef6012091f34f2
}
