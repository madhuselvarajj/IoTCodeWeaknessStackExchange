ctrl_interface=DIR=/var/run/wpa_supplicant 

GROUP=netdev
    update_config=1
    country=UK

network={
        ssid="laptop"
        id_str="laptopwifi"
        psk="pass123"
        priority=100
        key_mgmt=WPA-PSK
    }

network={
        ssid="home"
        id_str="home WiFi"
        psk="pass123"
        priority=99
        key_mgmt=WPA-PSK

}
