rpi ~$ iw dev
phy#0
        Unnamed/non-netdev interface
                wdev 0x2
                addr 42:43:06:8d:8c:0e
                type P2P-device
                txpower 31.00 dBm
        Interface wlan0
                ifindex 4
                wdev 0x1
                addr 02:e1:05:80:97:72
                ssid TestNet
                type managed
                channel 6 (2437 MHz), width: 20 MHz, center1: 2437 MHz
                txpower 31.00 dBm
