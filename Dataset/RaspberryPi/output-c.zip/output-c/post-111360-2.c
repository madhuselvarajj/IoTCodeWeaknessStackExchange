diskutil list
... 
(internal)
...
/dev/disk2 (external, physical):
   #:                       TYPE NAME                    SIZE       IDENTIFIER
   0:                                                   *64.1 GB    disk2
