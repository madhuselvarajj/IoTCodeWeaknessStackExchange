if(Mode == 0 || Mode == BCM2835_GPIO_FSEL_INPT){
    bcm2835_gpio_fsel(Pin, BCM2835_GPIO_FSEL_INPT);
    // Set GPIO pin to pull-up
    bcm2835_gpio_set_pud(Pin, BCM2835_GPIO_PUD_UP);
}
