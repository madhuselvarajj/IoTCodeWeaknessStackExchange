# force HDMI
hdmi_force_hotplug=1
# disable EDID
hdmi_ignore_edid=0xa5000080
# DMT group
hdmi_group=2
# 1366x768 60Hz 16:9
hdmi_mode=81
