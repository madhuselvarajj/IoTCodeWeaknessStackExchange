$ cat rsync-exclude.txt
/proc/*
/sys/*
/dev/*
/boot/*
/tmp/*
/run/*
/mnt/*
/media/*
/var/swap
/var/log/*
