network:
version: 2
ethernets:
    eth0:
        optional: true
        dhcp4: true
# add wifi setup information here ...
wifis:
    wlan0:
        optional: true
        access-points:
            "ssid":
                password: "123pass00"
        dhcp4: true
        dhcp6: true
