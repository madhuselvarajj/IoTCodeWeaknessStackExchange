>>> pi.hardware_PWM(18, 10000, 7733);pi.get_PWM_dutycycle(18)
0
7733
>>> pi.hardware_PWM(18, 10000, 72733);pi.get_PWM_dutycycle(18)
0
72733
>>> pi.hardware_PWM(18, 10000, 73);pi.get_PWM_dutycycle(18)
0
73
