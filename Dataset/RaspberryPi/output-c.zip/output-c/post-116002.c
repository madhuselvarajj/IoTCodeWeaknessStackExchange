SDA=2
SCL=3
baud=50000

pi.bb_i2c_open(SDA, SCL, baud)

# address 0x40            4 0x40
# start                   2
# write one byte 0xf1     7 1 0xf1
# restart                 2
# read 3 bytes            6 3
# stop                    3
# end                     0

cmd = [4, 0x40, 2, 7, 1, 0xf1, 2, 6, 3, 3, 0]

(count, data) = pi.bb_i2c_zip(SDA, cmd)

print(count, data)

# at the end of the session

pi.bb_i2c_close(SDA)
