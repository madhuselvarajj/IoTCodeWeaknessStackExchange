 config LEDS_TRIGGER_HEARTBEAT
    tristate "LED Heartbeat Trigger"
    help
      This allows LEDs to be controlled by a CPU load average.
      The flash frequency is a hyperbolic function of the 1-minute
      load average.
If unsure, say Y.
