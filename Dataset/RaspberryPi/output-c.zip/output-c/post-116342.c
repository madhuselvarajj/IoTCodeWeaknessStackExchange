#Ram Overclock 
sdram_freq=588 
sdram_schmoo=0x02000020 
over_voltage_sdram_p=6 
over_voltage_sdram_i=4 
over_voltage_sdram_c=4 
