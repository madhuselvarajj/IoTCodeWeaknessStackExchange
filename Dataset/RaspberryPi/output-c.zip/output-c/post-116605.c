pi@raspberry:~ $ sudo apt install screenfetch
Reading package lists... Done
Building dependency tree       
Reading state information... Done
...
Unpacking screenfetch (3.7.0-1) ...
Setting up screenfetch (3.7.0-1) ...
Processing triggers for man-db (2.7.6.1-2) ...

pi@raspberry:~ $ screenfetch 
    .',;:cc;,'.    .,;::c:,,.    pi@pi-boxcalmeas-05
   ,ooolcloooo:  'oooooccloo:    OS: Raspbian 9.13 stretch
   .looooc;;:ol  :oc;;:ooooo'    Kernel: armv7l Linux 4.19.66-v7+
     ;oooooo:      ,ooooooc.     Uptime: 1d 31m
       .,:;'.       .;:;'.       Packages: 1320
       .... ..'''''. ....        Shell: 3557
     .''.   ..'''''.  ..''.      Resolution: 1024x768
     ..  .....    .....  ..      DE: LXDE
    .  .'''''''  .''''''.  .     WM: OpenBox
  .'' .''''''''  .'''''''. ''.   CPU: ARMv7 rev 4 (v7l) @ 1.4GHz
  '''  '''''''    .''''''  '''   GPU: Gallium 0.4 on llvmpipe (LLVM 3.9, 128 bits)
  .'    ........... ...    .'.   RAM: 153MiB / 926MiB
    ....    ''''''''.   .''.    
    '''''.  ''''''''. .'''''    
     '''''.  .'''''. .'''''.    
      ..''.     .    .''..      
            .'''''''            
             ......       

