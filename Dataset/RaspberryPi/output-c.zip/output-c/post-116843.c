pi@raspberrypi4b:~ pi@raspberrypi4b:~ $ bluetoothctl
Agent registered
[bluetooth]# list
Controller DC:A6:32:02:F0:97 raspberrypi4b [default]
[bluetooth]# show
Controller DC:A6:32:02:F0:97 (public)
    Name: raspberrypi4b
    Alias: raspberrypi4b
    Class: 0x000c0000
    Powered: yes
    Discoverable: no
    Pairable: yes
    UUID: Headset AG                (00001112-0000-1000-8000-00805f9b34fb)
    UUID: Generic Attribute Profile (00001801-0000-1000-8000-00805f9b34fb)
    UUID: A/V Remote Control        (0000110e-0000-1000-8000-00805f9b34fb)
    UUID: Generic Access Profile    (00001800-0000-1000-8000-00805f9b34fb)
    UUID: PnP Information           (00001200-0000-1000-8000-00805f9b34fb)
    UUID: A/V Remote Control Target (0000110c-0000-1000-8000-00805f9b34fb)
    UUID: Audio Source              (0000110a-0000-1000-8000-00805f9b34fb)
    UUID: Audio Sink                (0000110b-0000-1000-8000-00805f9b34fb)
    UUID: Headset                   (00001108-0000-1000-8000-00805f9b34fb)
    Modalias: usb:v1D6Bp0246d0532
    Discovering: no
...
[bluetooth]# devices
Device B8:F6:53:12:13:F1 JBL Flip 5
...
[bluetooth]# info B8:F6:53:12:13:F1
Device B8:F6:53:12:13:F1 (public)
    Name: JBL Flip 5
    Alias: JBL Flip 5
    Class: 0x00240414
    Icon: audio-card
    Paired: yes
    Trusted: yes
    Blocked: no
    Connected: no
    LegacyPairing: no
    UUID: Serial Port               (00001101-0000-1000-8000-00805f9b34fb)
    UUID: Audio Sink                (0000110b-0000-1000-8000-00805f9b34fb)
    UUID: A/V Remote Control Target (0000110c-0000-1000-8000-00805f9b34fb)
    UUID: A/V Remote Control        (0000110e-0000-1000-8000-00805f9b34fb)
    ManufacturerData Key: 0x0057
    ManufacturerData Value:
  31 1f 01 18 8d 00                                1.....
    ServiceData Key: 0000fddf-0000-1000-8000-00805f9b34fb

