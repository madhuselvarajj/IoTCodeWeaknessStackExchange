root@pitest:~# ifconfig mon0
mon0: flags=4098<BROADCAST,MULTICAST>  mtu 1500
        unspec 00-36-76-B0-23-61-00-00-00-00-00-00-00-00-00-00  txqueuelen 1000  (UNSPEC)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 0  bytes 0 (0.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
