[bluetooth]# scan on
--- snip ---
[bluetooth]# scan off
--- snip ---
[bluetooth]# devices
Device 14:A3:64:06:9F:DB Ingo (Galaxy S5)

[bluetooth]# trust 14:A3:64:06:9F:DB
[CHG] Device 14:A3:64:06:9F:DB Trusted: yes
Changing 14:A3:64:06:9F:DB trust succeeded

[bluetooth]# pair 14:A3:64:06:9F:DB
--- snip ---
Pairing successful
[CHG] Device 14:A3:64:06:9F:DB ServicesResolved: no
[CHG] Device 14:A3:64:06:9F:DB Connected: no

[bluetooth]# connect 14:A3:64:06:9F:DB
Attempting to connect to 14:A3:64:06:9F:DB
[CHG] Device 14:A3:64:06:9F:DB Connected: yes
Connection successful
[CHG] Device 14:A3:64:06:9F:DB ServicesResolved: yes
[Ingo (Galaxy S5)]
