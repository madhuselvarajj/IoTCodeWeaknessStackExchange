3: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
link/ether 02:81:79:1b:3c:09 brd ff:ff:ff:ff:ff:ff
inet 192.168.1.3/24 brd 192.168.1.255 scope global eth0
   valid_lft forever preferred_lft forever
inet 192.168.1.13/24 brd 192.168.1.255 scope global secondary noprefixroute eth0
   valid_lft forever preferred_lft forever
inet6 fe80::81:79ff:fe1b:3c09/64 scope link 
   valid_lft forever preferred_lft forever
4: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
link/ether 12:81:79:1b:3c:09 brd ff:ff:ff:ff:ff:ff
inet 192.168.1.2/24 brd 192.168.1.255 scope global wlan0
   valid_lft forever preferred_lft forever
inet 192.168.1.13/24 brd 192.168.1.255 scope global secondary noprefixroute wlan0 valid_lft forever preferred_lft forever
inet6 fe80::1081:79ff:fe1b:3c09/64 scope link 
   valid_lft forever preferred_lft forever
