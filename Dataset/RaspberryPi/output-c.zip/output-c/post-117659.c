var displayDate = 0; // the date to be displayed

setInterval(() => {
  displayDate++;
}, 1000);
