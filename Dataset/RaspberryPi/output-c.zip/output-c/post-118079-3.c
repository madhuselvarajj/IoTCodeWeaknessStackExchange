connection.on( 'connect', () => {
  isConnectionActive = true;
  connection.emit( 'led-toggle', {
      r: button_red_state,
      g: button_green_state,
      b: button_blue_state,
  } );
} );
