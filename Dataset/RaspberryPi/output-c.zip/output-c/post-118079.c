// toggle LED states
exports.toggle = ( r, g, b ) => {
  pin_red.writeSync( r ? 1 : 0 );
  pin_green.writeSync( g ? 1 : 0 );
  pin_blue.writeSync( b ? 1 :0 );
};
