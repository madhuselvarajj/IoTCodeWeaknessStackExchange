# Define simple sequence
StepCount1 = 4
Seq1 = []
Seq1 = range(0, StepCount1)
Seq1[0] = [1,0,1,0]
Seq1[1] = [0,1,1,0]
Seq1[2] = [0,1,0,1]
Seq1[3] = [1,0,0,1]
