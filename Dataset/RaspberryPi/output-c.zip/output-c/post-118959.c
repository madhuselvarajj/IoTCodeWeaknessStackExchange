[EDID=ASUS_PA238]
hdmi_ignore_edid=0xa5000080
hdmi_group=2
hdmi_mode=82
hdmi_drive=2
