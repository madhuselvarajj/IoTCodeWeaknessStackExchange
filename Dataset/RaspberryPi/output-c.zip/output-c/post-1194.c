void outb_pi(unsigned char val)
{
  // Set all the bits in val that are 1
  GPIO_SET = val;
  // Clear all the bits in val that are 0
  GPIO_CLR = ~val;
}
