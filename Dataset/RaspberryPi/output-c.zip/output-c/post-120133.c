import time
import rgpio

L1=16
L2=26

sbc = rgpio.sbc()
h = sbc.gpiochip_open(0)

sbc.gpio_claim_output(h, L1)
sbc.gpio_claim_output(h, L2)

sbc.tx_pwm(h, L1, 10, 50)
sbc.tx_pwm(h, L2, 10, 50, pulse_offset=50000)

time.sleep(20)

sbc.gpiochip_close(h)
sbc.stop()
