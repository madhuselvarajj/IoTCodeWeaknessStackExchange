1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq master br0 state UP group default qlen 1000
    link/ether dc:a6:32:07:55:6f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dea6:32ff:fe07:556f/64 scope link 
       valid_lft forever preferred_lft forever
3: br0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f2:ea:7e:5b:ba:a4 brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.12/24 brd 192.168.1.255 scope global dynamic noprefixroute br0
       valid_lft 843201sec preferred_lft 735201sec
    inet6 2001:4dd5:4075:0:10d:3893:d2:e632/64 scope global dynamic mngtmpaddr noprefixroute 
       valid_lft 7115sec preferred_lft 3515sec
    inet6 fe80::d847:a8aa:3a86:c9d0/64 scope link 
       valid_lft forever preferred_lft forever
4: wlan0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether dc:a6:32:07:55:70 brd ff:ff:ff:ff:ff:ff
