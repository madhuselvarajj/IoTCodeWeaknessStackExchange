...
MMAL_CONNECTION_T *preview_connection; // Global variable

...
MMAL_STATUS_T connect_ports(MMAL_PORT_T * output_port, MMAL_PORT_T * input_port, MMAL_CONNECTION_T ** connection) {
  MMAL_STATUS_T status;
  status = mmal_connection_create(connection, output_port, input_port, MMAL_CONNECTION_FLAG_TUNNELLING | MMAL_CONNECTION_FLAG_ALLOCATION_ON_INPUT);
  if (status == MMAL_SUCCESS) {
    status = mmal_connection_enable( * connection);
    if (status != MMAL_SUCCESS) mmal_connection_destroy( * connection);
  }
  return status;
}

...

int main() {
  MMAL_PORT_T * camera_preview_port = NULL;
  MMAL_PORT_T * preview_input_port = NULL;
  std::cout << mmal_status_to_string(create_camera_component());
  std::cout << mmal_status_to_string(raspipreview_create());
  camera_preview_port = camera_component -> output[0];
  preview_input_port = preview_component -> input[0];
  connect_ports(camera_preview_port, preview_input_port, & preview_connection);
  sleep(10);
  destroy_camera_component();
  raspipreview_destroy();
  return 0;
}
