1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether b8:27:eb:4e:c3:b6 brd ff:ff:ff:ff:ff:ff
3: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether b8:27:eb:1b:96:e3 brd ff:ff:ff:ff:ff:ff
    inet 192.168.43.78/24 brd 192.168.43.255 scope global dynamic wlan0
       valid_lft 3318sec preferred_lft 3318sec
4: vlan0@wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether b8:27:eb:1b:96:e3 brd ff:ff:ff:ff:ff:ff
    inet 192.168.43.76/24 brd 192.168.43.255 scope global dynamic vlan0
       valid_lft 3318sec preferred_lft 3318sec
