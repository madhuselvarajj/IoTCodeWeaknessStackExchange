0 = LOG_EMERG      system is unusable
1 = LOG_ALERT      action must be taken immediately
2 = LOG_CRIT       critical conditions
3 = LOG_ERR        error conditions
4 = LOG_WARNING    warning conditions
5 = LOG_NOTICE     normal, but significant, condition
6 = LOG_INFO       informational message
7 = LOG_DEBUG      debug-level message
