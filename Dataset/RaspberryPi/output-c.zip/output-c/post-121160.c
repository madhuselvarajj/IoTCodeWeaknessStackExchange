while(1){
  gpioInitialise();
  gpioSetMode(pin, mode);
  ...
  gpioWaveTxSend(waveID, PI_WAVE_MODE_ONE_SHOT);
  gpioTerminate();

  initLEDsPWM(nbLeds);
  ...
  showLEDs();
  endLEDs();
}
