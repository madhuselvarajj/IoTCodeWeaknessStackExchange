> ip link                                                                                                              
2: eno1: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast state DOWN mode DEFAULT group default qlen 1000               
    link/ether c8:60:00:8a:50:39 brd ff:ff:ff:ff:ff:ff                                                                 
    altname enp0s25 
                                                                                                   
> ip link set eno1 up                                                                                                  
2: eno1: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc pfifo_fast state DOWN mode DEFAULT group default qlen 1000 
    link/ether c8:60:00:8a:50:39 brd ff:ff:ff:ff:ff:ff                                                                 
    altname enp0s25                                                                                                    
