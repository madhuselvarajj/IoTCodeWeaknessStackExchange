$.ajax ({
    url: /request/path,
    success: function (data) {
        // Update the page with 'data'
    }
})
