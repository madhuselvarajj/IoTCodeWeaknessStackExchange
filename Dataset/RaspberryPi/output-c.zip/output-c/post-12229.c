<script type="text/javascript">
    setTimeout (
        function() { window.location.reload(); },
        500
    )
</script>
