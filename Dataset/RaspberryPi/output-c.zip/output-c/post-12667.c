// Create object.
        BMP085 *bcm = new BMP085();
        if (!bcm->ok) {
                cerr << bcm->err << endl;
                return 1;
        }
// Take reading, report, and repeat ad infititum.
        BMP085::reading data = bcm->getBoth();
        cout << "Relative altitude at " << data.kPa << " kPa: "
                << BMP085::getRelativeAltitude(data.kPa) << "m.\n";
        while (1) {
                cout << "\rTemperature: " << data.celcius << " °C    "
                        << "Pressure: " << data.kPa << " kPa         " << flush;
                data = bcm->getBoth();
                sleep(2);
        }
