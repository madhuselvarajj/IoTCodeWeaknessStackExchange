Enabling fuzzy format match...
Parsing edid.dat2...
HDMI:EDID version 1.3, 1 extensions, screen size 22x13 cm
HDMI:EDID features - videodef 0x80 standby suspend active off; colour encoding:RGB444|YCbCr422; sRGB is not default colourspace; preferred format is native; does not support GTF
HDMI:EDID found monitor S/N descriptor tag 0xff
HDMI:EDID found monitor name descriptor tag 0xfc
HDMI:EDID monitor name is MotoLD2S_____þ
HDMI:EDID does not yet know monitor vertical range, setting to default 24 to 120Hz
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:72 MHz
HDMI:EDID calculated refresh rate is 57 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found preferred DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:75 MHz
HDMI:EDID calculated refresh rate is 60 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID established timing I/II bytes are 00 00 00
HDMI:EDID standard timings block x 8: 0x0101 0101 0101 0101 0101 0101 0101 0101 
HDMI:EDID parsing v3 CEA extension 0
HDMI:EDID monitor support - underscan IT formats:no, basic audio:yes, yuv444:yes, yuv422:yes, #native DTD:0
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:72 MHz
HDMI:EDID calculated refresh rate is 57 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:75 MHz
HDMI:EDID calculated refresh rate is 60 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:72 MHz
HDMI:EDID calculated refresh rate is 57 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:72 MHz
HDMI:EDID calculated refresh rate is 57 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID failed to find a matching detail format for 1366x768p hfp:59 hs:39 hbp:96 vfp:5 vs:9 vbp:24 pixel clock:72 MHz
HDMI:EDID calculated refresh rate is 57 Hz
HDMI:EDID guessing the format to be 1366x768p @60 Hz
HDMI:EDID found DMT detail timing format: 1366x768p @ 60 Hz (81)
HDMI:EDID found CEA format: code 2, 720x480p @ 60Hz 
HDMI:EDID found audio format 2 channels PCM, sample rate: 44 kHz, sample size: 16 bits
HDMI:EDID found HDMI VSDB length 5
HDMI:EDID HDMI VSDB has physical address 1.0.0.0
HDMI:EDID HDMI VSDB has no extension fields
HDMI:EDID adding mandatory support for DMT (4) 640x480p @ 60Hz
HDMI:EDID adding mandatory support for CEA (1) 640x480p @ 60Hz
HDMI:EDID adding mandatory support for CEA (3) 720x480p @ 60Hz
HDMI:EDID filtering formats with pixel clock > 162 MHz or h. blanking > 1023
HDMI:EDID best score mode initialised to DMT (4) 640x480p @ 60 Hz with pixel clock 25 MHz (score 0)
HDMI:EDID best score mode is now CEA (1) 640x480p @ 60 Hz with pixel clock 25 MHz (score 43432)
HDMI:EDID best score mode is now CEA (2) 720x480p @ 60 Hz with pixel clock 27 MHz (score 45736)
HDMI:EDID CEA mode (3) 720x480p @ 60 Hz with pixel clock 27 MHz has a score of 45736
HDMI:EDID DMT mode (4) 640x480p @ 60 Hz with pixel clock 25 MHz has a score of 36864
HDMI:EDID best score mode is now DMT (81) 1366x768p @ 60 Hz with pixel clock 85 MHz (score 5188835)
HDMI:EDID preferred mode remained as DMT (81) 1366x768p @ 60 Hz with pixel clock 85 MHz
HDMI:EDID has HDMI support and audio support
edid_parser exited with code 0
