network={
    ssid="static-wep-test"
    key_mgmt=NONE
    wep_key0="abcde"
    wep_key1=0102030405
    wep_tx_keyidx=0
    priority=5
}
