sqlite> select * from files where strFilename like %Recreation%';
   ...> 
   ...> ;
   ...> ;
   ...> .quit
   ...> ;
   ...> .exit
   ...> ;
   ...> 
   ...> ;
   ...> 
Error: incomplete SQL: select * from files where strFilename like %Recreation%';

;
;
.quit
;
.exit
;

;
pi@raspbmc:~/.xbmc/userdata/Database$
