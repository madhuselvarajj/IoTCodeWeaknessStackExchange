import sys 
sys.stderr = sys.stdout
try:
    import RPi.GPIO as GPIO
except Exception as e:
    print e
