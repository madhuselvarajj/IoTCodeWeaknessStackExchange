// ... other code
System.out.println("Stopping audio");

// Mute the clip
BooleanControl muteControl = (BooleanControl) clip.getControl(BooleanControl.Type.MUTE);
if(muteControl != null){
    muteControl.setValue(true); // True to mute the line, false to unmute
}

clip.loop(0); // Stops the sound after it runs through its buffer
clip.flush();
