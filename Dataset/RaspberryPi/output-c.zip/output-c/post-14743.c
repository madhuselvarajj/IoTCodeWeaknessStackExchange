<script>
$(document).ready(function(){

 $('#left_button').click(function(){

   $.post( "/robot_left.php", function( data ) {
     //Data will contain whatever the response is, or JSON and will be parsed to object
     //But you can leave this empty if you not passing data back to the client.
   });

  });

 });
 </script>
