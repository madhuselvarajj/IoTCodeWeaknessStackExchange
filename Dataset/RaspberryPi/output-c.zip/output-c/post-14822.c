
"controls" : {
    "servos_cron": {
      "on" : "crontab -l | sed '/servos/s/^#//' | crontab -",
      "off" : "crontab -l | sed '/^\*.*servos/s/^/#/' | crontab -"
    }
  }
