    <?php
    $path='/var/www/cron_onoff.txt';
    $text=$_GET['arg'];
    shell_exec('echo '.$text.' > '.$path);
    ?>
