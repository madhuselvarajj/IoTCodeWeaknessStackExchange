    $ dmesg

...
usb 1-1.2: new high speed USB device number 4 using dwc_otg
usb 1-1.2: New USB device found, idVendor=0ace, idProduct=1215
usb 1-1.2: New USB device strings: Mfr=16, Product=32, SerialNumber=0
usb 1-1.2: Product: USB2.0 WLAN
usb 1-1.2: Manufacturer: ZyDAS
cfg80211: Calling CRDA to update world regulatory domain
usb 1-1.2: reset high speed USB device number 4 using dwc_otg
ieee80211 phy0: Selected rate control algorithm 'minstrel_ht'
zd1211rw 1-1.2:1.0: phy0
usbcore: registered new interface driver zd1211rw
zd1211rw 1-1.2:1.0: firmware version 4725
zd1211rw 1-1.2:1.0: zd1211b chip 0ace:1215 v4810 high 00-1a-ee UW2453_RF pa0 -7---
...
