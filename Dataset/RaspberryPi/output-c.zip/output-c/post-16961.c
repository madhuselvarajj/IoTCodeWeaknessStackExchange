# Perform each of the following using sudo
ifconfig wlan0 up
iwconfig wlan0 mode ad-hoc
iwconfig wlan0 essid "Pi"
ifconfig wlan0 192.168.1.1 netmask 255.255.255.0
