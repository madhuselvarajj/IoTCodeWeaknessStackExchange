"name" : "RISC OS",
"partitions" : [
  "/dev/mmcblk0p5",
  "/dev/mmcblk0p6"
],
...
