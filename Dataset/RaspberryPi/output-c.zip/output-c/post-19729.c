network={
 ssid="Your SSID Name"
 proto=RSN
 key_mgmt=WPA-PSK
 pairwise=CCMP TKIP
 group=CCMP TKIP
 psk="your-pass-key"
}
