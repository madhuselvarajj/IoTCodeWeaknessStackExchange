    // create gpio controller
    log("trying to get gpio controller... ");
    Thread.sleep(1000);
    final GpioController gpio = GpioFactory.getInstance();
    if (gpio != null)
        log("opened gpio controller");
    else {
        //try again later if you want 
        log("failed to get gpio controller");
        System.exit(1);
    }
