if (pin === 7){
    //Set pin 7 low (0)
    gpio.write(7, 0, function() 
    { 
            gpio.close(7);
        return gpio;
    } );    // <----
} if (pin === 11){
