s = {"text":lcd_text, "line":4}
send_to_pipe(s)

hour = time.strftime("%H:%M:%S")
date = time.strftime("%d.%m.%Y")
s = {"text":date + " " + hour, "line":1}
send_to_pipe(s)

time.sleep(0.25)
