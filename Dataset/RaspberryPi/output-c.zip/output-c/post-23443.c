arm_freq=700
arm_freq_min=100
core_freq=250
core_freq_min=75
sdram_freq=400
over_voltage=0
