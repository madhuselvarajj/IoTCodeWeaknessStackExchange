#pikeyd.conf

#format:
# {keycode from /usr/include/linux/input.h} {GPIO pin no}
# Not limited to a single key. A GPIO press will emit all defined keys in order.
KEY_UP         8
KEY_DOWN       7
KEY_LEFT        17
KEY_RIGHT       11
KEY_1  24
KEY_ESC 18

KEY_5 25
KEY_2 22
KEY_LEFTCTRL 27
KEY_LEFTALT 4

KEY_ENTER 3
