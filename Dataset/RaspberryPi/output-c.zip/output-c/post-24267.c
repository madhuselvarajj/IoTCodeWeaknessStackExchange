# Zone Set Up
zone domain.tld {
       primary 10.1.0.1;
}


# Additional Information
ddns-domainname "domain.tld";
ddns-rev-domainname "in-addr.arpa.";
option domain-name "domain.tld";
option domain-name-servers 10.1.0.1;
option broadcast-address 10.1.0.255;

# Routes
option classless-static-routes
                            0,      0,0,0,0,
                            0,      10,1,0,1,
                            24,     10,1,0,         10,1,0,1;

# Push Routes to Clients
subnet 10.1.0.0 netmask 255.255.255.0 {
        range 10.1.0.100 10.1.0.254;
        option routers 10.1.0.1;
        zone 0.1.10.in-addr.arpa. {
                primary 10.1.0.1;
        }
        zone domain.tld. {
                primary 10.1.0.1;
        }
}
