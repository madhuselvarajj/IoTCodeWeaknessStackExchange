#include <sys/types.h>
#include <pwd.h>

struct passwd *info = getpwnam("pi");
printf("UID is %d\n", info->pw_uid);   
