$ ntpq -c rl
associd=0 status=0615 leap_none, sync_ntp, 1 event, clock_sync,
version="ntpd 4.2.6p5@1.2349-o Mon Jul 18 09:22:49 UTC 2013 (1)",
processor="x86_64", system="Linux/2.6.32-431.29.2.el6.x86_64", leap=00,
stratum=4, precision=-21, rootdelay=40.242, rootdisp=315.102,
refid=192.168.1.123,
reftime=d82131cd.fbb96c5e  Thu, Nov 27 2014 13:14:53.983,
clock=d82138e6.fd03bdd1  Thu, Nov 27 2014 13:45:10.988, peer=61770, tc=9,
mintc=3, offset=5.214, frequency=52.475, sys_jitter=12.217,
clk_jitter=23.319, clk_wander=1.373
$
