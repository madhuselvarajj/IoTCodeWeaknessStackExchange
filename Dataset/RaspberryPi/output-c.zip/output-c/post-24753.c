#include <bcm2835.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void on () {
        bcm2835_gpio_fsel(0, BCM2835_GPIO_FSEL_INPT);
        bcm2835_gpio_fsel(1, BCM2835_GPIO_FSEL_INPT);

        bcm2835_gpio_fsel(28, BCM2835_GPIO_FSEL_ALT0);
        bcm2835_gpio_set_pud(28, BCM2835_GPIO_PUD_UP);

        bcm2835_gpio_fsel(29, BCM2835_GPIO_FSEL_ALT0);
        bcm2835_gpio_set_pud(29, BCM2835_GPIO_PUD_UP);
}

int main (int argc, const char *argv[]) {
        if (argc != 2) {
                puts("On or off?");
                exit(1);
        }

        bcm2835_init();

        if (!strcmp(argv[1], "on")) on();
        else puts("What?");

        bcm2835_close();
        return 0;
}
