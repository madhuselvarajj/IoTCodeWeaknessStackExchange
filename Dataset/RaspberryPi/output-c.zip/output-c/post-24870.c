P - 0 - turning system off    
    1 - turning system on

M - Mode of airconditioner
    1000 - Auto
    0100 - Dehumidify
    1100 - Cool
    0010 - Heat

S - 0 - Normal fan  
    1 - Powerful

V - 1000 - Normal Use
    1111 - Vanes rotating

T - Temperature - here it appears to be 5 bits long.  Take 10 degrees off the temp in celsius convert to binary and reverse the bit.  The temps available only run from 18 to 28.
    18 - 00010
    19 - 10010
    20 - 01010
    21 - 11010
    22 - 00110
    23 - 10110
    24 - 01110
    25 - 11110
    26 - 00001
    27 - 10001
    28 - 01001

F - Fan Speed
    Auto - 0101
    1    - 1100
    2    - 0010
    3    - 1010
    4    - 0110
    5    - 1110
