#pi.wave_clear()
pi.wave_add_generic(square)

wid = pi.wave_create()

if wid >= 0:
  pi.wave_send_once(wid)
