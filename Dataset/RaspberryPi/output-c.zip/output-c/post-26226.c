option domain-name-servers 10.22.0.1, 8.8.8.8, 8.8.4.4;
authoritative;
subnet 10.22.0.0 netmask 255.255.255.192
{
    range 10.22.0.32 10.22.0.62;
    option routers 10.22.0.1;
}
