
    int nBytes = nLEDs * 3;
    char * strip = calloc(nBytes, sizeof(char));
    ... fill the array here ...
    bcm2835_spi_writenb(strip, nBytes); // write out the colors
