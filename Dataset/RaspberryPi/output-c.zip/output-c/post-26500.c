
if (!bcm2835_init())
{
    printf("Failure to initialize the bcm2835 library\n");
    return 1;
}
printf("Initializing Interface\n");
bcm2835_spi_begin();  // see http://www.airspayce.com/mikem/bcm2835/group__spi.html
bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);    // The default    
bcm2835_spi_setDataMode(BCM2835_SPI_MODE0);                 // The default    
bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_64);  // 64 = 256ns = 3.90625MHz  (under 25MHZ)
bcm2835_spi_chipSelect(BCM2835_SPI_CS_NONE);                // Not selecting a specific chip
bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);      // the default    
