pi@raspifix ~ $ free
             total       used       free     shared    buffers     cached
Mem:        496592     430080      66512          0     112996     230412
-/+ buffers/cache:      86672     409920
Swap:            0          0          0
