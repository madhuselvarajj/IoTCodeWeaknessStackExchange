temps = instrument.read_registers(30001, 4, 3) # address, count, function code (3 or 4)
print temps
coil = instrument.read_bit(10001, 1) # address, function code (1 or 2), generates error
print coil
instrument.write_bit(10001, 1, 5) # address, value, function code (5 or 15)
instrument.write_register(40001, 2, 0, 6, False) # address, value, number of decimals, function code, signed)
