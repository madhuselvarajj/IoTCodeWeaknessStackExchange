auto myButton = GPIO::openGPIO(3, GPIO_INPUT);
while (true) {
    myButton->waitForEdge(GPIO_EDGE_RISING);
    cout << "Button pressed!" << endl;
}
