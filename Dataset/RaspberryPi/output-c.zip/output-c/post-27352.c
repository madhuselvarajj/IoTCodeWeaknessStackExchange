dnsmasq-dhcp[2358]: DHCPREQUEST(eth2) 10.79.26.137 ac:87:xx:xx:xx:xx
dnsmasq-dhcp[2358]: DHCPACK(eth2) 10.79.26.137 ac:87:xx:xx:xx:xx Maxwell
dnsmasq-dhcp[2358]: DHCPDISCOVER(eth2) b8:27:xx:xx:xx:xx 
dnsmasq-dhcp[2358]: DHCPOFFER(eth2) 10.79.26.148 b8:27:xx:xx:xx:xx 
dnsmasq-dhcp[2358]: DHCPREQUEST(eth2) 10.79.26.148 b8:27:xx:xx:xx:xx 
dnsmasq-dhcp[2358]: DHCPACK(eth2) 10.79.26.148 b8:27:xx:xx:xx:xx raspberrypi 
