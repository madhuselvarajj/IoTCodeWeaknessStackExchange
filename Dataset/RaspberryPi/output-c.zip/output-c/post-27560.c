#include <linux/jiffies.h>

extern unsigned long volatile jiffies;

static irqreturn_t irq_handler(int irq, void *dev_id, struct pt_regs *regs) {

   static unsigned long old_jiffie = 0;
   unsigned long diff = jiffies - old_jiffie;
   if (diff < 20)
   {
     return IRQ_HANDLED;
   }

   printk(KERN_NOTICE "Interrupt [%d] for device %s was triggered, jiffies=%lu, diff=%lu, direction: %d \n",
          irq, (char *) dev_id, jiffies, diff, gpio_get_value(GPIO_BUTTON1));

   old_jiffie = jiffies;
   return IRQ_HANDLED;
}
