My IP address is 10.1.1.8

Raspbian GNU/Linux 7 raspberrypi tty1

raspberrypi login:
