> free
             total       used       free 
Mem:        448376     401792      46584 
-/+ buffers/cache:      55896     392480
                        ^^^^^
