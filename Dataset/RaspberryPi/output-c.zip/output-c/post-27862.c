<?php
$ip = '192.168.100.';

for ($i=0; $i < 256; $i++) { 
    $sock = @fsockopen( $ip . $i, 22, $errnr, $errstr, .5);
    if ($sock !== false) {
        echo ">> " . $ip.$i. PHP_EOL;
    }
}
