static void bcm2708_set_gpio_alt(int pin, int alt)
{
    /*
     * This is the common way to handle the GPIO pins for
     * the Raspberry Pi.
     * TODO This is a hack. Use pinmux / pinctrl.
     */
#define INP_GPIO(g) *(gpio+((g)/10)) &= ~(7<<(((g)%10)*3))
#define SET_GPIO_ALT(g,a) *(gpio+(((g)/10))) |= (((a)<=3?(a)+4:(a)==4?3:2)        <<(((g)%10)*3))
    unsigned int *gpio;
    gpio = ioremap(GPIO_BASE, SZ_16K);
    INP_GPIO(pin);
    SET_GPIO_ALT(pin, alt);
    iounmap(gpio);
#undef INP_GPIO
#undef SET_GPIO_ALT
}
