RPi> su – root
RPi> xauth list

10-111-11-11/unix:10 MIT-MAGIC-COOKIE-1 cf4967d5a6c0e6d5f33285aa0e483643

RPi> su – <user> (probably "pi")
RPi> xauth add 10-111-11-11/unix:10 MIT-MAGIC-COOKIE-1 cf4967d5a6c0e6d5f33285aa0e483643
