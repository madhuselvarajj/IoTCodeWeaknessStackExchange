  def turn_1_off
    @pin11.on
    puts "Pin11 now has value #{@pin11.value}"
    @pin13.off # <---- PIN 13 is off!
    puts "Pin13 now has value #{@pin13.value}"
    @pin15.on
    puts "Pin15 now has value #{@pin15.value}"
    @pin16.on
    puts "Pin16 now has value #{@pin16.value}"
    sleep(0.1)
    @pin22.on
    sleep(0.25)
    @pin22.off
  end
