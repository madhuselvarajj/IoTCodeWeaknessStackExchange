HTTP Basic Authentication:
       You  can  optionally  require  client  authentication by specifying one
       password for the 'user' user and one password  for  the  'admin'  user.
       Once  authenticated,  'admin' is allowed to access all the pages on the
       server. 'user' is allowed to access all the  pages  on  the  server  as
       well, but if both 'admin' and 'user' authentications are required, then
       only 'admin' is allowed to access the Control Panel page:

       --user-password arg
              require the client to provide the specified password for the
              'user' username
