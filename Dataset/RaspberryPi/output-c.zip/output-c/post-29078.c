Disk 2015-01-31-raspbian.img: 3.1 GiB, 3276800000 bytes, 6400000 sectors
Units: sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 512 bytes
I/O size (minimum/optimal): 512 bytes / 512 bytes
Disklabel type: dos
Disk identifier: 0x00092fac

Device                   Boot     Start       End  Blocks  Id System
2015-01-31-raspbian.img1           8192    122879   57344   c W95 FAT32 (LBA)
2015-01-31-raspbian.img2         122880   6399999 3138560  83 Linux
