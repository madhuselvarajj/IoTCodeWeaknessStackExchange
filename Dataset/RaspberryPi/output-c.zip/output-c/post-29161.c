uint32_t bcm2835_peri_read(volatile uint32_t* paddr)
{
    if (debug)
    { [...] }
    else
    {
    // Make sure we dont return the _last_ read which might get lost
    // if subsequent code changes to a different peripheral
    uint32_t ret = *paddr;
    *paddr; // Read without assigning to an unused variable
    return ret;
    }
}
