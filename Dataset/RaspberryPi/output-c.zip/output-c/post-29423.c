import Camera

if __name__ == '__main__':
    cam = Camera.image().On();
    cam.clean();
    cam.setlocation("test");
    cam.capture("GeneralTest.jpg");
    cam.clean();
