#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    printf("Hello, World!\n");
    exit(EXIT_SUCCESS);
}
