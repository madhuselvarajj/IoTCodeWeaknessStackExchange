sudo -i
ifconfig wlan0 up
iwconfig wlan0 mode ad-hoc
iwconfig wlan0 essid "YOUR_SSID"
ifconfig wlan0 192.168.1.1 netmask 255.255.255.0
