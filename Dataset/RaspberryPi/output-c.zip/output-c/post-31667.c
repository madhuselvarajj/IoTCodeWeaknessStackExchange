$ apt-cache search qt5
...
libqt5gui5 - Qt 5 GUI module
libqt5help5 - Qt 5 help module
libqt5keychain0 - Qt API to store passwords (QT5 version)
libqt5multimedia5 - Qt 5 Multimedia module
libqt5multimedia5-plugins - Qt 5 Multimedia module plugins
libqt5multimediaquick-p5 - Qt 5 Multimedia Quick module
libqt5multimediawidgets5 - Qt 5 Multimedia Widgets module
libqt5network5 - Qt 5 network module
libqt5nfc5 - Qt Connectivity NFC module
libqt5opengl5 - Qt 5 OpenGL module
libqt5opengl5-dev - Qt 5 OpenGL library development files
libqt5positioning5 - Qt Positioning module
libqt5positioning5-plugins - Qt Positioning module - position plugins
libqt5printsupport5 - Qt 5 print support module
libqt5qml5 - Qt 5 QML module
libqt5quick5 - Qt 5 Quick library
libqt5quickparticles5 - Qt 5 Quick particules module
libqt5quicktest5 - Qt 5 Quick Test library
libqt5quickwidgets5 - Qt 5 Quick Widgets library
libqt5scintilla2-11 - Qt5 port of the Scintilla source code editing widget
libqt5scintilla2-11-dbg - Qt5 port of the Scintilla source code editing widget (debug)
libqt5scintilla2-designer - Qt5 Designer plugin for QScintilla 2
libqt5scintilla2-designer-dbg - Qt5 Designer plugin for QScintilla 2 (debug)
libqt5scintilla2-dev - Scintilla source code editing widget for Qt5, development files
libqt5scintilla2-l10n - Scintilla source code editing widget for Qt5, translation files
libqt5script5 - Qt 5 script module
libqt5scripttools5 - Qt 5 script tools module
libqt5sensors5 - Qt Sensors module
libqt5sensors5-dev - Qt 5 Sensors development files
libqt5serialport5 - Qt 5 serial port support
libqt5serialport5-dev - Qt 5 serial port development files
libqt5sql5 - Qt 5 SQL module
libqt5sql5-mysql - Qt 5 MySQL database driver
libqt5sql5-odbc - Qt 5 ODBC database driver
libqt5sql5-psql - Qt 5 PostgreSQL database driver
libqt5sql5-sqlite - Qt 5 SQLite 3 database driver
libqt5sql5-tds - Qt 5 FreeTDS database driver
libqt5svg5 - Qt 5 SVG module
libqt5svg5-dev - Qt 5 SVG module development files
libqt5svg5-private-dev - Qt 5 SVG module private development files
libqt5test5 - Qt 5 test module
libqt5webkit5 - Web content engine library for Qt
libqt5webkit5-dev - Web content engine library for Qt - development files
libqt5websockets5 - Qt 5 Web Sockets module
libqt5websockets5-dev - Qt 5 Web Sockets module - development files
libqt5widgets5 - Qt 5 widgets module
libqt5x11extras5 - Qt 5 X11 extras
libqt5x11extras5-dev - Qt 5 X11 extras development files
libqt5xml5 - Qt 5 XML module
libqt5xmlpatterns5 - Qt 5 XML patterns module
libqt5xmlpatterns5-dev - Qt 5 XML patterns development files
libqt5xmlpatterns5-private-dev - Qt 5 XML patterns private development files
...
