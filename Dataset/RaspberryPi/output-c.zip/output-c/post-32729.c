gpio unexport 5
gpio export 24 in
$ gpio exports
GPIO Pins exported:
  24: in   1  none  
