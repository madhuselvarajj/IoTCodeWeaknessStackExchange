{
    "displays": [{
        "id": 0,
        "name": "outside",
        "enabled": "true"
    }, {
        "id": 1,
        "name": "inside",
        "enabled": "false"
    }, {
        "id": 2,
        "name": "downstairs",
        "enabled": "true"
    }]
}
