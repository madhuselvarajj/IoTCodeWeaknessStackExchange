
interface       = wlan0
ping            = 192.168.0.1
#ping           = 172.26.1.255
#file           = /var/log/messages
#change         = 1407
watchdog-timeout = 15

# Uncomment to enable test. Setting one of these values to '0' disables it.
# These values will hopefully never reboot your machine during normal use
# (if your machine is really hung, the loadavg will go much higher than 25)
max-load-1      = 24
#max-load-5     = 18
#max-load-15        = 12

# Note that this is the number of pages!
# To get the real size, check how large the pagesize is on your machine.
#min-memory     = 1

repair-binary       = /home/weather/weather/util/network_repair.sh
repair-timeout      = 60
#test-binary        = 
#test-timeout       = 

watchdog-device = /dev/watchdog

# Defaults compiled into the binary
#temperature-device =
#max-temperature    = 120

# Defaults compiled into the binary
#admin          = root
admin           = 
interval        = 10
logtick                = 500
log-dir     = /var/log/watchdog

# This greatly decreases the chance that watchdog won't be scheduled before
# your machine is really loaded
realtime        = yes
priority        = 1

# Check if syslogd is still running by enabling the following line
#pidfile        = /var/run/syslogd.pid   
