net start WinRM

Set-Item WSMan:\localhost\Client\TrustedHosts -Value MINWINPC

remove-module psreadline -force

Enter-PsSession -ComputerName MINWINPC -Credential MINWINPC\Administrator
