harry ~ $ sudo apt-get -s install mongodb
Reading package lists... Done
Building dependency tree       
Reading state information... Done
The following extra packages will be installed:
  libboost-dev libboost1.55-dev libpcap0.8 libsnappy1 libv8-3.14.5
  mongodb-clients mongodb-dev mongodb-server
Suggested packages:
  libboost-doc libboost1.55-doc libboost-atomic1.55-dev
  libboost-chrono1.55-dev libboost-context1.55-dev
  libboost-coroutine1.55-dev libboost-date-time1.55-dev
  libboost-exception1.55-dev libboost-filesystem1.55-dev
  libboost-graph1.55-dev libboost-graph-parallel1.55-dev
  libboost-iostreams1.55-dev libboost-locale1.55-dev
  libboost-log1.55-dev libboost-math1.55-dev libboost-mpi1.55-dev
  libboost-mpi-python1.55-dev libboost-program-options1.55-dev
  libboost-python1.55-dev libboost-random1.55-dev
  libboost-regex1.55-dev libboost-serialization1.55-dev
  libboost-signals1.55-dev libboost-system1.55-dev
  libboost-test1.55-dev libboost-thread1.55-dev libboost-timer1.55-dev
  libboost-wave1.55-dev libboost1.55-tools-dev libmpfrc++-dev
  libntl-dev
The following NEW packages will be installed:
  libboost-dev libboost1.55-dev libpcap0.8 libsnappy1 libv8-3.14.5
  mongodb mongodb-clients mongodb-dev mongodb-server
0 upgraded, 9 newly installed, 0 to remove and 0 not upgraded.
Inst libsnappy1 (1.1.2-4 Raspbian:testing [armhf])
Inst libboost1.55-dev (1.55.0+dfsg-3 Raspbian:testing [armhf])
Inst libboost-dev (1.55.0.2 Raspbian:testing [armhf])
Inst libpcap0.8 (1.7.3-1 Raspbian:testing [armhf])
Inst libv8-3.14.5 (3.14.5.8-8.1+rpi1 Raspbian:testing [armhf])
Inst mongodb-dev (1:2.4.14-1 Raspbian:testing [armhf])
Inst mongodb-clients (1:2.4.14-1 Raspbian:testing [armhf])
Inst mongodb-server (1:2.4.14-1 Raspbian:testing [armhf])
Inst mongodb (1:2.4.14-1 Raspbian:testing [armhf])
Conf libsnappy1 (1.1.2-4 Raspbian:testing [armhf])
Conf libboost1.55-dev (1.55.0+dfsg-3 Raspbian:testing [armhf])
Conf libboost-dev (1.55.0.2 Raspbian:testing [armhf])
Conf libpcap0.8 (1.7.3-1 Raspbian:testing [armhf])
Conf libv8-3.14.5 (3.14.5.8-8.1+rpi1 Raspbian:testing [armhf])
Conf mongodb-dev (1:2.4.14-1 Raspbian:testing [armhf])
Conf mongodb-clients (1:2.4.14-1 Raspbian:testing [armhf])
Conf mongodb-server (1:2.4.14-1 Raspbian:testing [armhf])
Conf mongodb (1:2.4.14-1 Raspbian:testing [armhf])
