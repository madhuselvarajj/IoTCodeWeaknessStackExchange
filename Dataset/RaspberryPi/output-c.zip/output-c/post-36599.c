network={
    ssid="Your SSID here"
    psk="Your password here"
    key_mgmt=WPA-PSK
}
