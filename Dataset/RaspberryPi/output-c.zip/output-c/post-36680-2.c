#include <stdio.h>                                             
#include <stdlib.h>                                            
#include <time.h>                                                                                          

// std=gnu99                                                   

#define TEST_CLOCK CLOCK_REALTIME                              

int main (int argc, char* const argv[]) {                      
// Get duration.                                               
    unsigned long long duration = 2500000000;                  
    if (argc > 1) {                                            
        char *check;                                           
        unsigned long long n = strtoull(argv[1], &check, 0);   
        if (check != argv[1]) duration = n;                    
    }                                                          
    printf("Duration %llu ns.\n", duration);                   

// Check precision.                                            
    struct timespec ts;                                        
    int check = clock_getres(TEST_CLOCK, &ts);                 
    if (check == -1) perror("Could not determine resolution"); 
    else printf("Clock resolution %ld ns.\n", ts.tv_nsec);     

// Time a sleep.                                               
    ts.tv_sec = duration / 1000000000;                         
    ts.tv_nsec = duration % 1000000000;                        
    struct timespec start, end;                                
    check = clock_gettime(TEST_CLOCK, &start);                 
    int check2 = nanosleep(&ts, NULL);                         
    int check3 = clock_gettime(TEST_CLOCK, &end);              
    if (check) {                                               
        perror("Starting timer fail");                         
        return 1;                                              
    }                                                          
    if (check2) {                                              
        perror("Sleep fail");                                  
        return 1;                                              
    }                                                          
    if (check3) {                                              
        perror("End timer fail");                              
        return 1;                                              
    }                                                          

// Report.                                                     
    double actual = (double)(end.tv_sec - start.tv_sec);       
    actual += (double)end.tv_nsec / 1000000000.0               
        - (double)start.tv_nsec / 1000000000.0;                
    printf("Elapsed: %lf seconds.\n", actual);                          

    return 0;                                                  
}
