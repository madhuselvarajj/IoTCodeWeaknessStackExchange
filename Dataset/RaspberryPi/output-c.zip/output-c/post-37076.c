int val;
char data[2];
...
done = radio.read( &data, sizeof(data) );
val = (data[0] << 8) + data[1]
