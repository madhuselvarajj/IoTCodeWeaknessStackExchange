public IPAddress GetIPAddress()
{
   List<string> IpAddress = new List<string>();
   var Hosts = Windows.Networking.Connectivity.NetworkInformation.GetHostNames().ToList();
   foreach (var Host in Hosts)
   {
      string IP = Host.DisplayName;
      IpAddress.Add(IP);
   }
   IPAddress address = IPAddress.Parse(IpAddress.Last());
   return address;
}
