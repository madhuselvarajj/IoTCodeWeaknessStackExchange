$ iw phy phy0 info
... lots of stuff ...
Supported interface modes:
     * IBSS
     * managed
     * AP
     * AP/VLAN
     * monitor
     * mesh point
     * P2P-client
     * P2P-GO
... lots more stuff ...
