//...    
radio.startListening();
radio.writeAckPayload(1,&counter,sizeof(counter));  

radio.stopListening();
radio.startListening();

// forever loop
while (1){  

    delay(10);
    uint8_t pipeNo; // Declare variables for the pipe
    //... 
