#include <Arduino.h>

static unsigned long counter = 0;

void setup() {
    Serial.begin(19200, SERIAL_8N1);
}

void loop() {
    Serial.print(counter++, HEX);
    delay(1000);
}
