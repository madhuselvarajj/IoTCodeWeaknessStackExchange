
    #deb http://mirrordirector.raspbian.org/raspbian/ wheezy main contrib non-free rpi
    #Uncomment line below then 'apt-get update' to enable 'apt-get source'
    #deb http://archive.raspbian.org/raspbian wheezy main contrib non-free`
    deb http://raspbian.mirrors.wvstateu.edu/raspbian/ wheezy main contrib non-free rpi
    deb-src http://archive.raspbian.org/raspbian/ wheezy main contrib non-free rpi
