<DeviceCapability Name="serialcommunication">
   <Device Id="any">
      <Function Type="name:serialPort" />
   </Device>
</DeviceCapability>
