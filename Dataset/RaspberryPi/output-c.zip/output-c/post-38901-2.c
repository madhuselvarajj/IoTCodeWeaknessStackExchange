  $('#btn_refresh').click(function () {        
          $.ajax({
              url: "refresh.php"
          }).done(function (msg){
              alert(msg);
          }).fail(function () {
              alert('Error calling refresh script!');
          });
     });
