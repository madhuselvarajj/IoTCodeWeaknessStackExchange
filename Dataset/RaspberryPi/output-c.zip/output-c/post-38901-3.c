<?php     
    // I put the time inside the file, to help me know when something didn't work ok if the file gets stuck there
    $time = time();

    if(!touch('refreshcookie', $time)) {
        echo 'Something went wrong when trying to reload the webpage!';
    } else {
        echo 'Refresh order sent, this may take up to ten seconds';
    }
?>
