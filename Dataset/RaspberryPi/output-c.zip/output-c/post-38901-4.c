<?php

    $imagefile = 'admin/refreshcookie';
    if (file_exists($imagefile))
    {
        unlink($imagefile);
        echo 1;
    }
    else
    {
        echo 0;
    }
?>
