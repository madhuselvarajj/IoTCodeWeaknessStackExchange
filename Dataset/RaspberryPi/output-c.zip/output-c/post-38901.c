$(document).ready(function() {
      setInterval(checkRefresh, 10000);    
 });

function checkRefresh()
{
    $.ajax({
            url: "checkrefresh.php"
    }).done(function (response) {
        if (response == 1)
        {
          document.location.reload(true);          
        }
    });
}
