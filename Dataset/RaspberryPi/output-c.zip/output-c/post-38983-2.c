gpio.setup(Motor1A, gpio.DIR_OUT, writeMotor1A);
function writeMotor1A(){
  gpio.write(Motor1A, gpio.HIGH, function(err) {
  if (err) throw err;
    console.log('Written to pin Motor1A');
  });
}
