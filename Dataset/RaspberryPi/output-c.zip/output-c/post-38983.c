gpio.setup(Motor1A, gpio.DIR_OUT);
gpio.write(Motor1A, gpio.HIGH, function(err) {
if (err) throw err;
  console.log('Written to pin Motor1A');
});
