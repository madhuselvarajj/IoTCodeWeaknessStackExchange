var gpio = require('rpi-gpio');

var Motor1A = 16;
var Motor1B = 18;
var Motor1E = 22;

gpio.setup(Motor1A, gpio.DIR_OUT);
gpio.setup(Motor1B, gpio.DIR_OUT);
gpio.setup(Motor1E, gpio.DIR_OUT);

function forward_engine_1() {
    gpio.write(Motor1A, true, function(err) {
        if (err) throw err;
    });

    gpio.write(Motor1B, false, function(err) {
        if (err) throw err;
    });

    gpio.write(Motor1E, true, function(err) {
        if (err) throw err;
    });
}
