name: hat
product: Display-o-Tron HAT
product_id: 0x0007
product_ver: 0x0001
uuid: 666dfe9b-9d78-4825-bbfe-1697048fc6cd
vendor: Pimoroni Ltd.
