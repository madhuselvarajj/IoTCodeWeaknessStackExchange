// SerialReader.cpp
#include "SerialReader.h"
#include "WProgram.h"

char *SerialReader::read(char *buffer, int maxLength)
{
    int i = 0;
    int bufferIndex = 0;

    if (Serial.available() > 0)
    {
        // Read as long as there is data to be read
        while (i>=0 && bufferIndex < (maxLength-1))
        {
            i = Serial.read();
            if ( i >= 0 ) buffer[bufferIndex++] = (char)i;
        }
        buffer[bufferIndex] = 0; // Null-terminate
    }
    return buffer;
}
