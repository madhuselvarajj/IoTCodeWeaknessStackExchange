// SerialReader.h
#ifndef SERIALREADER_DEFINED
#define SERIALREADER_DEFINED

#define BUFFER_SIZE 256

#include "WProgram.h"

class SerialReader
{
    public:

    char *read(char *buffer, int bufferSize);

};

#endif
