include_once 'PhpSerial.php';

if (!function_exists('open_serial_comms')) {
    function  open_serial_comms()
    {
        // Let's start the class
        $serial = new PhpSerial;

        // First we must specify the device. This works on both linux and windows (if
        // your linux serial device is /dev/ttyS0 for COM1, etc)
        $serial->deviceSet("USB0");

        // We can change the baud rate, parity, length, stop bits, flow control
        $serial->confBaudRate(38400);
        $serial->confParity("none");
        $serial->confCharacterLength(8);
        $serial->confStopBits(1);
        $serial->confFlowControl("xon/xoff");

        // Then we need to open it
        $serial->deviceOpen();

        //Finally we need to return the object
        return $serial; // all open boss, send some data!
    }
}
