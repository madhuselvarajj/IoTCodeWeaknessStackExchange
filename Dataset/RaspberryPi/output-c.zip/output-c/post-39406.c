cd rpf-linux-kernel
git checkout -b rpi-bootloader-4.1.7 59e76bb7e2936acd74938bb385f0884e34b91d72
make mrproper
make bcm2709_defconfig
make modules_prepare
