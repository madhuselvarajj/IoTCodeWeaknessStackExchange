void get_SOC_temp()
{
   FILE *f;
   float cpu_temp;

   f = fopen("/sys/class/thermal/thermal_zone0/temp", "r");

   if (f != NULL)
   {
      fscanf(f, "%f", &cpu_temp);
      cpu_temp /= 1000.0;
      fclose(f);

      printf("%.1f\n",cpu_temp);
   }
}
