pcm.mmap0 {
    type mmap_emul;
    slave {
      pcm "hw:0,0";
    }
}

#pcm.!default {
#  type plug;
#  slave {
#    pcm mmap0;
#  }
#}

pcm.pulse { type pulse }
ctl.pulse { type pulse }
pcm.!default { type pulse }
ctl.!default { type pulse }
