column 'physical'  40 pin connector position.
column 'v'         current value
column 'mode'      current mode In/Out GPIO.setup(n, GPIO.OUT)
column 'name'      human description/function 
column 'wPI'       Wiring Pi (*) pin id, GPIO.setmode(GPIO.BOARD)
column 'BCM'       BCM pin Id. GPIO.setmode(GPIO.BCM)
