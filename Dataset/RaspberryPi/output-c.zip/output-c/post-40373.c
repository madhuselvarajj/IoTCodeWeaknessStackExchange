Raspberry Pi Model A    700mA   500mA   200mA
Raspberry Pi Model B    1.2A    500mA   500mA
Raspberry Pi Model A+   700mA   500mA   180mA
Raspberry Pi Model B+   1.8A    600mA/1.2A (switchable) 330mA
Raspberry Pi 2 Model B  1.8A    600mA/1.2A (switchable) 
