ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1

network={
    ssid="Superbly secure WPA home network"
    psk="correctHorseBatt3ry5taple42"
    proto=RSN
    key_mgmt=WPA-PSK
    pairwise=CCMP TKIP
    group=CCMP TKIP
}

network={
        ssid="Horribly insecure open school network"
        key_mgmt=NONE
}
