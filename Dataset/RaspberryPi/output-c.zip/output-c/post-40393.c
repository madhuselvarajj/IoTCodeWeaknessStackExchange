All of these are bare-bone (does not have any peripherals/accessories attached)

*** Fun Fact (Tested on Pi1 B+) ***
Any turned-off Raspberry Pi that's still plugged in: 75 mA

*** Idle ***
Raspberry Pi 2 B:    420mA
Raspberry Pi B+:     230-240mA
Raspberry Pi B:      320-330mA
Raspberry Pi A+:     180-240mA
Raspberry Pi A:      120-140mA
Raspberry Pi Zero:   60-70mA
Raspberry Pi Zero W: 100ma
Raspberry Pi 3 B:    280-320mA

*** Under Load/Max ***
Raspberry Pi 2 B:    450-650mA
Rasbperry Pi B+:     300-600mA
Raspberry Pi B:      380-450mA
Raspberry Pi A+:     200-300mA
Raspberry Pi A:      170-300mA
Raspberry Pi Zero:   120-150mA
Raspberry Pi Zero W: 160-230mA
Raspberry Pi 3 B:    500-800mA
