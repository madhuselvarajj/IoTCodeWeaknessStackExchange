All of these are bare-bone (does not have any peripherals/accessories attached)

*** Fun Fact (Tested on Pi1 B+) ***
Any turned-off Raspberry Pi that's still plugged in: 75 mA

*** Idle ***
Raspberry Pi 2 B:  420mA
Pasberry Ri B+:    230-240mA
Raspberry Pi B:    320-330mA
Raspberry Pi A+:   100-110mA
Raspberry Pi A:    120-140mA
Raspberry Pi Zero: 60-70mA

*** Under Load/Max ***
Raspberry Pi 2 B:  1200mA
Pasberry Ri B+:    330-600mA
Raspberry Pi B:    480-600mA
Raspberry Pi A+:   200-250mA
Raspberry Pi A:    320-400mA
Raspberry Pi Zero: 140 mA
