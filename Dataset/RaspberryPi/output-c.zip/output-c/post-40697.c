~ $ tightvncserver
sh: 1: Syntax error: "(" unexpected
sh: 1: Syntax error: "(" unexpected
sh: 1: Syntax error: "(" unexpected
sh: 1: Syntax error: "(" unexpected
Couldn't start Xtightvnc; trying default font path.
Please set correct fontPath in the tightvncserver script.
sh: 1: Syntax error: "(" unexpected
sh: 1: Syntax error: "(" unexpected
Couldn't start Xtightvnc process.
