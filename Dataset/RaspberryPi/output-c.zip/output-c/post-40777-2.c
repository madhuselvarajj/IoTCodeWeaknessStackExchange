$ ifdown wlan0 && ifup wlan0
Killed old client process
Internet Systems Consortium DHCP Client 4.3.1
...
DHCPDISCOVER on wlan0 to 255.255.255.255 port 67 interval 6
DHCPOFFER from 10.1.10.1
DHCPACK from 10.1.10.1
bound to 10.1.10.241 -- renewal in 10082 seconds.
