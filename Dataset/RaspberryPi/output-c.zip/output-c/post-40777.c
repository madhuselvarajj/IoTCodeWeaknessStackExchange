$ ping 209.86.60.62
connect: Network is unreachable
$ apt-get update
Err http://mirrordirector.raspbian.org jessie InRelease
  Could not resolve 'mirrordirector.raspbian.org'
Err http://raspberrypi.collabora.com wheezy Release.gpg
  Could not resolve 'raspberrypi.collabora.com'
...    
