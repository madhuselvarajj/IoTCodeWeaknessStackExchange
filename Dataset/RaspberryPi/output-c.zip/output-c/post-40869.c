address <desired_ip>
netmask <run ifconfig -> Mask field>
network <run netstat -> Destination>
broadcast <run ifconfig -> Bcast field>
gateway <run netstat -nr - look for gateway>
