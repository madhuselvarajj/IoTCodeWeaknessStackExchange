long counter;
char state;
int direction = 1;

while(1) {
    /* get pin values */
    char ra = gpio_input_read(22); /* pseudocode library function */
    char rb = gpio_input_read(23);

    /* update encoder */
    int ns = (ra ^ rb) | (rb << 1);
    if (state == ns) { return; }
    int dt = (ns - state) % 4;
    if (dt < 0) { dt = dt * -1; }
    if (dt == 3) {
        direction = -1;
    if (dt == 1) {
        direction = 1;
    }
    counter = counter + direction;
    state = ns;

    /* do something with counter and/or direction */
}
