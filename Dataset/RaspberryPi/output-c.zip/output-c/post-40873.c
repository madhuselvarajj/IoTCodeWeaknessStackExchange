# Globals:
state = 0
counter = 0
direction = 1

while True:
    # get raw pin values
    ra = GPIO.input(22)
    rb = GPIO.input(23)

    # update encoder count and direction
    ns = (ra ^ rb) | rb << 1
    if state == ns: # no change since last time
        return
    dt = (ns - state) % 4
    if dt == 3:
        direction = -1
    elif dt == 1:
        direction = 1
    counter = counter + direction
    state = ns

    # do something with counter and/or direction
