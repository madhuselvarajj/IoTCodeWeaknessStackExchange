my $pin = SysfsGPIO->new (         
    number => 17,             
    direction => SysfsGPIO::INPUT, 
    edge => SysfsGPIO::BOTH_EDGES, 
    active => SysfsGPIO::LOW,      
    bouncetime => 0.01             
); 
