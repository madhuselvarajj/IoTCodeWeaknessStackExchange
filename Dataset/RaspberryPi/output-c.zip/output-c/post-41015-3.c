        my $prev = $pin->{lastValue};          
        my $state = $pin->getValue;            
        next if $pin->checkBounceTime;              
        print "$pin->{color} $state";
        $pin->{output}->toggle if ($state eq SysfsGPIO::HIGH);        
