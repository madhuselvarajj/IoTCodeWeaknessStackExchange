#!/usr/bin/perl                                                      
use strict;                                                          
use warnings FATAL => qw(all);                                       

use IO::Poll qw(POLLPRI POLLERR);                                    
use SysfsGPIO;                                                       

use constant POLL_EVENTS => POLLPRI | POLLERR;                       

my %buttons;                                                         
my $gpios = IO::Poll->new();                                         

foreach (                                                            
    [ 17, 'blue' ],                                                  
    [ 27, 'green' ],                                                 
    [ 22, 'yellow' ]                                                 
) {                                                                  
    my $pin = SysfsGPIO->new (                                       
        number => $_->[0],                                           
        color => $_->[1],                                            
        direction => SysfsGPIO::INPUT,                               
        edge => SysfsGPIO::BOTH_EDGES,                               
        active => SysfsGPIO::LOW,                                    
        bouncetime => 0.01                                           
    );                                                               
    if (!$pin) {                                                     
        print STDERR "Pin $_->[0] ($_->[1]) failed initialization!\n"; 
        next;                                                        
    }                                                                
    $buttons{$pin->{handle}} = $pin;                                 
    $pin->getValue;                                                  
    $gpios->mask($pin->{handle}, POLL_EVENTS);                       
}                                                                    


print "Begin...\n";                                                  


while ($gpios->poll) {                                               
    foreach ($gpios->handles(POLL_EVENTS)) {                         
        my $pin = $buttons{$_};                                      
        my $prev = $pin->{lastValue};                                
        my $state = $pin->getValue;                                  
        next if $pin->checkBounceTime;                                                           

        print "$pin->{color} $state";                                
    }                                                                
}                                                
