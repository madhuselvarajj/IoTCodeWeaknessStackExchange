use constant {                 
    INPUT      => "in\n",      
    OUTPUT     => "out\n",     
    HIGH       => "1\n",       
    LOW        => "0\n",       
    POSEDGE    => "rising\n",  
    NEGEDGE    => "falling\n", 
    BOTH_EDGES => "both\n",    
    NO_EDGE    => "none\n"     
};
