<body>
    <?php
        if ($_GET['drink']) {
            $cmd = "export DISPLAY=:0; myscript;";
            exec($cmd);
        }
    ?>
    <a href="?drink=true" class="btn btn-primary" role="button" >Launch script</a>
</body>
