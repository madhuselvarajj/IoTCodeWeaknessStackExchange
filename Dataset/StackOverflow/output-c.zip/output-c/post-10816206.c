#define numberOfBytes 4
char command[numberOfBytes];

    void serialRX() {
      while (Serial.available() > numberOfBytes) {
        if (Serial.read() == 0x00) { //send a 0 before your string as a start byte
          for (byte i=0; i<numberOfBytes; i++)
            command[i] = Serial.read();
        }
      }
    }
