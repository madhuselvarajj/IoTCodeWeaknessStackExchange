int pos = 0;
Serial.flush(); // flush all received data
while(Serial.avaialble()<3); // wait for the 3 ascii chars
if(Serial.read()==27){ // first char
  if(Serial.read()==91){ //second char
    switch (Serial.read()){
      case 67: // Right arrow
        myservo.write(++pos); // increment pos with 1 before write it
        break;
      case 68: // left arrow
        myservo.write(--pos); // derement pos with 1 before write it
        break;
      case 65: // up arrow
        myservo.write(++pos); // increment pos with 1 before write it
        break;
      case 66: // down arrow
        myservo.write(--pos); // decrement pos with 1 before write it
        break;
      case default:
        break;
    }
  }
}
