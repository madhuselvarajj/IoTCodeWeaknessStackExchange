//add below these lines:
#ifndef x
#define x
//this
#include <Arduino.h>
