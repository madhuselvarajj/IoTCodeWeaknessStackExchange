unsigned char b[35];

int sizeOfB = sizeof b / sizeof(unsigned char);

int sizeOfL = sizeOfB / 4;
if(sizeOfB % 4 != 0) ++sizeOfL;
    int lcount=0;

long* l = new long[sizeOfL];

for(int i = 0; i < sizeOfB; i+=4){
    long currentLong = 0;

    if(i + 3 < sizeOfB)
        currentLong = (currentLong << 8) + b[i+3];
    if(i + 2 < sizeOfB)
        currentLong = (currentLong << 8) + b[i+2];
    if(i + 1 < sizeOfB)
        currentLong = (currentLong << 8) + b[i+1];

    currentLong = (currentLong << 8) + b[i+0];

    l[lcount]=currentlong;
    lcount++;
}

// Use l...
delete l;
