typedef struct s_PIN {
  char *name;
  uint8_t gpio;
  char *mux;
  uint8_t eeprom;
  PWM pwm;  /* Notice: not a pointer */
} PIN;
