// given: String command
int data[MAX_ARGS];
int numArgs = 0;

int beginIdx = 0;
int idx = command.indexOf(",");

String arg;
char charBuffer[16];

while (idx != -1)
{
    arg = command.substring(beginIdx, idx);
    arg.toCharArray(charBuffer, 16);

    // add error handling for atoi:
    data[numArgs++] = atoi(charBuffer);
    beginIdx = idx + 1;
    idx = command.indexOf(",", beginIdx);
}

data[numArgs++] = command.substring(beginIdx);
