Serial.print(printByte);

for(int i=0; i<=sizeof(printByte);i++){
   if (0 == printByte[i])
       break;
   printf("%02x", printByte[i]);
}
printf("\n"); // Newline after output

if (0 == strpos(printByte, "QUIT"))
{
    // The cycle ends.
}

for(int i=0; i<=sizeof(printByte);i++){
   printByte[i]=0;
}
