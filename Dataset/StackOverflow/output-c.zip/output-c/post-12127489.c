typedef struct {
    int a;
} foo;

/* ... */

foo *fp = malloc(SOME_NUMBER * sizeof foo);
fp++;    // fp = fp + sizeof foo;
fp += 4; // fp = fp + sizeof foo * 4;
