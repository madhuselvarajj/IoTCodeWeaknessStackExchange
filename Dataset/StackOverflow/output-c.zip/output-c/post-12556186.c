import struct
...

data = my_port.read(5)
num, = struct.unpack('<fx', data)
