#include <stdio.h>
#include <stdlib.h>

void loop() {
    char data[10], *end;
    char indata;
    int i=0;
    float value;

    while ((indata!=13) & (i<10)) {
        if (Serial.available() > 0) {
            indata = Serial.read();
            data[i] = indata;
            i++;
        }
    }
    i-=1;
    data[i] = 0; // replace carriage return with 0
    value = strtof(data,&end);           
}
