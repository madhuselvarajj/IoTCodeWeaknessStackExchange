void setup()
{
  // set communiation speed
  Serial.begin(9600);
  pinMode(LED_PIN, OUTPUT);
  delay(500);
  acc.powerOn();
}
