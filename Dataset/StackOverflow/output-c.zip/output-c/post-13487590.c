// Enable the receiver and set local mode...
options.c_cflag |= (CLOCAL | CREAD);

// Set 8-bit mode
options.c_cflag &= ~CSIZE;
options.c_cflag |= CS8;
