#include <LiquidCrystal.h>
#include <string.h>
LiquidCrystal lcd(8, 9, 4, 5, 6, 7);

char serialinput [5] = {0};   // for incoming serial data
                              // 4 char + ending null char

void setup() {
    Serial.begin(9600);     // opens serial port, sets data rate to 9600 bps
}

void loop() {
    // send data only when you receive data:
    if (Serial.available() > 0) {
        memmove (serialinput, &serialinput[1], 3); // Move 3 previous char in the buffer
        serialinput [3] = Serial.read(); // read char at the end of input buffer

        if (0 == strcmp(serialinput, "send")) // Compare buffer content to "send"
        {
            lcd.print("received");
        }
    }
}
