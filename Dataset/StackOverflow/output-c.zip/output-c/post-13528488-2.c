class UART {
public:
    UART(unsigned int uart_device, RXBuffer& rx_buffer) :
        m_uart(uart_device), m_buffer(rx_buffer)
    {
    }

    unsigned int uart_device() const { return m_uart; }

    // set the timeout during a read operation
    void timeout(unsigned ms) { m_timer.countdown(ms); }

    template <typename InputIterator>
    void read(InputIterator first, InputIterator last)
    {
        // start the timer
        m_timer.start();

        size_t size = std::distance(first, last);
        size_t read_bytes = 0;

        while (read_bytes != size && !m_timer.is_expired())
        {
            read_bytes += m_buffer.read(first + read_bytes, last);
        }

        if (read_bytes != size) throw std::exception("timeout");
    }

    template <typename OutputIterator>
    void send(OutputIterator first, OutputIterator last)
    {
        size_t size = std::distance(first, last);
        uart_send(m_uart, &(*first), size);
    }

private:
    unsigned int m_uart;
    RXBuffer& m_buffer;
    timer m_timer;
};
