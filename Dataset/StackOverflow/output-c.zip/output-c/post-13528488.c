#include <cstdint>
#include <deque>
#include <algorithm>

class RXBuffer {
public:
    friend class ISR;

    typedef std::deque<uint8_t>::const_iterator const_iterator;

    RXBuffer();
    size_t size() const { m_buffer.size(); }

    // read from the buffer in a container in the range [first, last)
    template <typename Iterator>
    void read(Iterator first, Iterator last, Iterator to)
    {
        // how many bytes do you want to read?
        size_t bytes_to_read = std::distance(first, last);

        if (bytes_to_read >= size())
        {
            // read the whole buffer
            std::copy(begin(), end(), first);

            // empty the buffer
            m_buffer.clear();

            return size();
        }
        else
        {
            // copy the data
            copy(begin(), begin() + bytes_to_read, firt);

            // now enque the element
            m_buffer.erase(begin(), begon() + bytes_to_read);

            return bytes_to_read;
        }
    }

private:
    void put(uint8_t data)
    {
        // check buffer overflow
        m_buffer.push_back(data);
    }

    const_iterator begin() const { return m_buffer.begin(); }
    const_iterator end() const { return m_buffer.end(); }

private:
    std::deque<uint8_t> m_buffer;           // buffer where store data
    size_t m_size;                          // effective size of the container
};

class ISR {
public:
    ISR(RXBuffer& buffer) : m_buffer(buffer) {}

    // ISR Routine
    void operator () (uint8_t data)
    {
        m_buffer.put(data);
    } 

private:
    RXBuffer& m_buffer;
};
RXBuffer g_uart1_rx_buffer;
