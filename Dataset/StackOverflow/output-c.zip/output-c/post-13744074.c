int current_line = 0;
int current_col = 0;

void loop(void)
{
    char ch = read_char_from_serial();

    if (ch == '\n')
    {
        current_line++;
        current_col = 0;
    }
    else
    {
        lcd_goto(current_line, current_col++);
        lcd_put_char(ch);
    }
}
