/*
 * read the pin's value (works even if it's not muxed as a gpio).
 */
int at91_get_gpio_value(unsigned pin)
{
        void __iomem    *pio = pin_to_controller(pin);
        unsigned        mask = pin_to_mask(pin);
        u32             pdsr;

        if (!pio)
                return -EINVAL;
        pdsr = __raw_readl(pio + PIO_PDSR);
        return (pdsr & mask) != 0;
}
EXPORT_SYMBOL(at91_get_gpio_value);
