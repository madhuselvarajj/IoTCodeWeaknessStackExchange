void loop() {
    if (Serial.available()) {
        do {
            ch = Serial.read();
        } while (ch == 'y');
    }

    if (Serial.available()) {
        do {
            ch = Serial.read();
        } while (ch == 'x');
    }
}
