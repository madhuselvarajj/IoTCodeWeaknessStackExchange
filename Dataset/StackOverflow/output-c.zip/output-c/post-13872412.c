#include <WiServer.h>

// ---------------------------------------------------------------------------------
// Wireless configuration parameters
// ---------------------------------------------------------------------------------
unsigned char local_ip[]    = {192,168,1,10};   // IP address of WiShield 192.168.1.10
unsigned char gateway_ip[]  = {192,168,1,1};    // router or gateway IP address
unsigned char subnet_mask[] = {255,255,255,0};  // subnet mask for the local network
char ssid[]                 = {"monitored"};    // max 32 bytes

// 0 - open; 1 - WEP; 2 - WPA; 3 - WPA2
unsigned char security_type = 3;    

// WPA/WPA2 passphrase
const prog_char security_passphrase[] PROGMEM = {"password"};   // max 64 characters

// WEP 128-bit keys
prog_uchar wep_keys[] PROGMEM = { 
    0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d,   // Key 0
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // Key 1
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // Key 2
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00    // Key 3
};

// setup the wireless mode
// infrastructure - connect to AP
// adhoc - connect to another WiFi device
#define WIRELESS_MODE_INFRA 1
#define WIRELESS_MODE_ADHOC 2
unsigned char wireless_mode = WIRELESS_MODE_INFRA;
unsigned char ssid_len;
unsigned char security_passphrase_len;


// ---------------------------------------------------------------------------------
// GET REQUEST
// ---------------------------------------------------------------------------------

// IP Address for macpro.local
uint8 ip[] = {192,168,1,12};
// The request URL
GETrequest getStatus(ip, 80, "macpro.local", "/open-says-me/index.html");

const int relayPin    = 3;
int relayControlState = LOW;

// ---------------------------------------------------------------------------------
// Callback for WiServer's getStatus
// ---------------------------------------------------------------------------------
void setRelayControlState(char* data, int len) {

    Serial.print("[setRelayControlState] last digit of data: ");
    Serial.println(data[len-1]);

    Serial.print("[setRelayControlState] len: ");
    Serial.println(len);

    if(len > 0 
        && data[len-1] == '1') {

        relayControlState = HIGH;
        Serial.print("\nSET HIGH FOR 5.5s\n");

        digitalWrite(relayPin, HIGH);
        delay(5500);
        digitalWrite(relayPin, LOW);

    }

}

void setup() {

    pinMode(relayPin, OUTPUT);
    Serial.begin(57600);

    // Initialize WiServer (we'll pass NULL for the page serving function since we don't need to serve web pages) 
    WiServer.init(NULL);

    // Enable Serial output and ask WiServer to generate log messages (optional)

    WiServer.enableVerboseMode(true);

    // Have the processData function called when data is returned by the server
    getStatus.setReturnFunc(setRelayControlState);

}

// Time (in millis) when the data should be retrieved 
long updateTime = 0;
void loop(){

    // Check if it's time to get an update
    if (millis() >= updateTime) {
        // Get another update 15s from now
        updateTime += 1000 * 15;
        getStatus.submit();
        Serial.print("end update @ ms ");
        Serial.println(millis());
    }

    WiServer.server_task();
    delay(100);
}
