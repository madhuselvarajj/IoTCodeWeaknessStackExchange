void setup()
{
    frontServo.attach(2);
    rearServo.attach(3);
}

void loop()
{
    moveForward(5);
    exit(0);
}
