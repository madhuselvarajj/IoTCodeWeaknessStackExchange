int main()
{
    setup();
    for (;;) {
        loop();
    }
    return 0;
}
