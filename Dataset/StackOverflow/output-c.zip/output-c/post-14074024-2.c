#!/bin/bash

while true; do
    /path/to/your/program >> measurements.log

    sleep 1800 
done
