STARTUP(crt0.o)

SECTIONS {
    .init 0x8000 : {
        *(.init)
    }

    .text 0x9000 : {
        *(.text)
        *(.rodata)
        *(COMMON)
    }

    .data : {
        *(.data)
    }

    .bss : {
        *(.bss)
    }

    /DISCARD/ : {
        *(*)
    }
}
