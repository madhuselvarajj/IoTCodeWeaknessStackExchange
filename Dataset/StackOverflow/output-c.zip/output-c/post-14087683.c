boolean bLast = false;

const float vTrip = 1.5;
// you find a good value for this by looking at the noise in readings
// use a scratch program to just read in a loop  
// set this value to something much larger than any variation
const float vHyst = 0.1;

float getLight() {
    int sensorValue = analogRead(A0);
   // Convert the analog reading (which goes from 0 - 1023) to a voltage (0 - 5V):
   float voltage = sensorValue * (5.0 / 1023.0);
   return voltage;
}

void setup() {
    // establish the initial state of the light
    float v = getLight();
    bLast = ( v < (vTrip-vHyst) );
}

void loop() {
    float v = getLight();
    if( bLast ) {
        // light was on
        // when looking for decreasing light, test the low limit
        if( v < (vTrip-vHyst) ) {
             bLast = false;
             Serial.print("Dark");
        }
    }
    else {
        // light was off
        // when looking for increasing light, test the high limit
        if( v > (vTrip+vHyst) ) {
            bLast = true;
            Serial.print("Light");
        }
    }
}
