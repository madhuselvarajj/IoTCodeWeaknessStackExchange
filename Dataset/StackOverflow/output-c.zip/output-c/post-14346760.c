FILE* pOutput = popen("/usr/bin/python myscript.py", "r");
  while ( fgets(line, 199, pOutput) )
  {
    printf("%5d: %s", entry++, line);
  }
