#include "avr/io.h"

.global main

main:
    ldi r24, 0xFF
    sts _SFR_MEM_ADDR(DDRB), r24
    sts _SFR_MEM_ADDR(PORTB), r24

 end:
    jmp end
