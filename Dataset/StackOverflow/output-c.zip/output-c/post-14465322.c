#include "avr/io.h"

.global main

main:
    ldi r24, 0xFF
    out _SFR_IO_ADDR(DDRB), r24
    out _SFR_IO_ADDR(PORTB), r24

 end:
    jmp end
