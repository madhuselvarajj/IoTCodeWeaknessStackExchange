/**
 * \file foo.h
 */
#include <SdFat.h>
extern SdFat sd;
...
