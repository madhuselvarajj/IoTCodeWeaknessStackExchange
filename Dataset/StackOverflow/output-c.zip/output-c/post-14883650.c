/**
 * \file test.ino
 */
#include <SdFat.h>
#include <foo.h>
SdFat sd;
...
