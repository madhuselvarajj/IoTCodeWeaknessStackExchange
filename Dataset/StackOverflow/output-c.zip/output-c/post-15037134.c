boolean pinValue;

void setup() {
   Serial.begin(9600);
   pinMode(13, OUTPUT);
   digitalWrite(13, HIGH);
   pinValue = true;
}

void loop() {
    pinValue = !pinValue;
    digitalWrite(13, pinValue);
}
