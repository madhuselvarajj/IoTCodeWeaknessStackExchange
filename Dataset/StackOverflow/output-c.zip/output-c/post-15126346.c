enum {
    gpio1 = 42, 
    gpio2 = 84, 
    gpio3 = 43, 
    // etc.
};
