void getGyroValues (){
    int MSB, LSB;

    LSB = wiringPiI2CReadReg16(fd, 0x28);
    MSB = wiringPiI2CReadReg16(fd, 0x29);
    x = ((MSB << 8) | LSB);

    MSB = wiringPiI2CReadReg16(fd, 0x2B);
    LSB = wiringPiI2CReadReg16(fd, 0x2A);
    y = ((MSB << 8) | LSB);

    MSB = wiringPiI2CReadReg16(fd, 0x2D);
    LSB = wiringPiI2CReadReg16(fd, 0x2C);
    z = ((MSB << 8) | LSB);
}
