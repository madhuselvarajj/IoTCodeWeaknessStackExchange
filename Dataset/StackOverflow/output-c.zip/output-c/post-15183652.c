#define epsilon ((double)0.000999)
bool is_approximately_equal(double x, double y)
{
        return (abs(x - y) < epsilon);
}
