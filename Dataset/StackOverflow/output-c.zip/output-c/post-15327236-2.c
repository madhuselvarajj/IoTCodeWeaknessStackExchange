commFrame_t frame;
// Fill the frame with data
frame.wind = someWindValue;
frame.temperature = someTemperatureValue;
// Send the frame
Serial.write(&frame, sizeof(frame));
