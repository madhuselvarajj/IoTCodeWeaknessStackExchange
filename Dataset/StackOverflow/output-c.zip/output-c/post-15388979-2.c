Number           : 1.113
  Integer        : 1
  Fractional part: 113 over 1000
Number           : 20.000
  Integer        : 20
  Fractional part: 0 over 1000
Number           : 300.001
  Integer        : 300
  Fractional part: 1 over 1000
