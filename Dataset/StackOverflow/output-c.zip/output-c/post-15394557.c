int main() {
    double num = 30.233;
    int a,b;
    a = floor(num);
    b = num * pow(10,3) - a * pow(10,3);
    printf("%d",b);

    num = 30.2334567;
    a = floor(num);
    b = num * pow(10,7) - a * pow(10,7);
    printf("%d", b);

    return 0;
}  
