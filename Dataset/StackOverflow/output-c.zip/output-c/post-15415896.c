struct ab {
  long a;
  long b;
}

struct ab Conv(double num) {
  struct ab ab_instance;

  ab_instance.a = floor(num);
  ab_instance.b = num * pow(10,6) - a * pow(10,6);

  return ab_instance;
}
