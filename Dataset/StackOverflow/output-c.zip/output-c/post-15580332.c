if (strcmp (dataRx,"HELLO") == 0) {

    // matches HELLO

}
