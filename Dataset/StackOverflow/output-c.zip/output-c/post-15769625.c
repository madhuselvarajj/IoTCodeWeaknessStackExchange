String debinaryStringify(String source) {
    String result = "";
    int idxStart = 0;
    do {
        char val = 0;
        for (int i=0; i<8; i++) {
            val += ((source.charAt(idxStart+i) == '1') << (7-i)); // Trick: Assignment of an evaluation result
        }
        result.concat(val);
        idxStart = source.indexOf(' ') + 1;
    } while ( (idxStart > 0) && (idxStart < source.length() - 7) );
    return result;
}
