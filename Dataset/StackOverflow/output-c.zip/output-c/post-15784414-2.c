// ...

isAPressed = (digitalRead(buttonA) == LOW);
if(!wasAPressed && isAPressed) {
    wasAPressed = true;
    Serial.write('Ad');
} else if(wasAPressed && !isAPressed){
    wasAPressed = false;
    Serial.write('Au');
}

// ...
