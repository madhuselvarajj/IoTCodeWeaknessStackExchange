    mon = udev_monitor_new_from_netlink(udev, "udev");
    if(mon==NULL) {
        wprinterr("Could not create udev monitor!\n");
        exit(EXIT_FAILURE);
    }
    if(udev_monitor_filter_add_match_subsystem_devtype(mon, "block", NULL) != 0) {
        wprinterr("Could not add subsystem match to udev monitor\n");
        exit(EXIT_FAILURE);
    }
    if(udev_monitor_enable_receiving(mon) != 0) {
        wprinterr("Could not enable udev monitor receiving\n");
        exit(EXIT_FAILURE);
    }    
    fd = udev_monitor_get_fd(mon);
    while (1) {
        /*
         * this will block until there is a monitor event
         */
        fd_set fds;
        int ret;
        FD_ZERO(&fds);
        FD_SET(fd, &fds);
        ret = select(fd+1, &fds, NULL, NULL, NULL);

        /* Check if our file descriptor has received data. */
        if (ret > 0 && FD_ISSET(fd, &fds)) {
            dev = udev_monitor_receive_device(mon);
            if (dev) {
