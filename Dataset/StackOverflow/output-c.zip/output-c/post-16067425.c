
#define PTAD5  5
...

void setbit(PTADSTR byte, int bit)
{
    switch(bit)
    {
        ...
        case PTAD5  : byte.PTAD5 = 1; break;
        default: ASSERT_ALWAYS(); break;
    }
}
