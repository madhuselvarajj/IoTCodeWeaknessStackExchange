void LedBar()
{
  if(on == 1)
  {
    if (potValue < M2) {
      //digitalWrite all leds 0;
    }
    else if (potValue > M2 && potValue < M3) {
      //digitalWrite first led 1;
      //digitalWrite all the others 0;
    }
    else if (potValue > M3 && potValue < M4) {
      //digitalWrite first and second led 1;
      //digitalWrite all others 0;
    }
    //and so on...
  }


  else
   {
    digitalWrite(2, LOW);
    digitalWrite(3, LOW);
    digitalWrite(4, LOW);
    digitalWrite(5, LOW);
    digitalWrite(6, LOW);
    digitalWrite(7, LOW);
    digitalWrite(8, LOW);
    digitalWrite(9, LOW);
    digitalWrite(10, LOW);
    }
  }
