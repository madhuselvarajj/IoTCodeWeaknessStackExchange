 typedef struct String{
    int size;
    char * chararray;

 }String;
