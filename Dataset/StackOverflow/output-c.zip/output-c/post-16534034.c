boolean LED_state = false;  //init to false/closed

void loop(){

 if (checkForCorrectCommand() == true){ //

   if (LED_State == false){
     open_valve();
     LED_State = true;

   } else {
     close_valve();
     LED_State = false;
   }
 }
}
