#include "TimerOne.h" //Include the librart, follow the previous link to download and install.

int LED = 4;
const int RELAY_A = A0;  
boolean ledOn;

void setup()
{
    pinMode(LED, OUTPUT)
    Timer1.initialise(500000) // Initialise timer1 with a 1/2 second (500000µs) period
    ledOn = false;
}

void blinkCallback() // Callback function call every 1/2 second when attached to the timer
{
    if(ledOn){
        digitalWrite(LED,LOW);
        ledOn = false;
    }
    else{
        digitalWrite(LED,HIGH);     
        ledOn = true;
    }
}

void open_valve() {

  digitalWrite(RELAY_A, HIGH); // turn RELAY_A on

}

void close_valve() {

  digitalWrite(RELAY_A, LOW); // turn RELAY_A off
}

void serialEvent() {
  while(Serial.available()) {
    char inChar = (char)Serial.read();
    inputString += inChar;
    if (inChar == '\n') {
      stringComplete = true;
    }
  }
}

void loop()
{
    // print the string when newline arrives:
  if (stringComplete) {
    Serial.println(inputString);
    // clear the string:
    inputString = "";
    stringComplete = false;
  }


  if (inputString == "{blink_Flow_A}") {
    Timer1.attachInterupt(blinkCallback); //Start blinking
  }
  if (inputString == "{stop}") {
    Timer1.detachInterrupt(); //Stop blinking
  }
  if (inputString == "{open_valve}") {
    open_valve();
  }
  if (inputString == "{close_valve}") {
    close_valve();
  }
}  
