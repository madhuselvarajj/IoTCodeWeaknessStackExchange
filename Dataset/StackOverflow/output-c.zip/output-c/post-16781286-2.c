cs1_low();
foo = SPI.transfer(bar);
cs1_high(); //Deselect Control

...blah blah...

cs2_low();
foo = SPI.transfer(bar);
cs2_high(); //Deselect Control
