void cs1_low() {
    SPI.setDataMode(SPI_MODE0);
    SPI.setClockDivider(spiRate);
    digitalWrite(MP3_XCS, LOW);
}

void cs2_low() {
    SPI.setDataMode(SPI_MODE1);
    SPI.setClockDivider(spiRate/2)
    digitalWrite(MP3_XCS, LOW);
}
