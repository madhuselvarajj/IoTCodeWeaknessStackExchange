void setup()
{
     Serial.begin(9600);
     SPI.begin();
     rfid.init();
     analogWrite(10, 50); // set brightness on pin 10 to 0-255
     lcd.begin(16, 2);              // start the library
}
