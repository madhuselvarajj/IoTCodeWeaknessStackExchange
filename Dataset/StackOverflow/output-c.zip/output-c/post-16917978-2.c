// Allocate the command
char * fullCommand = malloc(len * sizeof(char));

// Build the command
strcpy(fullCommand, commandPre);
