    // Allocate the command
    char * fullCommand = (char *) malloc(len * sizeof(char));

    // Build the command
    strcat(fullCommand, commandPre);
