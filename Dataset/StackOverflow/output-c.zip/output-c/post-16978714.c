#!/usr/bin/python
while True:
  file = raw_input('Input file name:(input "q" to quit)')
  if file == 'q':
      break
  file_ = open(file).read()
  list_ = list(file_)
  new_file = ''
  for x in list_:
      if x != '^' and x != 'M':
          new_file = new_file + x
  file_ = open(file,'w')
  file_.write(new_file)
  file_.close()
