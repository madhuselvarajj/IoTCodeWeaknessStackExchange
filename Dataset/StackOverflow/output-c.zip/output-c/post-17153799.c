switch(val)
{
    case 0 ... 250:
        inRange(val);
        break;

    default:
        outOfRange();
        break;
}
