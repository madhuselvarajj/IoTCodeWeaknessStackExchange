void handle_steering(int steering) {
    if (steering > NN)
        turn_left(steering);
    elif (steering < NN)
        turn_right(steering);
    else
        keep_straight();
}
