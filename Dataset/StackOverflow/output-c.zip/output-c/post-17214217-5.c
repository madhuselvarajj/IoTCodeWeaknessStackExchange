void loop() {
    int throttle = read_throttle();
    int steering = read_steering();
    delay(5);
    handle_throttle(throttle);
    handle_steering(steering);
}
