int read_input(int i) {
    int value = pulseIn(PIN[i], HIGH, 20000);
    return map(value, 1000, 2000, DOM_MIN[i], DOM_MAX[i]);
}

int handle_action(int i, int value) {
    if (value > BOUND_MIN[i])
        *(ACTION[i])(value);
    elif (value < BOUND_MAX[i])
        *(ACTION[i])(value);
    else
        *(ACTION[i])(-1);
}

void loop() {
    for (int i=0; i<NB_INPUTS; ++i) {
        int value = read_input(i);
        delay(5);
        handle_action(i, value);
    }
}
