for(;;)
{
    WaitTimer() ;
    pulses = pulse_count - previous_pulse_count ;
    previous_pulse_count = pulse_count ;
    control = pid( pulses ) ;
    motor( control ) ;
}
