1 #include <stdio.h>
2 #include <stdlib.h>
3 
4 int main()
5 {
6         unsigned char buf[4];
7         unsigned int *fill = buf;
8         *fill = 4242;
9 
10         int i;
11         for(i = 0; i < sizeof(buf); i++) {
12             printf("%i", (unsigned int)buf[i]);
13         }
14 
15 }

printed value is [1461600]
