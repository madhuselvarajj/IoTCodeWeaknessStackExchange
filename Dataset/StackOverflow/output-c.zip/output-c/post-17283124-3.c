#include <stdio.h>
#include <stdlib.h>

int main (void) {

    // open a stream with popen with the (working) command    
    FILE *stream = popen("minicom -b 9600 -o -D /dev/ttyACM0", "r");

    while (!feof(stream) && !ferror(stream)) {

        // declare a buffer, read the stream
        char buf[4];
        int bytesRead = fread(buf, 1, 4, stream);

        // print stuff to see what has been read
        int *i = buf;
        printf("%i", *i);
        //for(i = 0; i < sizeof(buf); i++) {
        //   printf("%i", (int)buf[i]);
        //}

        printf("\n");
    }

    pclose(stream);
    return 0;
}
