#define  _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <stdio.h>
#include <errno.h>

/* RFID tag event types: tag read, tag lost.
*/
typedef enum {
    RFID_TAG_LOST = 0,
    RFID_TAG_READ
} rfid_event_type_t;

/* Structure describing all possible RFID tag events.
*/
typedef struct rfid_event_st  rfid_event_t;
struct rfid_event_st {
    struct rfid_event_st     *next;
    rfid_event_type_t         type;
    CPhidgetRFIDHandle        rfid;
    CPhidgetRFID_Protocol     protocol;
    void                     *userptr;
    char                      tag[];
};

static pthread_mutex_t  event_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t   event_wait = PTHREAD_COND_INITIALIZER;
static rfid_event_t    *event_queue = NULL;

/* Add event to event queue.
*/
static int add_event(const CPhidgetRFIDHandle rfid,
                     const CPhidgetRFID_Protocol protocol,
                     const rfid_event_type_t type,
                     const char *const tag,
                     void *const userptr)
{
    const size_t  taglen = (tag) ? strlen(tag) : 0;
    rfid_event_t *ev;

    /* Allocate memory for a new event. */
    ev = malloc(sizeof (rfid_event_t) + taglen + 1);
    if (!ev)
        return errno = ENOMEM;

    /* Fill in the fields. */
    ev->next = NULL;
    ev->type = type;
    ev->rfid = rfid;
    ev->protocol = protocol;
    ev->userptr = userptr;
    if (taglen > 0)
        memcpy(ev->tag, tag, taglen);
    ev->tag[taglen] = '\0';

    /* Lock event queue. */
    pthread_mutex_lock(&event_lock);

    /* Append to the event queue. */
    if (event_queue) {
        rfid_event_t *prev = event_queue;
        while (prev->next)
            prev = prev->next;
        prev->next = ev;
    } else
        event_queue = ev;

    /* Signal and unlock. */
    pthread_cond_signal(&event_wait);
    pthread_mutex_unlock(&event_lock);

    return 0;
}

/* Get next event, waiting at most 'maxwait' seconds.
*/
static rfid_event_t *get_event(const long maxwait)
{
    struct timespec until;
    rfid_event_t   *ev;

    pthread_mutex_lock(&event_lock);

    /* Event already in the queue? */
    if (event_queue) {
        ev = event_queue;
        event_queue = ev->next;
        ev->next = NULL;
        pthread_mutex_unlock(&event_lock);
        return ev;
    }

    /* No waiting requested? */
    if (maxwait <= 0L) {
        pthread_mutex_unlock(&event_lock);
        return NULL;
    }

    /* Get current wall clock time, */
    clock_gettime(CLOCK_REALTIME, &until);
    /* and add maxwait seconds. */
    until.tv_sec += maxwait;

    /* Wait for a signal. */
    pthread_cond_timedwait(&event_wait, &event_lock, &until);

    /* Event arrived in the queue? */
    if (event_queue) {
        ev = event_queue;
        event_queue = ev->next;
        ev->next = NULL;
        pthread_mutex_unlock(&event_lock);
        return ev;
    }

    /* No event; timed out. */
    pthread_mutex_unlock(&event_lock);
    return NULL;
}
