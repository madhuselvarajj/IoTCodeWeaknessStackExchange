    pid_t         child = (pid_t)-1; /* Not running */
    pid_t         p;
    rfid_event_t *event;

    /* Infinite loop */
    while (1) {

        /* Do we have a player child process? */
        if (child != (pid_t)-1) {

            /* Yes. Has it exited yet? */
            p = waitpid(child, NULL, WNOHANG);
            if (p == child) {
                /* Yes. No more player. */
                child == (pid_t)-1;
            }
        }

        /* Check for a new event.
         * If we have a child, only wait one second only
         * for the event; otherwise, wait up to 30 secs.
        */
        if (child == (pid_t)-1)
            event = get_event(30L);
        else
            event = get_event(1L);

        /* If no event yet, start at the beginning of the loop. */
        if (!event)
            continue;

        /*
         * TODO: Handle the event.
         *       You can stop the existing player via e.g.
         *       if (child != (pid_t)-1)
         *           kill(child, SIGKILL);
         *       and then start a new one.
        */

        /* Discard the event. It's dynamically allocated. */
        free(event);
    }
