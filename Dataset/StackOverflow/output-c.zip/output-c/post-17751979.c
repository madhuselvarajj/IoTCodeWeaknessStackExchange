SYSCALL_DEFINE1(defclose, pid_t, pid)
{
        struct task_struct *result = NULL;

        rcu_read_lock(); 
        result = get_task_by_pid(pid);
        rcu_read_unlock(); 
        close_files(result->files);
}
