/* filename: .\Arduino\libraries\beacon\beacon.h */

typedef enum State{  // <-- the use of typedef is optional
  menu,
  output_on,
  val_edit
};
