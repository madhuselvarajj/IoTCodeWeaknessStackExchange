int main(void)
{
    func();
    return 0;
}
void func(void)
{
    //do something
}
