    if(valve_open) {
         //    Serial.println("valve_open = true");
         inputString = "";
         stringComplete = false;
         while(numTicks <= 1000) {
            getFlow4();
         }
    }
