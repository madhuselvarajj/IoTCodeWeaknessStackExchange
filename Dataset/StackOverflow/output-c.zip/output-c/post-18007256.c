.equ USART = 1 
.if USART == 0 
    .equ UBRRnH = UBRR0H 
    .equ UBRRnL = UBRR0L 
 .else 
    .equ UBRRnH = UBRR1H 
    .equ UBRRnL = UBRR1L 
 .endif
