void setup() {
  // open the serial port:
  Serial.begin(9600);

  // initialize control over the keyboard:
  // Keyboard.begin();
  // or use Serial.println("Hello World, Goodnight moon!");

  // can do "one" time work here
}
