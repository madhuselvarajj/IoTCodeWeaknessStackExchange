#include <SimpleTimer.h>
SimpleTimer timer;

// a function to be executed periodically
// by the below timer.run in the main loop
void change_pwm() {
  if (page == 1)
    PWM++;
    set PWM for LED (analogWrite) change direction when PWM = 0 or 255
  else 
    set LED off
  end if
}

void setup() {
    Serial.begin(9600);
    timer.setInterval(10, change_pwm);
}

void loop() {
    timer.run();
    //...along with all the other stuff.
}
