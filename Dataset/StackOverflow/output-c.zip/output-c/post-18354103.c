pthread_t thread;
pthread_attr_t thread_attr;
int thread_error;

thread_error = pthread_attr_init(&thread);

if(thread_error)
{
    /* Handle error */
    return;
}

/* Make thread detached so I don't need to worry about it after it's creation */
result = pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);

if(!thread_error)
{
    thread_error = pthread_create(&thread,&thread_attr,<xmms-calling-funtion>,<arguments>);

    pthread_attr_destroy(&thread_attr);

    if(thread_error)
        /* Handle error */
}
else
    /* Handle error */
