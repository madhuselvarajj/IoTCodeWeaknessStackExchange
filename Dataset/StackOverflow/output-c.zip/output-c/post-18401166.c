#!/usr/bin/env python
import time
import os
import xively

# Xively variables specific to my account.
API_KEY = ....
FEED_ID = ....


# Continuously read data from the DHT22 sensor and upload
# the results to the Xively feed. 
while True:

    # Initialize Xively library and fetch the feed
    feed = xively.XivelyAPIClient(API_KEY).feeds.get(FEED_ID)

    feed.datastreams = [
        xively.Datastream(id='tempertature', current_value=getTemperature()),
        xively.Datastream(id='humidity', current_value=getHumidity()),
    ]
    # Upload the data into the Xively feed
    feed.update()

    # Wait 30 seconds to avoid flooding the Xively feed.
    time.sleep(30)
