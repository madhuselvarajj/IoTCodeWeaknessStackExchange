void loop()
{
   //this must be called for ethercard functions to work.
   ether.packetLoop(ether.packetReceive());
}
