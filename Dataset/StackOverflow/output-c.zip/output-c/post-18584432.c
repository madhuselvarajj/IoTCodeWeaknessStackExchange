CC  = $(CROSS_COMPILE)gcc
LD  = $(CROSS_COMPILE)ld
LDFLAGS = 
CFLAGS  = -g -Wall

TARGETS = main
#     

main:main.o
    $(LD) $(LDFLAGS) -o $@ $<

main.o:main.c
    $(CC) $(CFLAGS) -o $@ $<

clean:
    rm -rf $(TARGETS)
    rm -rf *.o
