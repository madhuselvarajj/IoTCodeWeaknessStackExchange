#include <stdio.h>

int main(int argc, char** argv)
{
    char line[200];
    line[0] = '\0';
    FILE* rf_line = popen("grep wlan0 /proc/net/wireless", "r");
    fgets(line, 200, rf_line);
    printf("%s", line);  /* You can remove this */
    pclose(rf_line);
}
