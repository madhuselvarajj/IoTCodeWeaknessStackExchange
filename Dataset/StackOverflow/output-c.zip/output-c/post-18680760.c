String txtMsg = ""; // a string for incoming text

void setup() {
    Serial.begin(9600);
    while (!Serial); // wait for serial port to connect. Needed for Leonardo only
}

void loop() {
    // add any incoming characters to the String:
    int got_start = 0;
    while (Serial.available() > 0) {
        char inChar = Serial.read();
        if (inChar == '>' && !got_start) {
            got_start = 1;
        }
        if (got_start) {
            txtMsg += inChar;
        }   
        if (inChar == '<' && got_start) {
            got_start = 0; 
            Serial.println(txtMsg);
            txtMsg = "";    
        }   
    }   
}   
