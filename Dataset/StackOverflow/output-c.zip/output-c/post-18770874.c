static void ReadLightSensor(void)
 {
                    //select pin in hex form
        P0SEL &= ~0x10; /* Set pin (sample) as GPIO */
        P0DIR &= ~0x10; /* Set pin as input*/
        P0INP |= 0x10;  /* Set as tri-state*/
        APCFG |= 0x10;  /* configure ADC on pin*/

        ADCCON3 = 0x34; /*This represents the paramters passed into ADCCON3*/

        while (!ADCIF);
        ADCIF = 0;

        tv = ADCL;
        tv |= (((unsigned short) ADCH) << 8);
        tv >>= 4 ;
        lv = tv;
                    PRINTF("Pin reading = 0x%04x\n\r", lv);
