LedControl::LedControl(uint8_t p1, uint8_t p2, uint8_t p3) 
  : pin1(p1), pin2(p2), pin3(p3)
{
  pinMode(pin1, INPUT);
  pinMode(pin2, OUTPUT);
  pinMode(pin3, OUTPUT);
  return;
}
