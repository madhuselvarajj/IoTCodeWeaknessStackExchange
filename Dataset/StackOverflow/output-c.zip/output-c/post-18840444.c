 memfill(conditions, 0, 6*20*sizeof(char *));
 for (i = 0 to 5)

   for (j = 0 to 20)

       if (conditions[i][j] == NULL) {break;}

       print("%s/n", conditions[i][j]);
       // test/compare strings, i is the enum value if a match
       // return i;

   end for j

end for i
