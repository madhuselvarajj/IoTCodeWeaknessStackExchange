boolean check(int key, char c){

    if (key == LOW) {
        if ( some_global_boolean){
            some_global_boolean = false;
            Serial.println(c);
            return true;
        }
    }

    else{
          some_global_boolean = true;
          return false;
        }
    }
}
