    int main(int argc, char const *argv[])
    {
       boolean some_global_boolean = true; //or false or w/e or initialize it as you wish
       check(4, &some_global_boolean, 'a');
       return 0;
    }

    boolean check(int key, boolean * prev_key_high, char c){

    if (key == LOW) {
        if ( *prev_key_high){
          *prev_key_high = false;
          Serial.println(c);
          return true;
        }
    }

    else {
        *prev_key_high = true;
        return false;
      }
    }
