#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char *argv[])

    {
    while (1)
        {
        char buf[256],syscmd[512];
        int i;

        /* Get next barcode */
        printf("Waiting for bar code [q=quit]:  ");
        if (fgets(buf,255,stdin)==NULL)
            break;

        /* Clean CR/LF off of string */
        for (i=0;buf[i]!='\0' && buf[i]!='\r' && buf[i]!='\n';i++);
        buf[i]='\0';

        /* q = quit */
        if (!strcmp(buf,"q"))
            break;

        /* Build into curl command */
        sprintf(syscmd,"curl \"http://www.xyz.com/test/order/complete?barcode=%s\"",buf);

        /* Execute--this will wait for command to complete before continuing. */
        system(syscmd);
        }
    return(0);
    }
