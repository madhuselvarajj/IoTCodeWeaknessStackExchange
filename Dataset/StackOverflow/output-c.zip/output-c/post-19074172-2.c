// printf("%c", rx_buffer[loop]);
if (isprint(rx_buffer[loop])) {
   printf("%c", rx_buffer[loop]);
}
else {
   printf("(%02hhX)", rx_buffer[loop]);
}
