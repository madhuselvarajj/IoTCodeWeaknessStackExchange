i = 0;
length = 0;
forever() {   
  do {
    i += length;
    length = read(&buffer[i])
    if (length means bad read) handle error;
    search buffer from i to (i+length) for End-of-packet
  } while (end-of-packet not found and buffer not too full)
  Use buffer from start to end-of-packet.
  length = i+length-end-of-packet-index
  memmove(&buffer[0], &buffer[end-of-packet-index+1], length);
  i = 0;
}
