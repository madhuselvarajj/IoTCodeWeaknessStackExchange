#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{

int cardNum, int firstCard, int secondCard; 
int highLow;
int score;

score = 0;   
srand(time(NULL));

printf("The current card is a %d\n", firstCard(2,14));
printf("\n Will the next card be higher(1) or lower(2)? (press 0 to quit)");
scanf("%d" ,highLow);

if (cardNum > 1 && cardNum < 11)
{        
     printf ("The card is: %d ,secondCard.");
}        
else if (cardNum == 11)
{
    printf ("The card is: Jack"); 
}       
else if (cardNum == 12)
{
    printf ("The card is: Queen"); 
}       
else if (cardNum == 13)
{
    printf ("The card is: King"); 
}       
else if cardNum == 14)
{
    printf ("The card is: Ace"); 
}       
{
if ((highLow == 1 && secondCard > firstCard) || (highLow == 2 && secondCard < firstCard))
    {   
        score = score + 1; 
        printf ("\n You have guessed correctly.");
        printf ("\n Your current score is %d ,score!\n");
        printf("The current card is a ("%d" ,cardOne). \n Will the next card be higher(1) or lower(2)? (press 0 to quit)");
    }    
else if ((highLow == 1 && secondCard < firstCard) || (highLow == 2 && secondCard > firstCard))  
    {
        score = score - 1;
        printf ("The card is: %d ,secondCard.");
        printf ("\n You have guessed incorrectly.");
        printf ("\n Your current score is %d ,score!\n");
        printf ("The current card is a %d ,cardOne."); 
        printf ("\n Will the next card be higher(1) or lower(2)? (press 0 to quit)");
    }
else if (secondCard == firstCard)
    {
        printf ("\n Matching cards, no change in score");
    }
else if (highLow == 0)
    {
        printf ("\n Thanks for playing! Your final score is %d, score.");
    }
else
    {
        printf ("\n Incorrect input. Please enter 0, 1 or 2");      
    }
}    
return(0);
}
