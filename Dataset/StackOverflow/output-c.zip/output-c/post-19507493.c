int main(){
    XColor c;
    get_pixel_color(display, 30, 40, &c);
    printf ("%d %d %d\n", c.red, c.green, c.blue);
    return 0;
}
