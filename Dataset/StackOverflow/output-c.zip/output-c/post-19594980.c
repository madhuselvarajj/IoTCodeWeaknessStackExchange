int i = 1;

void setup() {
  Serial.begin(9600);
  delay(1000); //wait for one second
}
