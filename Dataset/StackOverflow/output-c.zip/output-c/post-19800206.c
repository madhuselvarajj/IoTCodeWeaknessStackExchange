/* 

What does this program do:
Allows for a user to control a robotic arm
The current version uses multiple potentiometers to control the hand.

*/

#include <Servo.h> // Library that allows us to use inputs to a 179 degree servo

//Avoid magic numbers
#define MIN_POTENTIOMETER_VAL 0
#define MAX_POTENTIOMETER_VAL 1023

#define MIN_ANGLE 0
#define MAX_ANGLE 179

#define DELAY 27

Servo indexF;  // create servo object to control a servo
Servo middleF;
Servo ringF;
Servo pinkyF;
Servo thumb;
Servo wrist;
Servo forearmBicep;

// first define all of ur pots and servos
const int potpin1 = 0;  // analog pin used to connect the potentiometer
const int potpin2 = 1;  // analog pin used to connect the potentiometer
const int potpin3 = 2;  // analog pin used to connect the potentiometer
const int potpin4 = 3;
const int potpin5 = 4;

//Servo pins
const int indexFPin = 11;
const int middleFPin = 10;
const int ringFPin = 9;
const int pinkyFPin = 6;
const int thumbFPin = 5;


//Function for moving your servo
//servo is a pointer to the Servo struct. It's cheaper and faster to pass pointers, be be aware that you modify original object by that. You can avoid it by adding "const"
//pin is potpin you want to use, simple variables like int we pass by value, it means they are copied and you can do whatever you want to them, without losing original data
void moveServo(Servo* servo, int pin)
{
  int potentiometerVal = analogRead(pin);
  int mapped = map(potentiometerVal, MIN_POTENTIOMETER_VAL, MAX_POTENTIOMETER_VAL, MIN_ANGLE, MAX_ANGLE);
  if (NULL != servo)
  {
    servo->write(mapped);
  }
}

void setup() 
{ 
  indexF.attach(indexFPin);  // attaches the servo on pin 9 to the servo object 
  middleF.attach(middleFPin); // Same thing ^^
  ringF.attach(ringFPin);
  pinkyF.attach(pinkyFPin);
  thumb.attach(thumbFPin);
} 

void loop() 
{ 
   //Note "&" at the beginning of argument - it means that we pass an address, not the data itself
  moveServo(&indexF, potpin1);
  moveServo(&middleF, potpin2);
  moveServo(&ringF, potpin3);
  moveServo(&pinkyF, potpin4);
  moveServo(&thumb, potpin5);

  delay(DELAY);  // waits for the servo to get there  

} 
