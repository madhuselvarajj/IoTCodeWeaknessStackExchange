void InitTimer(){
    TCCR1A = 0;
    TCCR1B = 0;
    TCNT1  = 0;

    TCCR1A = B00000000;
    TCCR1B = B00001011;
    OCR1A=30;
    TIMSK1 = B00000010;
}

ISR(...){
 ........
if(green & (1<<BAM_pos))
    PORTD &= ~(1<<PORTD4);
else 
   PORTD |= (1<<PORTD4);

if(blue & (1<<BAM_pos))
    PORTB &= ~(1<<PORTB0);
else 
    PORTB |= (1<<PORTB0);
}
