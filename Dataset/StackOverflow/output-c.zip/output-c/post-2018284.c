int main(int argc, char **argv) {
    setup();
    while(1) {
        loop();
    }
}
