#define MAX_STR_CHARS 100
char stringToParse[MAX_STR_SIZE+1]="";
//...
void loop() {
    char b;
    int s;
    if (Serial.isAvailable()) {
        b=Serial.read();
        switch (b) {
        //Some possible string delimiters:
        case 0x0a: //LF
        case 0x0d: //CR
        case 0:    //NULL
            Serial.print("Received string is: ");
            Serial.println(stringToParse);
            //do you thing with string...
            *stringToParse=0; //reset string to next use
            break;
        default: //Add characters:
            s=strlen(stringToParse);
            if (s<MAX_STR_CHARS) { //Ensure is not writing after allocated buffer
                stringToParse[s]=b;
                stringToParse[s+1]=0;
            }
        }
    }
}
