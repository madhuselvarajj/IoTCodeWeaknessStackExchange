if (fgets(temp, sizeof(temp), file) != NULL) 
{ 
     sscanf(temp, "%d %d %d\n", &buffer[3*i], &buffer[3*i+1], &buffer[3*i+2]); 
     printf("%d %d %d\n", buffer[3*i], buffer[3*i+1], buffer[3*i+2]); 
}
