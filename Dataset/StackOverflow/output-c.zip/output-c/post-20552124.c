char text = 'World';

char buffer[25];
sprintf(buffer, "Hello  %c", text);
CvFont font;
cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX, 0.5, 0.5);
cvPutText(image, buffer, cvPoint(2, 2), &font, cvScalar(255));
