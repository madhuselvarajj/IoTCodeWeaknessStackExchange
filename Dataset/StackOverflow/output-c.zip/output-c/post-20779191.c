int main()
{
    int i, x, b;
    x = 0x3F;
    for(i = 0; i< 7; i++)
    {
        b = (x & (1 << i)) >> i;
        printf("%d ", b); // I am printing the value of b here
    }
    getchar();
    return 0;
}
