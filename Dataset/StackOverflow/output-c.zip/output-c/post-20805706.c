int last_update = 0;
void loop() {
    int mill = millis();
    if (mill-last_update > (1000/50)) {
        last_update = mill;
        update_pwm_output();
    }
}
