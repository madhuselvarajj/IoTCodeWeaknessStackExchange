import wiringpi2 as pi
from multiprocessing import Process

def process(choice):
        if choice == "1":
                pi.digitalWrite(17, 1)
        else:
                pi.digitalWrite(17, 0)

if __name__ == '__main__':
        pi.wiringPiSetupSys()
        choice = raw_input(">")
        p = Process(target=process, args=(choice,))
        p.start()
        p.join()

print('just printing something to see if gets to end')
