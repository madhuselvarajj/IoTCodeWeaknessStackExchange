#makefile

CC=gcc
CFLAGS= -g -c -Wall 
MYLIB= -lbcm2835
program:   dependencies 
 <  TAB IT!>${CC} ${CFLAGS} ${MYLIB} -o Obj dependencies
