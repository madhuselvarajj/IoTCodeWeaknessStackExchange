union Signal
{
    struct
    {
        unsigned unit   :2;
        unsigned channel:2;
        unsigned status :1;
        unsigned group  :1;
        unsigned remote :26;
    } parts;
    unsigned long data;
};

union Signal signal;

void testPassingStruct(union Signal *variable)
{
    variable->parts.status = 1;
}

void setup()
{
    signal.parts.status = 1;
    testPassingStruct(&signal);
}

void loop()
{
}
