void uglyDelayHack(int delayAmount, int lastMode){

 for (int i = 0; i < delayAmount; i++){

   delay(1); // 1 millisecond delay

   // call to a function that checks for input and changes mode 
   checkForInput(); 

   // get out of the fake delay if mode has changed
   // assumes "mode" is a global variable
   if (lastMode != mode) return;
 }
}
