#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int main()
{
    pid_t pid;
    pid = fork();
    if (pid == 0) {
        system("cat /dev/cu.usbmodem1a21 - 9600 >> num.txt");
    } else {
        /* ops */
        kill(pid, SIGKILL);
    }
    return 0;
}
