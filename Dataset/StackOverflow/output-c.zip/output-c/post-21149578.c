void printDirectory(File dir, int numTabs) {
  while(true) {
    File entry =  dir.openNextFile();
    if (! entry) {
      // no more files
      break;
    }
    for (uint8_t i=0; i<numTabs; i++) {
      Serial.print('\t');
    }

    if ( isFnMusic(entry.name()) ) { // Here is the magic
      Serial.print(entry.name());
    }

    if (entry.isDirectory()) { // Dir's will print regardless, you may want to exclude these
      Serial.print(entry.name());
      Serial.println("/");
      printDirectory(entry, numTabs+1);
    } else {
      // files have sizes, directories do not
      Serial.print("\t\t");
      Serial.println(entry.size(), DEC);
    }
    entry.close();
  }
}

bool isFnMusic(char* filename) {
  int8_t len = strlen(filename);
  bool result;
  if (  strstr(strlwr(filename + (len - 4)), ".mp3")
     || strstr(strlwr(filename + (len - 4)), ".aac")
     || strstr(strlwr(filename + (len - 4)), ".wma")
     || strstr(strlwr(filename + (len - 4)), ".wav")
     || strstr(strlwr(filename + (len - 4)), ".fla")
     || strstr(strlwr(filename + (len - 4)), ".mid")
     // and anything else you want
    ) {
    result = true;
  } else {
    result = false;
  }
  return result;
}
