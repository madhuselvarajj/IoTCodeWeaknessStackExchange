  if (iForceSensorVoltage == 0){
    Serial.println("No pressure at index finger");  
  } 
  else{
  ulForceSensorConductance = conductanceFunction(ulForceSensorResistance,         iForceSensorVoltage);
  delay(30);
  } 
