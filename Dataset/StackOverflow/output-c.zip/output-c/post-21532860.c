#include "Arduino.h"

//bii:#entry_point()
void setup(){
}
void sendRawDataToIRLED(int array[], int len){
//your code here
}
void loop()
{
    int Samsung_power[] = {4500, 243, 23};
    int Channel_1[] = {450, 23, 233, 44, 55};
    int* FunctionArray[2] = {Samsung_power, Channel_1};
    int sizeArray[] = {sizeof(Samsung_power)/sizeof(int), sizeof(Channel_1)/sizeof(int)};
    int index = 0;//whatever your index
    sendRawDataToIRLED(FunctionArray[index], sizeArray[index]);
}
