# first build project B
add_subdirectory(B)

# add include directory of project B
include_directories("${CMAKE_CURRENT_SOURCE_DIR}/B/include")

# [...] build here your project

# and finally:
target_link_libraries(A B)
