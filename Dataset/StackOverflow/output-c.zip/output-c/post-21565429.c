projA/
    CMakeLists.txt
    include/
    src/
    B/ 
       CMakeLists.txt
       include/
       src/
