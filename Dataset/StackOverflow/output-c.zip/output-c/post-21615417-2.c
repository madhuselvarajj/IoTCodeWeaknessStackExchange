void interruptfunction() { 

      //your interrupt code here

  if (digitalRead(2)==HIGH) state=true;
  else state=false;

  while(1){
    if (digitalRead(2)!=state){
      delay(50);
      if (digitalRead(2)!=state) break;
    }
  }
}
