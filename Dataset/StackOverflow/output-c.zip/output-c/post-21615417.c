void interruptfunction() { 

      //your interrupt code here

  while(1){
    if (digitalRead(2)==LOW){
      delay(50);
      if (digitalRead(2)==LOW) break;
    }
  }
}
