const String hexDigits = "0123456789abcdef";
char hex[2] = "";

hex[0] = hexDigits[ (int)line.at(i) / 16 ];
hex[1] = hexDigits[ (int)line.at(i) % 16 ];
