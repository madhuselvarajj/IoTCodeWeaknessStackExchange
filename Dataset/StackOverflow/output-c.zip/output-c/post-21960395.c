    void myDelay(int ms)
    {
      try
      {    
        Thread.sleep(ms)
      }
      catch(Exception e) {
      }
    }
