loop():
  #print and handle input
  if (navigate)
    Display_function()

Display_function():
  while(true)
    # print and do whatever
    if (nav_angle)
       Display_angle()
    else if (nav_coord)
       Display_coordinate()
    #... etc.
    if (nav_back)
      return

Display_angle():
  while(true)
    #do stuff
    if (nav_back)
      return
