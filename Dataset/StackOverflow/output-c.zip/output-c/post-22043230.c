uint8_t calculate(byte[] bytes) {
    uint16_t crc = 0xFFFF; // initial value
    // loop, calculating CRC for each byte of the string
    for (uint8_t byteIndex = 0; byteIndex < bytes.Length; ++byteIndex) {
        uint8_t bit = 0x80; // initialize bit currently being tested
        for (uint8_t bitIndex = 0; bitIndex < 8; ++bitIndex) {
            bool xorFlag = ((crc & 0x8000) == 0x8000);
            crc <<= 1;
            if (((bytes[byteIndex] & bit) ^ (uint8_t)0xff) != (uint8_t)0xff)
                crc = crc + 1;
            if (xorFlag)
                crc = crc ^ 0x1021;
            bit >>= 1;
        }
    }
    return (uint8_t)crc;
}
