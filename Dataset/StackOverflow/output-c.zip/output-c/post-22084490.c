import serial
import time
ser = serial.Serial(1)

ser.read(1)
read_val = ("nothing")

gpsfile="gpscord.dat"
l=0

megabuffer=''
def buffThis(s):
        global megabuffer
        megabuffer +=s
def buffLines():
        global megabuffer
        megalist=megabuffer.splitlines()
        megabuffer=megalist.pop()
        return megalist

def readcom():
        ser.write("ati")
        time.sleep(3)
        read_val = ser.read(size=500)
        lines=read_val.split('\n')
        for l in lines:
                if l.startswith("$GPGGA"):
                        if l[:len(l)-3].endswith("*"):
                                outfile=open('gps.dat','w')
                                outfile.write(l.rstrip())
                                outfile.close()

readcom()

while 1==1:
    readcom()

answer=raw_input('not looping , CTRL+C to abort')
