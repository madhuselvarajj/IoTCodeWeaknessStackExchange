#include <stdio.h>

int main() {
    double d = 6.626e-34l;
    printf("%.40f\n", d);
}
