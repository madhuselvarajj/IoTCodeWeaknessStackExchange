if(arr[0]=='s' & arr[1] =='t' & arr[2]=='a' & arr[3]=='r' & arr[4]=='t'){
    delay(1000);
    Serial.println("done");
}
else {
    delay(1000);
    Serial.println("oo"); 
}
