int initSingleGPIO(int pin)
{
    char buffer [50]; 
    int numBytes; 

    int fh = open("/sys/class/gpio/export", O_WRONLY);

    if(fh<0) return -1;

    sprintf(buffer, "");

    numBytes = sprintf(buffer, "%s\n%d", buffer, pin);

    int rv = write(fh, buffer, numBytes);

    close(fh);

    return rv;
}

int initGPIO(int pins[], int numPins)
{     
    int i;   
    for (i=0; i<numPins; i++)
    {
        initSingleGPIO(pins[i]);
    }

}
