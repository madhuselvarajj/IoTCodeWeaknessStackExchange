int a=10;
int b=20;
float r=0;

r = a+(b/100f);
