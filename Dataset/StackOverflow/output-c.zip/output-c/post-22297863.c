#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>

int
main(int argc, char *argv[])
{
    int a = 10;
    int b = 20;
    float f;
    char *buf;

    if (asprintf(&buf, "%d.%d", a, b) > 0) {
        f = strtof(buf, NULL);
        printf("%f\n", f);
        free(buf);
    }

    exit(EXIT_SUCCESS);
}
