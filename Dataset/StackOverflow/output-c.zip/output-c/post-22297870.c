float concat(int a, int b){
    float c;
    c = (float)b;
    while( c > 1.0f ) c *= 0.1f; //moving the decimal point (.) to left most
    c = (float)a + c;
    return c; 
}
