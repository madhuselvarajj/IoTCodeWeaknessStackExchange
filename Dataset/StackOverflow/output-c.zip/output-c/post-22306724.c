static const int enablePin[3] = { 1, 4, 7 };
static const int revPin[3]    = { 2, 5, 8 };
static const int fwdPin[3]    = { 3, 6, 9 };

// ...
int ch = Serial.read();
if (ch >= '0' && ch <= '3') {
    int selection = ch - '0';

    analogWrite(enablePin[selection], speed);
    digitalWrite(revPin[selection],   !reverse);
    digitalWrite(fwdPin[selection],   reverse);
}
