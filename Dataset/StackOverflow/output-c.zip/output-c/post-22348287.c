main()
{
int Time1;
int Time2;
int hour=10;
int minute=5;
int second=13;
int h; int m;
int  Ntime; //double has been changed to int
double Ntime2;
Time1=(3600*5)+(60*30);
Time2=(3600*hour)+(60*minute)+second;
Ntime=Time2-Time1;
Ntime2=((double)((Ntime%60)/100) + (double)(Ntime/60));

h=(int)(Ntime2);
m=((Ntime2 - (double)h)*100);
printf("hour after subtraction is : %d hour %d min",h,m) 
}
