pi@pi$ cc -O4 -S y1.c
pi@pi$ cc -O4 -S y2.c
pi@pi$ diff y1.s y2.s
13c13
<       .file   "y1.c"
---
>       .file   "y2.c"
