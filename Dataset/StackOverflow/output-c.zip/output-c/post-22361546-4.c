    .arch armv6
    .eabi_attribute 27, 3
    .eabi_attribute 28, 1
    .fpu vfp
    .eabi_attribute 20, 1
    .eabi_attribute 21, 1
    .eabi_attribute 23, 3
    .eabi_attribute 24, 1
    .eabi_attribute 25, 1
    .eabi_attribute 26, 2
    .eabi_attribute 30, 2
    .eabi_attribute 18, 4
    .file   "y1.c"
    .section        .text.startup,"ax",%progbits
    .align  2
    .global main
    .type   main, %function
main:
    @ args = 0, pretend = 0, frame = 160
    @ frame_needed = 0, uses_anonymous_args = 0
    stmfd   sp!, {r4, r5, r6, lr}
    mov     r4, #0
    sub     sp, sp, #160
.L2:
    add     r5, sp, #0
    ldr     r3, [r5, r4]!
    blx     r3
    add     r4, r4, #8
    ldr     r3, [r5, #4]
    mov     r6, r0
    mov     r0, #3
    blx     r3
    mov     r1, r0
    mov     r0, r6
    bl      getPatternValue
    sxtb    r1, r0
    ldr     r0, .L5
    bl      printf
    cmp     r4, #160
    bne     .L2
    mov     r0, #0
    bl      exit
.L6:
    .align  2
.L5:
    .word   .LC0
    .size   main, .-main
    .section        .rodata.str1.4,"aMS",%progbits,1
    .align  2
.LC0:
    .ascii  "%d\012\000"
    .ident  "GCC: (Debian 4.6.3-14+rpi1) 4.6.3"
    .section        .note.GNU-stack,"",%progbits
