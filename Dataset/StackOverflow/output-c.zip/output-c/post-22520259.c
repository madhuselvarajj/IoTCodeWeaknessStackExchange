for(x=0; x < sizeof(column) / sizeof(int); x++) {
  if (column[x] > 2) {
      column[x] = 0;
  }
}
