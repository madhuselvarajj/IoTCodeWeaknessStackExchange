while(val == 1 && timeout < 70)
    {
    val = bcm2835_gpio_lev(SIG);
    data[i] = data[i] + 1;
    dat = dat + 1;
    timeout = timeout + 1;
    delay(0.001);
    }
