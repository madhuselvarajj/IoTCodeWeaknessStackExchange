uint8_t valu = bcm2835_gpio_lev(SIG);
uint8_t val = 1;
while(valu == 0)
    {
    valu = bcm2835_gpio_lev(SIG);
    data[i] = 0;
    dan = dan + 1;
    delay(0.001);
    }
