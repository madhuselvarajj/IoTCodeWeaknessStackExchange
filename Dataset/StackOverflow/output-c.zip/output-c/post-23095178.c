 #include<stdlib.h>

 typedef struct {
   int Player;
   int Score;
 } PS_T;

 int compar(const void *va, const void *vb) {
   PS_T *ia = (PS_T *) va;
   PS_T *ib = (PS_T *) vb;
   return (ia->Score >= ib->Score) - (ib->Score >= ia->Score);
 }

 // Return true if Silver beat Bronze (detect ties after 2nd place.)
 int Sort4(int *Gold, int *Silver, 
     int Score1, int Score2, int Score3, int Score4) {
   PS_T PS[4] = { { 1, Score1 }, { 2, Score2 }, { 3, Score3} , {4, Score4} };
   qsort(PS, 4, sizeof PS[0], compar);
   *Gold = PS[0].Player;
   *Silver = PS[1].Player;
   return PS[1].Score > PS[2].Score;
 }

 ...
 int First;
 int Second;
 Sort4(&First, &Second, buttonPushCounter, buttonPushCounter2, 
   buttonPushCounter3, buttonPushCounter4);
