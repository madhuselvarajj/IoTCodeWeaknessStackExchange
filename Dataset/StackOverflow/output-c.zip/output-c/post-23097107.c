int speakerOut = A0;
int buttonPin = 13;

void setup() {
    pinMode(speakerOut, OUTPUT);
    pinMode(buttonPin, INPUT_PULLUP);
}

int a = 0;

void loop() {
    if(digitalRead(buttonPin) == LOW) {
        a ++;
        Serial.println(a);
        analogWrite(speakerOut, NULL);

        if(a > 50 && a < 300) {
            analogWrite(speakerOut, 200);
        }

        if(a <= 49) {
            analogWrite(speakerOut, NULL);
        }

        if(a >= 300 && a <= 2499) {
            analogWrite(speakerOut, NULL);
        }
    }
}
