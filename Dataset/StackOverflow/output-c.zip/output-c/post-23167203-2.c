  int truncated = 0;
  while(Serial.available() > 0) //Don't read unless you know there is data
  {
    if(index < 19) //One less than the size of the array
    {
      inChar = Serial.read(); //Read a character
      inData[index] = inChar; //Store it
      index++; //Increment where to write next
      inData[index] = '\0'; //Null terminate the string
    }
    else
    {
      truncated = 1;
      break;
    }
  }

  if(truncated && strncmp(inData, input, 19) == 0){
    index = 0;
    inData[index] = '\0';
    return(0);
  }
  else if(!truncated && strcmp(inData, input) == 0) {
    ...
  }
  else {
    ...
  }
