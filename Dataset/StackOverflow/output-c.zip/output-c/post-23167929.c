#include <SoftwareSerial.h>

#define MAXLEN 20

char getline(char* unsigned int);

void setup()
{
  //Begin Serial Communication
  Serial.begin(9600);
}

void loop(void){

  //Determine if command mode should be entered
  char cmd[MAXLEN];
  while (!getline(cmd, MAXLEN))
      ; // Wait for a complete input line

  if(strcmp("BTMODIFY", cmd) == 0)
  {
     Serial.print("Entering bluetooth command mode..."); 
  }
}

char getline(char* input, unsigned int size){
  static unsigned int i = 0;
  static char done = 0;

  while(Serial.available() > 0
          && i < size-1
          && !done)
  {
    char c = Serial.read(); //Read a character
    input[i++] = c;         //Store it and increment
    if (c == '\n')          //Or whatever newline your serial terminal is sending
    {
        done = 1;
    }
  }
  input[i] = '\0';

  if (done)
  {
    done = 0;
    return 0;
  }

  return 1;
}
