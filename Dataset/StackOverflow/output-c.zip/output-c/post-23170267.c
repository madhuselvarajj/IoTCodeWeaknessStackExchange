char Comp(const char* input) {
  size_t len = strlen(input);
  int i = 0;
  while(Serial.available() > 0) {
    if (index > (sizeof inData - 2)) {
      // toss eldest `char`
      index = sizeof inData - 2;
      memmove(&inData[0], &inData[1], index);
    }
    inChar = Serial.read(); //Read a character
    inData[index] = inChar; //Store it
    index++; //Increment where to write next
    inData[index] = '\0'; //Null terminate the string  **

    if(index >= len && memcmp(&inData[index-len], input, len) == 0) {
      index = 0;
      inData[index] = '\0'; // **
      return(0);
    }
  }
  return(1);
}
