#include <sys/select.h>
#include <unistd.h>
#include <string.h>

int main()
{
   int run = 1, rc;
   fd_set fd_list, readfd;

   FD_ZERO(&fd_list);
   FD_SET(STDIN_FILENO, &fd_list);

   while (run)
  {
    readfd = fd_list;
    rc = select(STDIN_FILENO + 1, &readfd, NULL, NULL, NULL);

    if (rc == -1)
    {
        perror("Select error");
      return 1;
    }

    if (FD_ISSET(STDIN_FILENO, &readfd) && read(STDIN_FILENO, &rc, sizeof(rc)) == 0 )
      run = 0;

  }

  return 0;
}
