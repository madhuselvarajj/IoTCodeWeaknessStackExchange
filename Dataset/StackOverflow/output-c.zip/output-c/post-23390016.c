void TimFun()
{
    static int LastRead;
    if(LastRead && (0 == analogRead(sensor1))
    {
        Serial.println("SensorTrip");
    }
    LastRead = analogRead(sensor1);
}

void loop()
{
    // Do other stuff here
}

void setup()
{
    Timer1.initialize(100000);
    Timer1.attachInterrupt(TimFun);
    // Rest of setup Here
}
