#define arraySize 32        
char inChar = '0';
char inVariable[arraySize];
byte index = 0;  
byte inDigit;     
int inNumber;
int i; //counter

String repeatstring;

void setup(){
  Serial.begin(9600);
}

void loop(){
  checkSeriale();
}

void checkSeriale(){
  while(Serial.available() > 0){
    pr("Start of 'checkSeriale' function");
    pr("Characters available in serial receive buffer: " + String(Serial.available()));
    //Serial.println(Serial.available());
    inChar = Serial.read();
    pr("Read a char into InChar: " + String(inChar));
    pr("Characters available after Serial.read(): " + String(Serial.available()));
    if(inChar != ':' && index < arraySize-1 && inChar != ';'){
      pr("First 'if' statement (inChar not equal to colon)");
      inVariable[index] = inChar;
      index++;
      inVariable[index] = '\0';
      for(i=0;i<sizeof(inVariable);i++){
        Serial.print(String(inVariable[i]));
      }
    }
    else{
      pr("Else statement for first 'if', inChar equals colon hence break");
      break;
    }
  }
  if(inChar == ':'){ 
    pr("Second 'if' statement (InChar is equal to colon)");
    index = 0;
    pr("Characters available in serial receive buffer: " + String(Serial.available()));
    while(Serial.available() >0 && index < 10 && inChar != ';'){
      inDigit = Serial.read() - '0';
      pr("Characters available after Serial.read(): " + String(Serial.available()));
      pr("inDigit: " + String(inDigit));
      pr("inNumber: " + String(inNumber));
      inNumber = inNumber * 10;
      pr("inNumber * 10: " + String(inNumber));
      inNumber = inNumber + inDigit; 
      pr("InNumber + inDigit : " + String(inNumber));
      index++; 
    }
    cambioVariabiliSeriale(inVariable);
  }

  if(inChar == ';'){
    pr("third 'if' statement (inChar is equal to semicolon)");
    cambioVariabiliSeriale(inVariable);
    inNumber=0;
    inChar='0';
    index=0;
  }

}

void cambioVariabiliSeriale(char test[]){
}

//simple debug technique - use pr("something"); in your code - askchipbug
void pr(String txt){
  if(repeatstring != txt){
    //if the debug text is different, print it
    Serial.println(txt); //prints the text and adds a newline
    delay(1000); //just pauses the scrolling text for 1 second, make bigger if you want a longer pause
    repeatstring = txt;
  }
}
