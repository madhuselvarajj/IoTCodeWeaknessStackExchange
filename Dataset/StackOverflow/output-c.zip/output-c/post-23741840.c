void checkSeriale(){
  while(Serial.available() > 0){
    Serial.println(Serial.available());
    inChar = Serial.read();
    if(inChar != ':' && index < arraySize-1 && inChar != ';'){
      inVariable[index] = inChar;
      index++;
      inVariable[index] = '\0';
    }

    else if(inChar == ':'){ 
      index = 0;
      while(Serial.available() >0 && index < 10){
        inDigit = Serial.read() - '0';
        inNumber = inNumber * 10;
        inNumber = inNumber + inDigit; 
        index++; 
      }
      cambioVariabiliSeriale(inVariable);
    }

    else if if(inChar == ';'){
      cambioVariabiliSeriale(inVariable);
      inNumber=0;
      inChar='0';
      index=0;
    }
  }
}
