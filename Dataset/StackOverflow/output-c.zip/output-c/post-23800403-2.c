int (*patterns[])[3] =
{
    pattern0,
    pattern1,
    pattern2,
    pattern3,
    pattern4,
    NULL
};
