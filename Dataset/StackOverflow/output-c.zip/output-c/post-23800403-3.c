void loop()
{
    int i, j;

    for ( i = 0; patterns[i] != NULL; i++ )
    {
        Serial.print( "Pattern " );
        Serial.println( i + 1 );
        for ( j = 0; patterns[i][j][2] != 0; j++ )
        {
            if ( patterns[i][j][0] == HIGH )
                Serial.print( "HIGH " );
            else
                Serial.print( "LOW  " );

            if ( patterns[i][j][1] == HIGH )
                Serial.print( "HIGH " );
            else
                Serial.print( "LOW  " );

            Serial.println( patterns[i][j][2] );
        }
        Serial.println( "" );
        delay( 500 );
    }
}
