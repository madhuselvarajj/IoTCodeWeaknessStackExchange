int pattern0[][3] =
{
    {HIGH, LOW, 500},
    {LOW, HIGH, 500},
    {0,      0,   0}
};

int pattern1[][3] =
{
    {HIGH, LOW, 250},
    {LOW, HIGH, 250},
    {0,      0,   0}
};

int pattern2[][3] =
{
    {HIGH, LOW, 125},
    {LOW, HIGH, 125},
    {0,      0,   0}
};

int pattern3[][3] =
{
    {HIGH, LOW, 250},
    {LOW, LOW, 250},
    {HIGH, LOW, 250},
    {LOW, LOW, 250},

    {LOW, HIGH, 250},
    {LOW, LOW, 250},
    {LOW, HIGH, 250},
    {LOW, LOW, 250},

    {0,     0,   0}
};

int pattern4[][3] =
{
    {HIGH, LOW, 125},
    {LOW, LOW, 125},
    {HIGH, LOW, 125},
    {LOW, LOW, 125},

    {LOW, HIGH, 125},
    {LOW, LOW, 125},
    {LOW, HIGH, 125},
    {LOW, LOW, 125},

    {0,     0,   0}
};
