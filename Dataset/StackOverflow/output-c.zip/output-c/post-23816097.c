while(*buffer)
{
  USART_SendData(USARTx, *buffer++);
  while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
  delay_us(5);
}
