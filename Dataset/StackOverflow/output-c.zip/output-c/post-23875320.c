char var[10];
int i = 0; // index
while (Serial.Available() > 0){
    char readval = Serial.Read();
    var[i++] = readval;
}
var[i] = 0;  // null terminate string
int int_of_var = atoi(var);
