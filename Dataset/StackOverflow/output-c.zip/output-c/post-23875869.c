bool sendTemperatures;
String readString;

void executeCommand(String cmd)
{
    if (cmd == "START") sendTemperatures = true;
    else if (cmd == "STOP") sendTemperatures = false;
    // etc...
    else Serial.println("Bad command");
}

void checkSerial()
{
    if (!Serial.available()) return;
    char c = Serial.read();
    if (c == '\n') {
        executeCommand(readString);
        readString = "";
    }
    else readString += c;
}

void sendSensorData() 
{
    // etc..
}


void loop() 
{
    checkSerial();
    if (sendTemperatures) sendSensorData();
}
