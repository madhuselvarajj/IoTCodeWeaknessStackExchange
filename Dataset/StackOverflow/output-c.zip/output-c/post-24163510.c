include($ENV{HOME}/raspberrypi/rootfs/usr/share/cmake-2.8/Modules/FindPkgConfig.cmake)
set(CMAKE_PREFIX_PATH $ENV{HOME}/raspberrypi/rootfs/)
set(SYSROOT $ENV{HOME}/raspberrypi/rootfs/)
set (PKG_CONFIG_SYSROOT_DIR ${SYSROOT})
set(PKG_CONFIG_PATH ${SYSROOT}/usr/lib/pkgconfig:${SYSROOT}/usr/local/lib/pkgconfig:${SYSROOT}/usr/lib/arm-linux-gnueabihf/pkgconfig:${SYSROOT}/usr/share/pkgconfig)
#Change 1 to 0 to disable logging
add_definitions(-DENABLE_LOG=1)
find_program(PKG_CONFIG_EXECUTABLE NAMES pkg-config PATHS /usr/bin DOC "pkg-config executable" NO_CMAKE_FIND_ROOT_PATH)
set (CMAKE_CXX_FLAGS "-W -O3 -g -Wall -std=c++0x -rdynamic  -D_TRACE ${CMAKE_CXX_FLAGS}"  CACHE STRING "" FORCE)
#rdynamic is for stack unwinding on crash
set(CMAKE_PREFIX_PATH $ENV{HOME}/raspberrypi/rootfs/)
set(CMAKE_LIBRARY_PATH $ENV{HOME}/raspberrypi/rootfs/lib:$ENV{HOME}/raspberrypi/rootfs/usr/lib:$ENV{HOME}/raspberrypi/rootfs/usr/local/lib)
set(CMAKE_MODULE_PATH $ENV{HOME}/raspberrypi/rootfs/usr/share/cmake-2.8/Modules)

include_directories(SYSTEM
$ENV{HOME}/raspberrypi/rootfs/usr/include/arm-linux-gnueabihf
$ENV{HOME}/raspberrypi/rootfs/usr/include
$ENV{HOME}/raspberrypi/rootfs/usr/local/include
)

add_definitions(
-march=armv6zk 
-mfpu=vfp 
-mfloat-abi=hard
)

link_directories(

$ENV{HOME}/raspberrypi/rootfs/lib/arm-linux-gnueabihf
$ENV{HOME}/raspberrypi/rootfs/lib
$ENV{HOME}/raspberrypi/rootfs/usr/lib/arm-linux-gnueabihf
$ENV{HOME}/raspberrypi/rootfs/usr/lib
$ENV{HOME}/raspberrypi/rootfs/usr/local/lib
)   

set_target_properties(${TARGET} PROPERTIES COMPILE_FLAGS ${CMAKE_CXX_FLAGS})
