void Wrong(int a) {
  a = 10;
}

void Right(int& a) {
  a = 20;
}

void Right(int* pA) {
  *pA = 30;
}

int a = 0;
Wrong(a);  printf("%d ", a);
Right(a);  printf("%d ", a);
Right(&a);  printf("%d\n", a);
