import subprocess

subp = subprocess.Popen("./test",stdout=subprocess.PIPE)

for line in iter(subp.stdout.readline, ''):
    print line
