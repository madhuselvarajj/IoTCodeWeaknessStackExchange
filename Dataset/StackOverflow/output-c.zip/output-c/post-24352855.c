#include <stdio.h>
#include <unistd.h>

int main(void)
    {
    int i = 0;

    for (;;)
        {
        printf("%05d\n", i % 1000000);
        i++;
        fflush(stdout);
        sleep(1);
        }
    return 0;
    }
