import subprocess
from serial import Serial
port = Serial("/dev/ttyAMA0",115200,timeout=3)

subp = subprocess.Popen("./test",stdout=subprocess.PIPE)

for line in iter(subp.stdout.readline, ''):
    port.write(line,)
    print line,
