union {
  float float_variable;
  char bytes_array[4];
} my_union;

my_union.float_variable = 1.11;
