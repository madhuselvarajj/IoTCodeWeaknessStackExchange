# New and improved Makefile (remember about the TABS vs SPACES here!)
#
XIVELY_OBJ_PATH=$(HOME)/libxively/obj
#
# Any special libraries you are using in your project
LIBS=-lrt -lwiringPi
#
# Now add all the pesky .o files
LIBS+=$(wildcard $(XIVELY_OBJ_PATH)/*.o)
LIBS+=$(wildcard $(XIVELY_OBJ_PATH)/io/posix/*.o)
#
LDFLAGS=
#
# We love the new standard
CFLAGS+=-std=c99
#
# debugging symbols always good
CFLAGS+=-g
#
CC=gcc
#
.PHONY: all clean
#
all: sensortest
#
sensortest: main.c main.h
    $(CC) $(CFLAGS) -c -o $@.o $<
    $(CC) $(CFLAGS) $(LDFLAGS) -o $@ $@.o $(LIBS)
#
clean:
    rm -f sensortest *.o
