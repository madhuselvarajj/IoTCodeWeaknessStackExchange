/*
 * Actual printf innards.
 *
 * This code is large and complicated...
 */
