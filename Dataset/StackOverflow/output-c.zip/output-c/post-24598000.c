union byte2char
{
    char c[4];
    int i;
};
