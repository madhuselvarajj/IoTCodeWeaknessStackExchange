int input[3];

for (int i = 0; i < 3; i++) {
  input[i] = Serial.read();
}
