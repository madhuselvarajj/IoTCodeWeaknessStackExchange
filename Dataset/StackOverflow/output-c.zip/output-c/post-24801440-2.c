unsigned long previousTime;
void myfunc();

void setup() {                
  Serial.begin(9600);     
}

void loop() {
  Serial.println("I'm in the loop function");
  myfunc();
}

void myfunc()
{
  unsigned long currentTime;
  unsigned long enteringTime = millis();
  while(((currentTime = millis()) - enteringTime) < 10000)
  {
    if(currentTime - previousTime > 1000)
    {
      previousTime = currentTime;
      Serial.println("I'm in the custom function");
    }
  }
}
