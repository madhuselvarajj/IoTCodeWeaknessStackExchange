void statTemp(){
    unsigned long currentMillis;
    unsigned long enteringMillis = millis();
    while (((currentMillis = millis()) -enteringMillis) < T)
    {
        if(currentMillis - previousMillis > ttemp){
        etc etc etc....
    }
    return ;
}
