void loop() 
{
  if(Serial.available() > 0)
  {
    str = Serial.readStringUntil(' ');
    //x = Serial.parseInt();
    //Serial.println(str);
    if(str.equals (data))
    {
      Serial.println("Access Granted. ");
      calfunc();
    }

    if(str.equals(data2))
    {
      digitalWrite(5, HIGH);
      digitalWrite(13, HIGH);
      Serial.println("Access Denied");
    }
  }
  delay(100);
}
