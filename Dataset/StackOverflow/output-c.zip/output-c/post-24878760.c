char *headAddress = (char *)&header;
char *buffAddress = (char *)&buff;
for (uint32_t i = 0; i < 4; i++)
{
    memcpy(data, headAddress+(i*BLOCK_SIZE), BLOCK_SIZE);
    xteaEncrypt((uint32_t*)data);
    memcpy(&buffAddress+(i*BLOCK_SIZE), data, BLOCK_SIZE);
}
