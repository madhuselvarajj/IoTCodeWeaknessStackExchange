void loop() {
  static float mean = analogRead(A0);
  int newInput = analogRead(A0);
  mean = (mean * 0.95) + (newInput * 0.05);
  Serial.println(mean);
}
