int i=0;
while(i<MAX_VAL){
   EEPROM.write ( i, arrvalues[ i ] );
   i++;
  }
