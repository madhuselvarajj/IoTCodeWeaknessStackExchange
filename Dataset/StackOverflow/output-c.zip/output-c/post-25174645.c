volatile int n = 0;

ISR(TIMER1_COMPA_vect) {
    n = 1;
}


void loop() {

    n = 0;

    // At this point the tricky compiler might think 
    // "n must be zero, why do this comparison?"
    // it might also think,
    // "hey, I've got the value of n still sitting in a
    // register, I don't even have to read it from memory
    // The volatile keyword says "stop thinking"

    if(n == 1) {
      // do something when ISR() occurred just before if()
      // a very small window, but it would eventually happen
      n = 0;
    }

 }
