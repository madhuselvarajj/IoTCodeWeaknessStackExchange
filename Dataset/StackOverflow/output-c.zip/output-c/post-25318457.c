#include <stdio.h>
#include <stdint.h>

#define MY_BYTES 0x26,0x28,0X1B,0X52,0X07,0X62,0X62 


int main(void) 
{
    uint8_t a[] = {MY_BYTES};
    int i;

    for ( i = 0; i < sizeof( a ) / sizeof( *a ); i++ ) printf( "%d ", a[i] );
    puts( "" );

    return 0;
}
