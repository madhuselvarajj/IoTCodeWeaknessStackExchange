for (int x=0; x<=100000;x++){
    //wait to make the 1024 iteration blinking visible
    BUTTON5_state = digitalRead(START_BUTTON);

    if (BUTTON5_state == HIGH ){
        break;
    }
    else if (x & (1 << 10)){ //each 1024th iteration
        toggleLed();
    }
}
