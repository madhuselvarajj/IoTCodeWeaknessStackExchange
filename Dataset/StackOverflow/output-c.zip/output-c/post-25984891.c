i2c_write(int file, int address, int subaddress, int size, char *data) {
    char buf[size + 1];               // note: variable length array
    ioctl(file, I2C_SLAVE, address);  // real code would need to check for an error
    buf[0] = subaddress;              // need to send everything in one call to write
    memcpy(buf + 1, data, size);      // so copy subaddress and data to a buffer 
    write(file, buf, size + 1); 
}
