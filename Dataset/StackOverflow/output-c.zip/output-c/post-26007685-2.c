void loop(){
  digitalWrite(resistorPin,HIGH);
  delay(onTime);
  digitalWrite(resistorPin,LOW);
  delay(offTime);
}
