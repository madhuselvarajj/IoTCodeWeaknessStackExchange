const int onTime=1000; // in ms
const int offTime=12000; // in ms
const int resistorPin=7; // Change as necessary
boolean currentlyOn=false;
unsigned long startTime;

void setup(){
  pinMode(resistorPin,OUTPUT);
  digitalWrite(resistorPin,LOW);
  startTime=millis(); // Initialize
}

void loop(){
  if (currentlyOn && millis()>startTime+onTime){ // Switch resistor off
    digitalWrite(resistorPin,LOW);
    currentlyOn=false;
    startTime=millis(); // Reset timer
  }
  if (!currentlyOn && millis()>startTime+offTime){ // Switch resistor on
    digitalWrite(resistorPin,HIGH);
    currentlyOn=true;
    startTime=millis(); // Reset timer
  }
  delay(10);
}
