const byte greenLed = 2;
const byte yellowLed = 3;
const byte redLed = 4;
const byte redYellow[2] = {redLed, yellowLed} // create an array of 2 pins


void setup() {
pinMode(greenLed, OUTPUT);
pinMode(yellowLed, OUTPUT);
pinMode(redLed, OUTPUT);
}

    void loop() {
    // the middle number is the number of LEDs the function will need to control.
        trafiksignal(redLed, 1, 3000);
        trafiksignal(redYellow, 2, 1000);
        trafiksignal(greenLed, 1, 3000);
        trafiksignal(yellowLed, 1, 1000);
    }

    void trafiksignal(byte pin[], unsigned int numberOfLeds, unsigned int duration)
    {
      for (int i =0; i < numberOfLeds; ++i {
        digitalWrite(pin[i], HIGH);
      }
        delay(duration);
       for (int i = 0; i < numberOfLeds; ++i) {
        digitalWrite(pin[i], LOW);
       }
    }
