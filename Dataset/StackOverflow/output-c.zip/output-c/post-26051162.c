if (pin == 1) {
  digitalWrite(3, HIGH);
  digitalWrite(4, HIGH);
  delay(duration)
  digitalWrite(3, LOW);
  digitalWrite(4, LOW);
 }
else {
  digitalWrite(pin, HIGH);
  delay(duration);
  digitalWrite(pin, LOW);
}
