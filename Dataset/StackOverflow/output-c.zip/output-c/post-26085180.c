//exact address depends on IC model and <A0:A2> wiring
#define dip_addr       0x38 
...

byte rdata = 0xFF;

Wire.beginTransmission(dip_addr);
Wire.send((uint8_t)0);  
Wire.endTransmission();

Wire.requestFrom(dip_addr,1);

if (Wire.available()) rdata = Wire.receive();

Serial.println ("DIP: " + String(rdata, DEC));
