#include <stdio.h>

void functionOne(int x)   { puts ("1"); }
void functionTwo(int x)   { puts ("2"); }
void functionThree(int x) { puts ("3"); }
void functionFour(int x)  { puts ("4"); }
void functionFive(int x)  { puts ("5"); }
void functionSix(int x)   { puts ("6"); }

void (*functionsArray[2][3])(int x) = {
    {functionOne,  functionTwo,  functionThree},
    {functionFour, functionFive, functionSix}
};

int main (void) {
    (functionsArray[0][1])(99);
    (functionsArray[1][2])(99);
    return 0;
}
