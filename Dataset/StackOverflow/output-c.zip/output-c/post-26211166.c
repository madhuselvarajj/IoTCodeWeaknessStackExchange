#include <stdio.h>

int functionOne(int x)   { return 1; }
int functionTwo(int x)   { return 2; }
int functionThree(int x) { return 3; }
int functionFour(int x)  { return 4; }
int functionFive(int x)  { return 5; }
int functionSix(int x)   { return 6; }

int (*functionsArray[2][3])(int x) = {
    {functionOne,  functionTwo,  functionThree},
    {functionFour, functionFive, functionSix}
};

int main (void) {
    printf ("%d\n", (functionsArray[0][1])(99));
    printf ("%d\n", (functionsArray[1][2])(99));
    return 0;
}
