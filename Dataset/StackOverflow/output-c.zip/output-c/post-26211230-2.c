void foo()
{
}

int (*fp)(int x) = foo;
