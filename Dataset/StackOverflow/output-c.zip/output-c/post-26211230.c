int (*functionsArray[2][3])(int x) = 
{
   {functionOne,functionTwo,functionThree},
   {functionFour,functionFive,functionSix}
};
