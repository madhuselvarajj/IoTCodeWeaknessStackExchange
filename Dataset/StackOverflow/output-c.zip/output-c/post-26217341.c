cd ~/Downloads
tar zxvf SDL2*.tar.gz
cd SDL2*

./configure --disable-video-x11
make
sudo make install
