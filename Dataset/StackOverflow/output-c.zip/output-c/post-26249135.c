delay:  call delay1             ; push the PC onto the stack
delay1: pop  r30                ; pop the PC into the Z registers
        pop  r31
        add  r30,r0             ; add some amount to the PC value
        addc r31,r1
        ijmp                    ; use IJMP to jump to the resulting address
        nop
        nop
        nop
        ...
