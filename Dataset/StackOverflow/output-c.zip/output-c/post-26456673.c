float contSurfArea(float x, float y){
  float z;
  z = (3.14159*x*x)+(2*3.14159*x*y);
  return (z);
}




 void setup()
  {
    Serial.begin(9600); //serial communication initialized


}

void loop(){
  float baseRad, contHeight = -1; 
  char junk = ' ';

  Serial.println("Open-top Cylindrical Container Program");
  delay(2000);

  Serial.println("Radius of the base(in meters): ");
  while (Serial.available() == 0); //Wait here until input buffer has a character
  baseRad = Serial.parseFloat();
  Serial.print("baseRad = "); Serial.println(baseRad, DEC);
  while (Serial.available() > 0) { //parseFloat() can leave non-numeric characters
    junk = Serial.read(); //clear the keyboard buffer
  }

  Serial.println("Height of the container(in meters): ");
  while (Serial.available() == 0); //Wait here until input buffer has a character
  contHeight = Serial.parseFloat();
  Serial.print("contHeight = "); Serial.println(contHeight, DEC);
  while (Serial.available() > 0) {
    junk = Serial.read(); //clear the keyboard buffer
  }

  float q;
  q = contSurfArea(baseRad, contHeight);

  Serial.print("The surface area of your container is: ");
  Serial.print(q);
  Serial.print( "meters^2");

}
