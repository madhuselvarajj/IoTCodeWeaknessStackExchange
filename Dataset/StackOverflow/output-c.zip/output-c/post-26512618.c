unsigned long redButtonPress = 0;
unsigned long yellowButtonPress = 0;

void setup()
{
  pinMode(0, OUTPUT);
  pinMode(1, OUTPUT);
  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(7, OUTPUT);
  pinMode(8, OUTPUT);
  pinMode(9, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(11, OUTPUT);
  pinMode(12, INPUT);
  pinMode(13, INPUT);
}

void loop()
{
  if (digitalRead(12) == HIGH && yellowButtonPress+399 < millis())
  {
    yellowButtonPress = millis();
  }
  if (digitalRead(11) == HIGH && redButtonPress+399 < millis())
  {
    redButtonPress = millis();
  }


  if (millis() <= yellowButtonPress+99 && millis() >= yellowButtonPress+2)
  {
    digitalWrite(2, HIGH);
  }else{digitalWrite (2, LOW);}

  if (millis() <= redButtonPress+99 && millis() >= redButtonPress+2)
  {
    digitalWrite(6, HIGH);
  }else{digitalWrite (6, LOW);}

  if (millis() >= yellowButtonPress+100 && millis() <= yellowButtonPress+199)
  {
    digitalWrite(3, HIGH);
  }else{digitalWrite (3, LOW);}

  if (millis() >= redButtonPress+100 && millis() <= redButtonPress+199)
  {
    digitalWrite(7, HIGH);
  }else{digitalWrite (7, LOW);}

  if (millis() >= yellowButtonPress+200 && millis() <= yellowButtonPress+299)
  {
    digitalWrite(4, HIGH);
  }else{digitalWrite (4, LOW);}

    if (millis() >= redButtonPress+200 && millis() <= redButtonPress+299)
  {
    digitalWrite(8, HIGH);
  }else{digitalWrite (8, LOW);}

  if (millis() >= yellowButtonPress+300 && millis() <= yellowButtonPress+399)
  {
    digitalWrite(5, HIGH);
  }else{digitalWrite (5, LOW);}

  if (millis() >= redButtonPress+300 && millis() <= redButtonPress+399)
  {
    digitalWrite(9, HIGH);
  }else{digitalWrite (9, LOW);}
}
