int val = 0;
for(int j = i+1; j < size; j++){
    if(isdigit(input[j] )){
        val = val * 10 + input[j]-'0';// val = (val << 8) | input[j];
    }   
}
return val;
