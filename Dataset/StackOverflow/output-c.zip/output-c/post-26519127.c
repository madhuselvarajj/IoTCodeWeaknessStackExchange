const uint8_t hrmSet[] = "Heart Rate:";

int compare_string( uint8_t *input, const uint8_t *expected, int size )
{
    for ( int i = 0; i < size; i++ )
    {
        if ( *input != *expected || *expected == '\0' )
            return( -1 );

        if ( *input == ':' && *expected == ':' )
            return( i + 1 );

        input++;
        expected++;
    }

    return( -1 );
}

int parse( uint8_t *input, uint8_t size )
{
    int i, val;

    if ( (i = compare_string( input, hrmSet, size )) < 0 )
        return( -1 );

    val = 0;
    for ( ; i < size && isdigit( input[i] ); i++ )
        val = val * 10 + input[i] - '0';

    return( val );
}

int main( void )
{
    uint8_t input[] = "Heart Rate:75";
    int rate = parse( input, sizeof(input) - 1 );
    printf( "%d\n", rate );
}
