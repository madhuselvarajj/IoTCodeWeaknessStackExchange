          int write(int file, char *ptr, int len) {
            int todo;

            for (todo = 0; todo < len; todo++) {
              outbyte (*ptr++);
            }
            return len;
          }
