float prev_voltage0[9];
float prev_voltage1[9];

for (...) {
    ....
    //difference is (voltage0 - prev_voltage0[row])
    prev_voltage0[row] = voltage0;
    prev_voltage1[row] = voltage1;
    delay(2000);
}
