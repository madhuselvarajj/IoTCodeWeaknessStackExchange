int main(void) {

    // PIC Initializations should go here
    OSCCAL= 0x00;
    CMCON0 = 0x51;
    TRISGPIO = 0x08;
    GPIO= 0xFF;

    while(1) {
        // Program main loop (should never end)
    }

    return 0; // we should never reach this
}
