unsigned long yellowButtonPress = 0;
unsigned long yellowTimeElapsed = 0;
int yellowLED = 2

unsigned long redButtonPress = 0;
unsigned long redTimeElapsed = 0;
int redLED = 6

unsigned long MAX_Time = 400;

void setup(){
  //Setup the INPUT and OUTPUT pins
  for (int x=2; x<10; x++){
    pinMode(x, OUTPUT);
  }
    pinMode(12, INPUT);  //Yellow Button
    pinMode(13, INPUT);  //Red Button
}

void loop{
  yellowTimeElapsed = millis() - yellowButtonPress;
  redTimeElapsed = millis() - redButtonPress;

  //Check if yellow button has been pressed
  if(digitalRead(12) == HIGH && yellowTimeElapsed > MAX_Time){
    yellowButtonPress = millis();
  }

  //Check if red button has been pressed
  if(digitalRead(13) == HIGH && redTimeElapsed > MAX_Time){
    redButtonPress = millis();
  }

  //Identify which yellow LED needs to be on at this time
  if (yellowTimeElapsed > Max_Time){
    yellowLED=0; //This will turn off all yellow LEDs
  } else {
    yellowLED = map(yellowTimeElapsed, 0, MAX_Time, 2,5);
  }

  //Identify which red LED needs to be on at this time
  if (redTimeElapsed > Max_Time){
    redLED=0;  //This will turn off all red LEDs
  } else {
    redLED = map(redTimeElapsed, 0, MAX_Time, 6,9);
  }

  //Turn the yellow and/or red LEDs on and off
  for (int i = 2; i<10; i++){
    if (i == yellowLED || i == redLED){
      digitalWrite(i,HIGH);
    } else {
      digitalWrite(i,LOW);
    }
  }
}
