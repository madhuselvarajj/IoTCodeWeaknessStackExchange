readInt = read(fd, bufferRecv, sizeof(bufferRecv) - 1);
if (readInt < 0){
    perror("Unable to read from the port\n");
    return -3;
}
bufferRecv[readInt] = '\0';
printf("ADC value read = %s\n", bufferRecv);
