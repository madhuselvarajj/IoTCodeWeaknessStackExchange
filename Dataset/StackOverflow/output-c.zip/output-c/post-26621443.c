#include <termios.h>

struct termios  serialSettings;
speed_t     spd;
int fd;
int rc;

fd = open(deviceName, O_RDWR | O_NOCTTY);
if (fd == -1) {
    printf("\n %s\n", deviceName);
    perror("unable to open port");
    return -1;
}

rc = tcgetattr(fd, &serialSettings);
if (rc < 0) {
    perror("unable to get attributes");
    return -2;
}

spd = B115200;
cfsetospeed(&serialSettings, spd);
cfsetispeed(&serialSettings, spd);

serialSettings.c_cflag &= ~CSIZE;
serialSettings.c_cflag |= CS8;

serialSettings.c_cflag &= ~PARENB;
serialSettings.c_cflag &= ~CSTOPB;

serialSettings.c_cflag &= ~CRTSCTS;    /* no HW flow control? */
serialSettings.c_cflag |= CLOCAL | CREAD;

serialSettings.c_iflag &= ~(PARMRK | ISTRIP | IXON | IXOFF | INLCR);
serialSettings.c_iflag |= ICRNL;
serialSettings.c_oflag &= ~OPOST;
serialSettings.c_lflag &= ~(ECHO | ECHONL | ISIG | IEXTEN);
serialSettings.c_lflag |= ICANON;

rc = tcsetattr(fd, TCSANOW, &serialSettings);
if (rc < 0) {
    perror("unable to set attributes");
    return -2;
}
/* serial port is now configured and ready */
...
