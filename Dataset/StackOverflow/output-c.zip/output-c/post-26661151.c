char delta(int e, char *z) 
{
    char result;

    /* do whatever here... */

    return result; 
}

char z[4] = "z_0";
int e = 0;

char result = delta(e, z);
