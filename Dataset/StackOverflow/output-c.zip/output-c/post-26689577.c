unsigned char buffer[32];

void setup() {
  serial.begin();
}

void loop() {
  if(serial.available()) {
    int size = serial.read(buffer);
    if (size!=0) {
      //serial.write((const uint8_t*)buffer, size);
      int bright = atoi((char *) buffer);

      //int final = ((unsigned int)buffer[0]);

      //int final = bright -'0';
      serial.write(bright);
      serial.write('\n');
    }
  }
  serial.poll();
}
