#include <stdio.h>

int test_func( char *s ) {
        if( s == NULL ) {
                fprintf( stderr,
                        "%s: recieved null pointer argument\n", __func__ );
                return -1;
        }
        /* ... */
}

int main() {

    //test_func(str)  call the function with the required parameters

    return 0;

}
