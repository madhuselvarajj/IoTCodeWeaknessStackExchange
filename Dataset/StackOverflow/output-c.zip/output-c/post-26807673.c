String command;

void loop()
{
    if(readCommand())
    {
        parseCommand();
        Serial.println(command);
        command = "";
    }
}

void parseCommand()
{
  //Parse command here
}

int readCommand() {
    char c;
    if(Serial.available() > 0)
    {
        c = Serial.read();
        if(c != '\n')
        {       
            command += c;
            return false;
        }
        else
            return true;

    }
} 
