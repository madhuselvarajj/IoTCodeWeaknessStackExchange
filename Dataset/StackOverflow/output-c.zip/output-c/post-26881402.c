int startVideoRecording() {
    int error;
    error = 0;

    if ((AVRecordingProcess = fork()) != -1) {
        switch (AVRecordingProcess) {
            case -1:
                printf("Error: Fail to create AVRecordingProcess\n");
                error = -1;
            case 0:
                setpgid(AVRecordingProcess,0);  <-- NEW
                execl("record.sh", "0", NULL);
                //system("//root//record.sh");
                printf("Error: Fail to execute AVRecordingProcess\n");
                error = -1;
            default:
               printf("Video Recording...process id %d\n", AVRecordingProcess); 
                break;
        }
    } else {  
        printf("Error: MainHost failed to fork AVRecordingProcess\n");
        error = -1;
    } 

    return error;

}

void stopAllRecordings() {
    int ret; 
    FILE *infile, *outfile;
    int ch;


    printf("Terminating child processes..%d\n", AVRecordingProcess);
    ret = killpg(AVRecordingProcess, SIGINT); <-- NEW
    printf("Sending interrupt to GStreamer process.. Status %d\n", ret);

    int status;
    printf("Wait for the GStreamer process %d to end....", AVRecordingProcess);
    waitpid(AVRecordingProcess,0,0); <-- NEW
    printf("GStreamer ended.\n"); 
}
