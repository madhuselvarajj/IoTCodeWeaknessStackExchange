#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "stb_image.h"

double compare_pictures(const char* path1, const char* path2);

double compare_pictures(const char* path1, const char* path2)
{
    double totalDiff = 0.0;
    unsigned int x, y;

    int width1, height1, comps1;
    unsigned char * image1 = stbi_load(path1, &width1, &height1, &comps1, 0);

    int width2, height2, comps2;
    unsigned char * image2 = stbi_load(path2, &width2, &height2, &comps2, 0);

    if (image1 == NULL || image2 == NULL)
    {
        fprintf(stderr, "One of the images does not exist\n");
        return -1;
    }

    if ((width1 != width2) || (height1 != height2))
    {
        fprintf(stderr, "width/height of the images must match!\n");
        return -1;
    }
    else 
    {
        for (y = 0; y < height1; y++)
        {
            for (x = 0; x < width1; x++)
            {
                totalDIff += fabs((int)image1[(x + y*width1) * comps1 + 0] - (int)image2[(x + y*width2) * comps2 + 0]) / 255.0;
                totalDiff += fabs((int)image1[(x + y*width1) * comps1 + 1] - (int)image2[(x + y*width2) * comps2 + 1]) / 255.0;
                totalDiff += fabs((int)image1[(x + y*width1) * comps1 + 2] - (int)image2[(x + y*width2) * comps2 + 2]) / 255.0;
            }
        }
        totalDiff = 100.0 * totalDiff / (double)(width1 * height1 * 3);
        printf("%lf\n", totalDiff);
        return totalDiff;
    }
}
