// Servo trial 11/15/14 by SLC

#include <wiringPi.h>

#include <stdio.h>
#include <unistd.h>

int main()
{
    wiringPiSetup();
    pinMode( 6, OUTPUT );
    digitalWrite( 6,  HIGH );

    int idx = 0, tries = 0;
    while ( tries++ < 30 )
    {
        int i;
        const int period[] = { 500, 1500, 2500 };

        printf( "Setting period to %i ms\n", period[idx] );
        for ( i = 0; i < 20; ++i )
        {
            // Output going through an inverter (to convert 3.3V to 5V)
            digitalWrite( 6, LOW );
            usleep( period[idx] );
            digitalWrite( 6,  HIGH );
            usleep( 20 * 1000 );
        }
        ++idx;
        idx %= 3;

        sleep( 2 );
    }
}
