class MyApp(object):
  def __init__(self):
    self._counter = 0
    registerInterrupt(self.interruptHandler)

  def interruptHandler(self):
    self._counter += 1

  def getCount(self):
    return self._counter
