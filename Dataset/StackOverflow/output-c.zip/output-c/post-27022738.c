#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef STB_IMAGE_IMPLEMENTATION
    #define STB_IMAGE_IMPLEMENTATION
    #include "stb_image.h"

    #ifndef STBI_ASSERT
        #define STBI_ASSERT(x)
    #endif
#endif

#define COLOR_R 0
#define COLOR_G 1
#define COLOR_B 2
#define OFFSET 10

double compare_pictures(const char* path1, const char* path2);

double compare_pictures(const char* path1, const char* path2)
{
    double totalDiff = 0.0, value;
    unsigned int x, y;

    int width1, height1, comps1;
    unsigned char * image1 = stbi_load(path1, &width1, &height1, &comps1, 0);

    int width2, height2, comps2;
    unsigned char * image2 = stbi_load(path2, &width2, &height2, &comps2, 0);

    if (image1 == NULL || image2 == NULL)
    {
        return -1;
    }

    if ((width1 != width2) || (height1 != height2))
    {
        return -2;
    }
    else
    {
        for (y = 0; y < height1; y++)
        {
            for (x = 0; x < width1; x++)
            {
                // Calculate difference in RED 
                value = (int)image1[(x + y*width1) * comps1 + COLOR_R] - (int)image2[(x + y*width2) * comps2 + COLOR_R];
                if (value < OFFSET && value > (OFFSET * -1)) { value = 0; }
                totalDiff += fabs(value) / 255.0;

                // Calculate difference in GREEN 
                value = (int)image1[(x + y*width1) * comps1 + COLOR_G] - (int)image2[(x + y*width2) * comps2 + COLOR_G];
                if (value < OFFSET && value > (OFFSET * -1)) { value = 0; }
                totalDiff += fabs(value) / 255.0;

                // Calculate difference in BLUE
                value = (int)image1[(x + y*width1) * comps1 + COLOR_B] - (int)image2[(x + y*width2) * comps2 + COLOR_B];
                if (value < OFFSET && value > (OFFSET * -1)) { value = 0; }
                totalDiff += fabs(value) / 255.0;
            }
        }
        totalDiff = 100.0 * totalDiff / (double)(width1 * height1 * 3);
        return totalDiff;
    }
}
