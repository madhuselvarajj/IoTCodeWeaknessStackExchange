String str;

while (Serial.available() > 0) {
    str = Serial.readString();
}
