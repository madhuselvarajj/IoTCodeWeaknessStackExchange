#define ULONG_MAX 0xFFFFFFFFUL

unsigned long startTimeKeeper, stopTimeKeeper, elapsedTime;
volatile boolean buttonFlag = false, signalFlag = false;

void setup() {
  Serial.begin(9600);

  pinMode(2, INPUT);
  pinMode(7, INPUT);
  pinMode(13, OUTPUT);
  pinMode(8, OUTPUT);

  // Int.2 corresponds to pin 2
  attachInterrupt(2, buttonPressed, FALLING);
  // Int.4 corresponds to pin 7
  attachInterrupt(4, signalReceived, RISING);
}

void loop() {
  // Loop until the buttonPressed ISR sets this flag
  if (buttonFlag) {
    // Record the start time
    startTimeKeeper = micros();

    // Do nothing until the signal flag is set by the ISR
    while (!signalFlag);

    // Record the end time
    stopTimeKeeper = micros();

    // Normal case - stop time is apparently after start time
    if (stopTimeKeeper > startTimeKeeper)
      elapsedTime = stopTimeKeeper - startTimeKeeper;
    // Overflow case - stop time is apparently before start time
    else
      elapsedTime = stopTimeKeeper + (ULONG_MAX - startTimeKeeper);

    Serial.print(elapsedTime);

    signalFlag = buttonFlag = false;
  }
}

// Very lightweight ISRs
void buttonPressed() {
  buttonFlag = true;
}

void signalReceived() {
  signalFlag = true;
}
