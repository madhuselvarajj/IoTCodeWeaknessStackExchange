switch(obj[4]) {
    case 'r':
        Serial.println("RED: " + red_brightness );
    case 'g':
        Serial.println("GREEN: " + green_brightness );
    case 'b':
        Serial.println("BLUE: " + blue_brightness );
}
