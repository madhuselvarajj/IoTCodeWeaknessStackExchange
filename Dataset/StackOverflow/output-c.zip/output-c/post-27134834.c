// Assuming these are globals.
int red_brightness, green_brightness, blue_brightness;

// Use this array to help you parse.
static const struct {
    const char *optionName;
    int        *brightness;
    const char *label;
} ledOptions[] = {
    { "led_r", &red_brightness,   " RED: "   },
    { "led_g", &green_brightness, " GREEN: " },
    { "led_b", &blue_brightness,  " BLUE: "  },
};

// A handy macro for later.
#define DIM(array)  (sizeof(array) / sizeof(array[0]))

...

// Now in your actual code:    
strlcpy(obj, &jarr[i], arr[i]);
for (j=0;j<DIM(ledOptions);j++) {
    if( !strcmp( obj, ledOptions[i].optionName ) ){
        i++;
        strlcpy( obj, &jarr[i], arr[i] );
        *ledOptions[i].brightness = atoi( obj );

        Serial.print(ledOptions[i].label);
        Serial.println(*ledOptions[i].brightness);
    }
}
