for (int i=0; i<6; i++)
{
   i++;
   int b = atoi( &jarr[i] );
   switch (i)
   {
     case 1:
        Serial.print(" RED: ");
        red_brightness = b;
        break;
     case 3: 
        Serial.print(" GREEN: ");
        green_brightness = b;
        break;
     case 5:
        Serial.print(" BLUE: ");
        blue_brightness = b;
        break;
     default:
        break;
   }
   Serial.println(b);
}
