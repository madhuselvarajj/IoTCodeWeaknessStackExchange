 RED :200
 GREEN :100
 BLUE :150
test0 : miss 0
miss 1 wrong color order expected RED
 GREEN :200
miss 2 wrong color order expected BLUE
 RED :100
miss 3 wrong color order expected GREEN
 BLUE :150
test1 : miss 3
miss 1 wrong variable expected led_r
miss 2 wrong variable expected led_r
miss 3 wrong color order expected RED
miss 4 wrong color order expected GREEN
 BLUE :150
test2 : miss 4
