#ifndef ARDUINO
#include <string.h>
#include <stdio.h>

/* PART of code derived from question but unspecified in code . done to be able to compile */

// this is not specified in question 
//   either it a char jarr[1024] but then why do we iterate on char ( i++ would go to next char and not to next word )
//   either it is a char* jar[6] but then we access its char * content with jarr[i] and not with &jarr[i]
//char * jarr[6];
// this look like to be size of each argument.
//int arr[6];

/*
TEST vectors
 */

char * jarr0[] = { "led_r", "200", "led_g", "100", "led_b", "150" };
int arr0[] = { 5, 3, 5,3, 5,3 };

char * jarr1[] = { "led_g", "200", "led_r", "100", "led_b", "150" };
int arr1[] = { 5, 3, 5,3, 5,3 };

char * jarr2[] = { "lgd_g", "200", "ged_r", "100", "led_b", "150" };
int arr2[] = { 5, 3, 5,3, 5,3 };

int red_brightness = 0;
int blue_brightness = 0;
int green_brightness = 0;

/* end of unspecified PART */
#endif

/*real code *

/* use indirection */
struct led_color_map {
  int * color_brightness_p;
  const char * color_name;
  char key;
} led_color[] = {
  {&red_brightness,"RED",'r'},
  {&green_brightness,"GREEN",'g'},
  {&blue_brightness,"BLUE",'b'}
};


enum { RED_IDX=0, GREEN_IDX, BLUE_IDX };

// for perf test
int miss = 0;

#ifdef ARDUINO
void led_setup()
#else
  void led_setup(char * jarr[], int arr[])
#endif
{

  char* obj=NULL;
  int i=0;
  int offset=0;

  for (i=0; i <6; i+=2)
    {
      obj=jarr[i];
      // test 'led_' prefix with reverse statistical letter apparence
      // which is 'l' then 'd' then 'e' , guessing that '_' can be used in other words ... 
      if ( ( obj[0] == 'l' ) && ( obj[2] == 'd' ) && (obj[1] == 'e' ) && (obj[3] == '_') )
    {
      int idx=0;
      for ( idx = 0; idx <= BLUE_IDX; idx ++)
        {
          int rolling_idx = (idx + offset) % ( BLUE_IDX + 1 );
          struct led_color_map * color_found = &led_color[rolling_idx]; 
          if ( color_found->key == obj[4] )
        {
          char ivalue[32];
          if ( arr[i+1] < sizeof(ivalue) )
            {
              #ifdef ARDUINO
              strlcpy(ivalue, jarr[i+1], arr[i+1]);
              #else
              strncpy(ivalue, jarr[i+1], arr[i+1]);
              #endif
              {
            int brightness = atoi( ivalue );
            *(color_found->color_brightness_p) = brightness;
            #ifdef ARDUINO
            Serial.print( color_found->color_name );
            Serial.println( *color_brightness );
            #else
            printf(" %s :%i\n", color_found->color_name, brightness);
            #endif
              }
              offset=(rolling_idx + 1) % ( BLUE_IDX + 1 ); // try with next color first next time.
              break;
            }
        }
          else
        {
          miss ++;
          printf("miss %i wrong color order expected %s\n",miss, led_color[rolling_idx].color_name);
        }
        }     
    }
      else
    {
      miss ++;
      printf("miss %i wrong variable expected led_%c\n", miss, led_color[offset % ( BLUE_IDX + 1 )].key);
    }
    }

}

#ifndef ARDUINO
int main(int argc, char ** argv)
{

led_setup(jarr0, arr0);
 printf("test0 : miss %i\n",miss);

miss=0;
led_setup(jarr1, arr1);
 printf("test1 : miss %i\n",miss);

miss=0;
led_setup(jarr2, arr2);
 printf("test2 : miss %i\n",miss);

}
#endif
