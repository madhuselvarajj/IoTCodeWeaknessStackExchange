char obj[5];
strlcpy(obj, &jarr[i], arr[i]);
int *brightness;
String ostr();
if( !strcmp( obj, "led_r" ) ){
 ostr = " RED: ";
 brightness = red_brightness;
}
if( !strcmp( obj, "led_g" ) ){
 ostr = " GREEN: ";
 brightness = green_brightness;
}
if( !strcmp( obj, "led_b" ) ){
 ostr = " BLUE: ";
 brightness = blue_brightness;
}
i++;
strlcpy( obj, &jarr[i], arr[i] );
*brightness = atoi( obj );
Serial.print(ostr);
Serial.println(*brightness);
