/* these assume red in the msbs, blue in the lsbs. */
const uint32_t red = 0xff0000;
const uint32_t purple = 0xff00ff;
const uint32_t yellow = 0xffff00;
/* and so on */
