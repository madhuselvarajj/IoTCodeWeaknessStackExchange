if (isASH(&buf)) {
  // This is ASH
  ASHtoChar(...);
} else {
  // This is not ASH
}
