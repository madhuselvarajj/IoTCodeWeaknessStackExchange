  CvSize size = cvSize(100, 100);
  if ((img = cvCreateImage(size, IPL_DEPTH_16S, 1)) != NULL) {
     img = frame;
     cvSaveImage(pathToImage, img);
  }
