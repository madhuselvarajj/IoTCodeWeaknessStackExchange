all: main

main: file.o

%.o: %.c
    gcc -c $< -o $@
