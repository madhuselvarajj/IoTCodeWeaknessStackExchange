SOURCES = source1.c source2.c source3.c
OBJECTS = $(SOURCES:%.c=%.o)

TARGET = myExecutable

$(TARGET): $(OBJECTS)
    gcc $^ -o $@

%.o: %.c
    gcc -c $< -o $@
