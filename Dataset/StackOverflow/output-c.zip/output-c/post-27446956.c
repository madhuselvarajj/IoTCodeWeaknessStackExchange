GET /te/add_data.php?sensor=2323 HTTP/1.1\r\n
Host: 192.168.1.7\r\n
User-Agent: Arduino\r\n
Accept: text/html\r\n
\r\n
