void buttonInt(void){ // disable button interrupt 
     M8C_DisableIntMask(INT_MSK0, INT_MSK0_GPIO);
     if (Right_Data_ADDR & Right_MASK) buttonRightPressed = 1;
     if (Left_Data_ADDR & Left_MASK) buttonLeftPressed = 1;
     if (Select_Data_ADDR & Select_MASK) buttonSelectPressed = 1;
}
