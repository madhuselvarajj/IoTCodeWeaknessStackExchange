TIMER_usecCtx_t timer;
TIMER_usecStart(&timer);

while (1)
{
    if (TIMER_usecElapsedUs(timer) > yourDelayInMicroseconds)
    {
        doSomethingHere();
        TIMER_usecStart(&timer);
    }
}
