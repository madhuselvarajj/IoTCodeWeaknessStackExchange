typedef struct
{
    struct timeval startTimeVal;
} TIMER_usecCtx_t;

void TIMER_usecStart(TIMER_usecCtx_t* ctx)
{
    gettimeofday(&ctx->startTimeVal, NULL);
}

unsigned int TIMER_usecElapsedUs(TIMER_usecCtx_t* ctx)
{
    unsigned int rv;

    /* get current time */
    struct timeval nowTimeVal;
    gettimeofday(&nowTimeVal, NULL);

    /* compute diff */
    rv = 1000000 * (nowTimeVal.tv_sec - ctx->startTimeVal.tv_sec) + nowTimeVal.tv_usec - ctx->startTimeVal.tv_usec;

    return rv;
}
