int main()
{
    int displayNumber;
    int pins[6] = {3, 0, 1, 2};
    int i;

    wiringPiSetup();

    pinMode(0, OUTPUT);
    pinMode(1, OUTPUT);
    pinMode(2, OUTPUT);
    pinMode(3, OUTPUT);
    pinMode(6, OUTPUT);

    digitalWrite(0, LOW);
    digitalWrite(1, LOW);
    digitalWrite(2, LOW);
    digitalWrite(3, LOW);
    digitalWrite(6, LOW);

    displayNumber = -1;
    while ((displayNumber < 0) || (displayNumber > 9))
    {
        printf("Please select a number to display! 0-9\n");
        scanf("%i", &displayNumber);
    }

    digitalWrite(6, LOW);
    for (i = 0 ; i < 4 ; i++)
        digitalWrite(pins[i], displayNumber & (1 << i) ? HIGH : LOW);
    digitalWrite(6, HIGH);

    return 0;
}
