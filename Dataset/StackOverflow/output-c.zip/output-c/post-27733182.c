digitalWrite(6, LOW);
digitalWrite(3, displayNumber & 1 ? HIGH : LOW);
digitalWrite(0, displayNumber & 2 ? HIGH : LOW);
digitalWrite(1, displayNumber & 4 ? HIGH : LOW);
digitalWrite(2, displayNumber & 8 ? HIGH : LOW);
digitalWrite(6, HIGH);
