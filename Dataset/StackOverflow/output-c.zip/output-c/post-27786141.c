import serial
arduino = serial.Serial(port,speed)
time.sleep(2) # may need 5s
byte = chr(0x31)
arduino.write(byte) # byte0<=i<=255
time.sleep(2)
arduino.close()
