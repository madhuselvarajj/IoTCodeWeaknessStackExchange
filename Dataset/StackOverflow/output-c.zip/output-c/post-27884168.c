    /*
// Humidity every 3 seconds
  if(millis()-timeHum>=3000){
    serialPuts (fd, "06\n");
    timeHum=millis();
  }

  // read signal
  if(serialDataAvail (fd)){
    char humChar = serialGetchar (fd);
    printf("%c", humChar);
    fflush(stdout);
    }
*/
