int size_test(char b[])
{
    char a[10];
    char foo[] = {'a', 'b', 'c', 'd', 'e'};
    char *bar = malloc(20);
    printf("sizeof a = %ld, sizeof b = %ld, sizeof foo = %ld, sizeof bar = %ld\n", sizeof(a), sizeof(b), sizeof(foo), sizeof(bar));
}
int main()
{
    char b[12];
    size_test(b);
}
