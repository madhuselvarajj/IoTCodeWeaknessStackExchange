void receiveMessage(AndroidAccessory acc, boolean accstates, byte *theMessage){
    if (theMessage == NULL)
        return;
    if(accstates){
        byte rcvmsg[255];
        int len = acc.read(rcvmsg, sizeof(rcvmsg), 1);
        if (len > 0) {
            if (rcvmsg[0] == COMMAND_TEXT) {
                if (rcvmsg[1] == TARGET_DEFAULT){
                byte textLength = rcvmsg[2];
                int textEndIndex = 3 + textLength;
                int i=0;
                    for(int x = 3; x < textEndIndex; x++) {
                        theMessage[i]=rcvmsg[x];
                        i++;
                        delay(250);
                    }
                return;
                }
            }
        }
    }       
}
