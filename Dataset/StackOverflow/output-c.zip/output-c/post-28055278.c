printArray( question) ;

void printArray(char question[])
{
//process
}
