/**
 * Print the question and answers.  Use the pointer p to 
 * "walk" through the question and answer array.
 */
void printQandA( const char **question )
{
  const char **p = question; 

  /**
   * First element of the array is the question; print it
   * by itself
   */
  printf( "%s\n", *p++ );

  /**
   * Print the answers until we see the NULL element
   * in the array.
   */
   while ( *p )
     printf( "\t-%s\n", *p++ );
}
