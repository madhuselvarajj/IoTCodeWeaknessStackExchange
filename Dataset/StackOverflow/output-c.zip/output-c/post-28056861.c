char question[] = "Question here";
char answ_A[] = "answer1";
char answ_B[] = "answer2";
char answ_C[] = "answer3";
char answ_D[] = "answer4";

/**
 * Set up an array of pointers to char, where each
 * element will point to one of the above arrays
 */
const char *q_and_a[] = { question, answ_A, answ_B, answ_C, answ_D, NULL };

printQandA( q_and_a );
