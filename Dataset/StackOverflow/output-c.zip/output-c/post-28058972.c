input = digitalRead(signal);
while (input == digitalRead(signal))
    ; // wait for input signal to change state (sync)
start = millis();
while (input != digitalRead(signal))
    ; // wait for input signal to change state (first part of period)
while (input == digitalRead(signal))
    ; // wait for input signal to change state (one complete period)
end = millis();
period = end - start;
freq = 60000 / period;
