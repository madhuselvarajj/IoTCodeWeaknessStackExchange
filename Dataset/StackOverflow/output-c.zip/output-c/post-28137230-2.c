user ~/programming/stack $ gcc -Wall -I/usr/include/python3.2 -lpython3.2 pythonInC.c 
pythonInC.c: In function 'main':
pythonInC.c:6:3: warning: passing argument 1 of 'Py_SetProgramName' from incompatible pointer type [enabled by default]
/usr/include/python3.2/pythonrun.h:25:18: note: expected 'wchar_t *' but argument is of type 'char *'
/usr/bin/ld: cannot find -lpython3.2
collect2: ld returned 1 exit status
