typedef struct
{
    const __FlashStringHelper* desc;
    int a;    
} SensorStringInformation;

void setup()
{
       const SensorStringInformation res = 
       {
          F("Depth: "),
          2
       };
}

void loop()
{

}
