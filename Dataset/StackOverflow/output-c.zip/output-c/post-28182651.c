void LCD(char RGBXXX, void *str, int is_data) {  
  RGB(RGBXXX);   
  if (is_data != 0) {   
    char data[33];   
    memcpy(data,(uint8_t*)str,33);  
    writeLCD(data);   
 }   
 else {   
   BMP((uint16_t *)str);
 } 
