int ConfigSonde[][10] = {
    {'x', 3, 'A', 1, 0, 0, 0, 0, 0, 0},
    {'x', 1, 'A', 1, 0, 0, 0, 0, 0, 0}
};

for (i = 0; i < 2; i = i + 1) {ConfigSonde[i][3] = 0;}
