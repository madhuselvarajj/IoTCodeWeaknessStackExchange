int ConfigSonde_0[] = {'x', 3, 'A', 1, 0, 0, 0, 0, 0, 0}; 
int ConfigSonde_1[] = {'x', 1, 'A', 1, 0, 0, 0, 0, 0, 0};
int *ConfigSonde [] = {ConfigSonde_0, ConfigSonde_1};

for (i = 0; i < 2; i = i + 1) {ConfigSonde[i][3] = 0;}
