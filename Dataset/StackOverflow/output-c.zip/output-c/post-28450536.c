unsigned long timestamp = 0;

void loop()
{
    int piezoValue;
    unsigned long elapsedTime;

    piezoValue = analogRead(piezo);

    if ( piezoValue > 2 )
    {
        // compute the time (in milliseconds) since the last knock
        elapsedTime = millis() - timestamp;

        Serial.print( "Time since the last knock " );
        Serial.print( elapsedTime );
        Serial.println( " msec" );

        // store the current time 
        timestamp = millis();
    }
}
