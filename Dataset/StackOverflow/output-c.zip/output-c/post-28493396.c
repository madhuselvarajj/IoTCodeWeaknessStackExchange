asm("\n# onesectimer");
void OneSecTimer()
{
  if(bags!=0){
    asm("\n# for counter 1");
    if(counter1 == 3)
...
