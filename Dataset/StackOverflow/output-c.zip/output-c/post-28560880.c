int fd = open("/dev/ttyS0", O_RDWR | O_NOCTTY | O_NDELAY);

if(fd == -1)
{
        return -1;
}
else
{

        struct termios new_termios;
        struct termios orig_termios;

        tcgetattr(fd, &orig_termios);
        memcpy(&new_termios, &orig_termios, sizeof(new_termios));

        cfmakeraw(&new_termios);

        cfsetispeed(&new_termios, B57600);
        cfsetospeed(&new_termios, B57600);

        tcsetattr(fd, TCSANOW, &new_termios);

}
