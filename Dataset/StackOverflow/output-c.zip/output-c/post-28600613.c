String str;

void setup()
{
    Serial.begin(9600);
}

void loop ()
{
    while (Serial.available() > 0){
        char c = Serial.read();
        str.concat(c);
        if (Serial.available() == 0)
        {
            Serial.print(str);
            str = "";
            break;
        }
    }
}
