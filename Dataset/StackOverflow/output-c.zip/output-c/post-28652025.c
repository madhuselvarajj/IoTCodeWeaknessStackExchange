#include <stdio.h>
#include <string.h>

int main(void) {
    unsigned char a[3+3] = {1, 2, 3}; // n+m
    unsigned char b[3]   = {4, 5, 6}; // m

    memcpy(a+3, b, 3); // a+n is destination, b is source and third argument is m

    for (int i = 0; i < 6; i++) {
        printf("%d\n", a[i]);
    }

    return 0;
}
