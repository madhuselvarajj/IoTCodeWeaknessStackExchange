char ch = 'h';
for (i=0; i<7; i++) {
   bool b = (ch & 1 == 1);
   ch >>= 1;
   // set the bit value b off to the pin....
   }
