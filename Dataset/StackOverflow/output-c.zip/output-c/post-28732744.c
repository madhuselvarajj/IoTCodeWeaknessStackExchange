void toPort(unsigned char x) {
  x |= 0200; // Set unused high-bit to 1
  for ( ; ; ) {
   char bit = x & 1;
   x >>= 1;
   if(x == 0) return;
   push_to_port(bit);
  } 
}
