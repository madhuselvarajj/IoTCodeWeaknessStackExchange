if(ButtonPress==true){
 time=millis() //time was previously declared as unsigned long
    if(time>=5000){ //5000 = 5 sec
     ButtonPress==false
    }
}
