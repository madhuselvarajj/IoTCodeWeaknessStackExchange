int  button1PressedCount = 0;
int  debounceCounter = 5; // Number of successive reads before we say the switch is pressed
boolean buttonPressed = false;
int inputPin1 = 7;

void setup() {
  // Grounding the input pin causes it to actuate
  pinMode(inputPin1, INPUT ); // set the input pin 1
  digitalWrite(inputPin1, HIGH); // set pin 1 as a pull up resistor.
}

void loop()     
{
  // Some code

  // Check button, we evaluate below
  checkButton();

  // Some more code
}

void checkButton() {
  if (digitalRead(inputPin) == 0) {
    // We need consecutive pressed counts to treat this is pressed    
    if (button1PressedCount < debounceCounter) {
      button1PressedCount += 1;
      // If we reach the debounce point, mark the start time
      if (button1PressedCount == debounceCounter) {
        // Button is detected as pressed!
        buttonPressed = true;
      }
    }
  } else {
    if (button1PressedCount == debounceCounter) {
        // We were pressed, but are not any more 
        buttonPressed = false;
    }

    button1PressedCount = 0;
  }
}
