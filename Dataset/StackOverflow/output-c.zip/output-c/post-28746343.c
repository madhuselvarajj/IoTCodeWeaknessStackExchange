s=serial('COM2','Baudrate',9600,'Databits',8);

fopen(s);

count=0;

while count<50

    a=fscanf(s);

    count=count+1;

end

fclose(s);
