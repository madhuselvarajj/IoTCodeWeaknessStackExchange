#ifndef _MY_C_LIB_h
#define _MY_C_LIB_h

typedef struct {char data1;
                int data2;
                } sampleStruct;

  void mycLibInit(int importantParam);
  void mycLibDoStuff(char anotherParam);

  sampleStruct mycLibGetStuff();

#endif
