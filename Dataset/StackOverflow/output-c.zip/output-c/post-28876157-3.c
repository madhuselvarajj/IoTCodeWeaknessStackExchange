#include "mycLib.h"
sampleStruct _sample;
void mycLibInit(int importantParam)
{
    //init stuff!
    //lets say _sample.data2 = importantParam
}

void mycLibDoStuff(char anotherParam)
{
    //do stuff!
    //lets say _sample.data1 = anotherParam
}

sampleStruct mycLibGetStuff()
{
    //return stuff, 
    // lets say return _sample;
}
