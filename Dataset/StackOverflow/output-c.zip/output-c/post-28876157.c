extern "C"{
  #include <mycLib.h>
}

void setup()
{
  mycLibInit(0);
}

void loop()
{
}
