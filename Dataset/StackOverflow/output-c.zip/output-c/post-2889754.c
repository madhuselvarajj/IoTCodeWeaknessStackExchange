void printLetter(char letter) {
  static int* charToMatrix[] = { A, B, C, ... };
  int* matrixToPrint = charToMatrix[letter - 'A'];
  // print the matrix
}
