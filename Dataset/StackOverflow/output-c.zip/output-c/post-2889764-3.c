int *lookup[256] = {
    NULL,   // you need a total of 65 NULL's
    NULL,
    ...
    A,      // so this is at the correct position
    B,
    C,
    ...
};
