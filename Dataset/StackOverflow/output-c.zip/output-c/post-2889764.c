int *lookup[256];  // assuming ASCII
memset(lookup, 0, sizeof(lookup));

lookup['A'] = A;
lookup['B'] = B;
...
