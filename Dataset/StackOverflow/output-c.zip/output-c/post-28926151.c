#include <SPI.h>
#include <Ethernet.h>

byte mac[] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
IPAddress ip;
IPAddress localIp (192,168,1,181);
EthernetClient client ;

void setup()
{
  Serial.begin(9600);
  Ethernet.begin(mac , localIp);
  char x[] = "192.168.1.1" ;//my pc , running SimpleHTTPServer (python)  
  client.connect(x , 8000);
  if( client.connected() ){
    Serial.println("connected"); //does never print
  }
  client.println ("Hellou world from Arduino!") ;
  client.stop();       
}

void loop()
{

}
