#include <stdio.h>

// prototypes
int func00(void);
int func01(void);
...
int funcFF(void);

// array of function pointers
int (*funcarry[256])(void) = {
    func00, func01, ..., funcFF
};

// call one function
int main(void){
    unsigned char switchstate = 0x01;
    int res = (*funcarry[switchstate])();
    printf ("Function returned %02X\n", res);
    return 0;
}

// the functions
int func00(void) {
    return 0x00;
}
int func01(void) {
    return 0x01;
}
...
int funcFF(void) {
    return 0xFF;
}
