int main(){

   //some code before disable hdmi
   system("tvservice -o");

   //do somethings when HDMI is disabled

   //turn HDMI back on
   system("tvservice -p");
   system("fbset -depth 8 && fbset -depth 16");

   return 0;

}
