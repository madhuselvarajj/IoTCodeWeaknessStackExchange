pid_t pid;


pid = fork();
if (0 == pid) {
    execl("/opt/vc/bin/tvservice", "-p", NULL);
}
if (-1 == pid) {
    // Handle error here, close program?
}
