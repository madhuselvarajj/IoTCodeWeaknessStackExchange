~/dev/stackoverflow > make t42
clang -O3 -Wall -o t42 t42.c
t42.c:6:32: warning: shift count >= width of type [-Wshift-count-overflow]
    printf("1 << 40 = %d\n", 1 << 40);
                               ^  ~~
t42.c:7:32: warning: shift count >= width of type [-Wshift-count-overflow]
    printf("1 << 40 = %d\n", 1 << 40);
                               ^  ~~
t42.c:8:32: warning: shift count >= width of type [-Wshift-count-overflow]
    printf("1 << 40 = %d\n", 1 << 40);
                               ^  ~~
3 warnings generated.
~/dev/stackoverflow > ./t42
1 << 40 = 1386850896
1 << 40 = 256
1 << 40 = 512
1 << 40 = 256
~/dev/stackoverflow > ./t42
1 << 40 = 1477618256
1 << 40 = 256
1 << 40 = 512
1 << 40 = 256
