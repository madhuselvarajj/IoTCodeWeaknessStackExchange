#include <stdio.h>

int a = 1, b = 40;

int main() {
    printf("1 << 40 = %d\n", 1 << 40);
    printf("1 << 40 = %d\n", 1 << 40);
    printf("1 << 40 = %d\n", 1 << 40);
    printf("%d << %d = %d\n", a, b, a << b);
}
