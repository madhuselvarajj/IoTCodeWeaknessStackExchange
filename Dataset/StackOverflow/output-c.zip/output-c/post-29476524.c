int ledPin = 13;
int buttonPin = 3;
int lastButtonState = HIGH;
int ledState = HIGH;

void setup()
{
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);
}

void loop()
{
  // read from the button pin
  int buttonState = digitalRead(buttonPin);
  // if the button is not in the same state as the last reading
  if (buttonState==LOW && buttonState!=lastButtonState)
  {
    // change the LED state
    if (ledState==HIGH)
    {
      ledState = LOW;
    }
    else
    {
      ledState = HIGH;
    }
  }
  digitalWrite(ledPin, ledState);
  // store the current button state
  lastButtonState = buttonState;
  // add a delay to avoid multiple presses being registered
  delay(20);
}
