char dt[20]; // space enough for DD/MM/YYYY HH:MM:SS and terminator
struct tm tm;
time_t current_time;

current_time = time(NULL);
tm = *localtime(&current_time); // convert time_t to struct tm
strftime(dt, sizeof dt, "%d/%m/%Y %H:%M:%S", &tm); // format

fprintf(currfd, "%s %d %d\n", dt, temp, humidity);
