#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

int random (int low, int high) {
    return low + rand() % (high - low);
}

int getGCD(int a, int b) {
    int c;
    while (a != 0)
    {
        c = a;
        a = b % a;
        b = c;
    }
    return b;
}

int getCoprime(int n) {
    int coprime;
    do
    {
        coprime = random(1, n);
    } 
    while (getGCD(n, coprime) != 1);
    return coprime;
}

int main(void) {
        int e, x, y, r, n, s, v, test, ysqmodn;

        srand((unsigned)time(NULL));
        n = 7 * 3;
        s = getCoprime(n);
        v = (s * s) % n;

        e = random(0, 2);
        r = random(1, n);

        printf("n=%d, s=%d, e=%d, r=%d\n", n,s,e,r);

        y = (r * (int)pow(s, e)) % n;
        x = (r * r) % n;

        ysqmodn = y * y % n;
        test = (x * (int)pow(v, e)) % n;

        if(ysqmodn == test)
            printf("The current ICC matches. \n");
        else
            printf("%d\n", e);

        return 0;
    }
