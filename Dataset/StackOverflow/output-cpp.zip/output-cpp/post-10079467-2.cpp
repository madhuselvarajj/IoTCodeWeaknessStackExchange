void loop() {
   byte* frame = assembleFrame();
   Serial.write( frame , frame[ 0 ] );
   // release the memory allocated by assembleFrame()
   delete [] frame;
   while ( 1 ) {
   }
}
