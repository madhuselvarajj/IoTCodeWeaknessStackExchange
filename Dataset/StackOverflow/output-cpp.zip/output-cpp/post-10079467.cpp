 byte* assembleFrame() {
      byte* frame = new byte[5];
      frame[0] = 4;
      frame[1] = 'a';
      frame[2] = 'b';
      frame[3] = 'c';
      frame[4] = 'd';
      return frame;
 }
