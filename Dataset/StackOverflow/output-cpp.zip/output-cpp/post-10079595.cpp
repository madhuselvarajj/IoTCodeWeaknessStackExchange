/* Takes in an array of bytes with at least the given size, returns
 * the number of bytes written into the frame.
 */
int assembleFrame(byte *frame, int frame_size) {
  frame[0] =  4;
  frame[1] = 'a';
  frame[2] = 'b';
  frame[3] = 'c';
  frame[4] = 'd';
  return 5; // only used five bytes in the frame
}

  /* then in loop() */
  byte frame[10];
  bytes_in_frame = assembleFrame(frame, 10);
  someDataSendingFunction(frame, bytes_in_frame); // assuming ptr + bytes to send
