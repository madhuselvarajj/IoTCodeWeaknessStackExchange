float y = 0;

char b[sizeof(x)];

// Store 4 bytes representing the float into b
// [...]

// Rebuild the float
memcpy(&y, b, sizeof(y));
