float x = 1128.476;

char b[sizeof(x)];
memcpy(b, &x, sizeof(x));

// Iterate over b and send bytes
// [...]
