int receiveObject(void *object, size_t size) {
  char *inputCursor = (char *) object;

  for (;size > 0;size--) {
    int nextByte = yourReceiveAByteFunction();
    if (nextByte < 0)
      return FALSE;

    *inputCursor++ = nextByte;
  }
  return TRUE;
}
