void sendObject(const void *object, size_t size) {
  char *outputCursor = (char *) object;

  for (;size > 0;size--)
    yourSendAByteFunction(*outputCursor++);
}
