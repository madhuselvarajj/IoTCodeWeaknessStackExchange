(...appropriate setup...)
void loop() { 
  lcd.setCursor(0, 0);
  while (Serial.available() > 0) {       //Changed Line
      incomingByte = Serial.read();      //Added Line
      lcd.print(incomingByte);
  }
  delay(1000);
}
