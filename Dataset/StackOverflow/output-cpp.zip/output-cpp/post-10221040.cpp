int sensorValue = 0;
int prevValue = 0;

void loop()
{    
    sensorValue = 0.004882812 * analogRead(sensorPin) + 1;
    if (sensorValue != prevValue) {
       lcd.print(sensorValue);
       prevValue == sensorValue;
    }
}
