#include <Wire.h> 
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27,16,2);  
int sensorPin = A0;

void setup()
{
    lcd.init();                      
    lcd.backlight();
}

void loop()
{
    int sensorValue = 0.004882812 * analogRead(sensorPin) + 1;
    String display = "Voltage=";
    display += sensorValue;
    lcd.print(display);
}
