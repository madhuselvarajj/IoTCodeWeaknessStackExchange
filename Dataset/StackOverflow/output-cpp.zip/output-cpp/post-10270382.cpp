switch (int(input) /  500)
{
case 0: ... // 0..500
case 1: ... // 500..1000
case 2: ... // 1000..1500
etc
}
