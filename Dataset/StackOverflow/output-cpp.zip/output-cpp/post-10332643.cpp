unsigned long start = micros();
// Call to your function
myFunction();
// Compute the time it took
unsigned long end = micros();
unsigned long delta = end - start;
Serial.println(delta);
