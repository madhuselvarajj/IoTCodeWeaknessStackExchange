GSAttackDur getRandomDuration()
{
    static const GSAttackDur lookup[]
    {
        AT_2MS, AT_8MS, AT_16MS, AT_24MS, AT_38MS, 
        AT_56MS, AT_68MS, AT_80MS, AT_100MS // add more as necessary
    } ;

    // Get random index into lookup - 0 to N-1 where N is the number 
    // of elements in lookup.
    int r = rand() / (RAND_MAX / (sizeof(lookup) / sizeof(*lookup)) ) ;

    // Return a random GSAttackDur value
    return lookup[r] ;
}
