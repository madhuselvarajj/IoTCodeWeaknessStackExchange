sensor1.init(
    (unsigned char[]){led1,led2,led3,led4,led5,led6,led7,led8},
    numSensors,
    timeout,
    emitterPin1);

sensor2.init(
    (unsigned char[]){led9,led10,led11,led12,led13,led14,led15,led16},
    numSensors,
    timeout,
    emitterPin2);
