sedimentSensor::sedimentSensor() 
    : led1(24), led2(26), /* other variables needing initialization */
      sensor1(/*arguments*/), sensor2(/*arguments*/)
{
    /* .... */
}
