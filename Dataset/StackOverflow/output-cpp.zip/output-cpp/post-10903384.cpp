class LightManager
{
    static std::vector<Light> lights;
    static void notify()
    {
       for ( size_t i = 0 ; i < lights.size() ; i++ )
           lights[i].update();
    }
    static void add(const light& l)
    {
       lights.push_back(l);
    }
};

class Light
{
    Light()
    {
       LightManager::add(*this);
    }
};
