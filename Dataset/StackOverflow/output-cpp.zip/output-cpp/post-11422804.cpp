serial_fd = open("/dev/ttyUSB0", O_RDWR);
if (serial_fd < 0) {
    cout << "Error while opening device... " << "errno = " << errno << endl;
    perror("Something went wrong with open()");
    exit(1);
}
