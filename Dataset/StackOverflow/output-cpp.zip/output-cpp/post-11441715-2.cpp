enum ButtonState { Neutral=0, Left=1, Right=2, Up=3, Down=4 };

ButtonState lastButton = Neutral;

const int XPin = 4;
const int YPin = 5;

char* myStrings[]={"Neutral", "Left","Right","Up","Down"};

void setup() {
    Serial.begin(9600);
}

ButtonState readButtonState() {
    int xAxis=map(analogRead(XPin), 0, 1023, 0, 10);
    int yAxis=map(analogRead(YPin), 0, 1023, 0, 10);
    if (xAxis < 4 ) return Left;
    if (xAxis > 6 ) return Right;
    if (yAxis < 4 ) return Down;
    if (yAxis > 6 ) return Up;
    return Neutral;
}

void loop() {
    ButtonState button = readButtonState();
    if (button != lastButton) {
        Serial.println(myStrings[button]);
        lastButton = button;
    }
    delay(50);
}
