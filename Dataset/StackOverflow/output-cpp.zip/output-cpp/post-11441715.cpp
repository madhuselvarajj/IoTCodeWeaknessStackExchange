int lastButton = 0;
...
void loop() {
    button = ...// Read button state
    ...
    if (button != lastButton) {
        ... // New keypress
        lastButton = button;
    }
}
