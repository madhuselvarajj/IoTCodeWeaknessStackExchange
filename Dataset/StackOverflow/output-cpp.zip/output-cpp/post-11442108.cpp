const int Left = 1;
const int Right = 2;
const int Up = 3;
const int Down = 4;

int xpin = 4;
int ypin = 5;

int xAxis;
int yAxis;
char* myStrings[]={"Left","Right","Up","Down"};
int button;


void setup() {
  Serial.begin(9600);
}
int lastButton = -1; // init lastButton to a never occurring value

void loop() {

   xAxis=map(analogRead(xpin), 0, 1023, 0, 10);
   yAxis=map(analogRead(ypin), 0, 1023, 0, 10);

   if (xAxis < 4 ) { 
     button = Left; 
   }
   else if (xAxis > 6 ) { 
     button = Right; 
   }

   if (yAxis < 4 ) { 
     button = Down; 
   }
   else if (yAxis > 6 ) { 
     button = Up;
   }

   if (button == lastButton){
       //Serial.println(0);
       //button = 0;
       delay(50); // wait more
   }else{
       lastButton = button;
       Serial.println(myStrings[button-1]);
       button = 0;
       delay(50);
   }
 }
