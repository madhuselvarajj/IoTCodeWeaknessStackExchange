namespace Motor {
  extern unsigned char left_speed;
  extern unsigned char right_speed;

  void ChangeSpeed(unsigned char, unsigned char);
}
