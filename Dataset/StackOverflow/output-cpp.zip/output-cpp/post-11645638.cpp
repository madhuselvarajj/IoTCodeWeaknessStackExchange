    char __dataFileName[sizeof(dataFileName)];
    dataFileName.toCharArray(__dataFileName, sizeof(__dataFileName));

    pinMode(SD_PIN,OUTPUT);
    dataFile = SD.open(__dataFileName,FILE_WRITE);
