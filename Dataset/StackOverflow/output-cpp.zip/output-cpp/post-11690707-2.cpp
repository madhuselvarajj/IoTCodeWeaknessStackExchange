        dataFile = SD.open("datalog.txt", FILE_WRITE);
        // if the file is available, write to it:
        if (SD.open("datalog.txt", FILE_WRITE)) 
        {
              dataFile.println(dataString);
              // print to the serial port too:
              Serial.println("data logged to SD");
        }
        // if the file isn't open, pop up an error:
        else
        {
              Serial.println("File Error datalog.txt");
        } 
        dataFile.close(); // always close after an open.
