void main() {
    char * input = "$ÇÐÇÇÁ,175341.458,3355.7870,Ó,01852.4251,Å,1,03,5.5,-32.8,Í,32.8,Í,,0000*57";

    char * garbage = strtok(input, ",");
    char * firstNumber = strtok(NULL, ",");
    char * secondNumber = strtok(NULL, ",");
    double firstDouble;
    sscanf(firstNumber, "%lf", &firstDouble);
    printf("%f\n", firstDouble);
}
