std::unique_ptr<WiFlyClient> m_client;

...

m_client = m_server.available();

...

// convert m_client.<...> to m_client-><...>

// change m_server.available() to return std::unique_ptr<WiFlyClient>
