// WiFlyClient.h
class WiFlyClient : public Client {
 public:
  WiFlyClient();
  ...
private:
  static WiFlyDevice& _WiFly;
  ...
};
