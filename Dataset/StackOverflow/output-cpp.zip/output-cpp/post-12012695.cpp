int a = 1;
int b = 2;
int &ar = a;
int &br = b;
ar = br; // changes a's value to 2, does not change ar to reference b
