WiFlyClient& operator= (const WiFlyClient & wi)
{
  /* make a copy here */ 
  return *this;
}
