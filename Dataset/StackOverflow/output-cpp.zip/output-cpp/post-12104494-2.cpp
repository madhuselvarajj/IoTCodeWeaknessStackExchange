typedef struct {
  char code[4];
  gpsCoord_t bounds[4];
  gpsCoord_t points[4];
} track_t;
