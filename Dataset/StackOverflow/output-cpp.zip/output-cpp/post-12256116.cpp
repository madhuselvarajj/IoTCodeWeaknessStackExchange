#ifndef MY_H_FILE
#define MY_H_FILE

/* ..Declarations.. */

#endif
