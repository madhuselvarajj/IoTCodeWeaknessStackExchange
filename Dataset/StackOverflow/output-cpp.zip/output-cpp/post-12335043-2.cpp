if (hsensor2.measure(SHT21::HUMI) && hsensor2.measure(SHT21::TEMP))
{
 hsensor2.calculate(h, t); 
 float hum2 = (h); 
 float temp2 = (t);    
}
