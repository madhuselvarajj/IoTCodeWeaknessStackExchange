uint8_t SHT21::measure(uint8_t type, void (*delayFun)()) {

    start();
    writeByte(type == TEMP? MEASURE_TEMP : MEASURE_HUMI)

    for (uint8_t i = 0; i < 250; ++i) {
        if (!digiRead()) {
            meas[type] = readByte(1) << 8;
            meas[type] |= readByte(1);
            uint8_t flipped = 0;

            for (uint8_t j = 0x80; j != 0; j >>= 1) {
                flipped >>= 1;
            }

            if (readByte(0) != flipped)
                break;

            return 0;
        }


        if (delayFun)
            delayFun();
        else
            delay(1);
    }

    connReset();
    return 1;
}
