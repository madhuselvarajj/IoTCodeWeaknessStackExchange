bool hasHUMI;
if (hsensor2.measure(SHT21::HUMI))
{
  hasHUMI=true;
}
