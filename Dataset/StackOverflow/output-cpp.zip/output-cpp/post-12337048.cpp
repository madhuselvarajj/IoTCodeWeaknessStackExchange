/*...*/
int num_args = 5;
byte* arg_listB = new byte[2*num_args+10];
//initialize your array

//free the memory when done with the array
delete[] arg_listB;
