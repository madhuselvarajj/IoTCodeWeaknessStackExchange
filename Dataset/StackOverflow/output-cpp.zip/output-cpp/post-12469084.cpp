#define LEN   16
#define CR    13

int i=0;
char incoming;

while ((incoming!= CR) & (i<LEN-1))
{
   if (Serial.available())
   {
       incoming = Serial.read();
       firstline[i]=incoming;
       i++;
   }
}
firstline[i]=0;
Serial.println(firstLine);
