#include <vector>
#include <iostream>

#define MEMORY_SIZE 10

class Clazz {
    std::vector<int> memory;

    public:
        Clazz() : memory(MEMORY_SIZE){}
        int memory_size() {return memory.size();}
};

int main() {
    Clazz c;
    std::cout << c.memory_size() << std::endl;
    return 0;
}
