const int a[3][4] = { {0, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 0, 0} };
const int b[3][4] = { {0, 0, 0, 1}, {0, 0, 0, 0}, {0, 0, 0, 0} };

int c[3][4];

const int* pa = &a[0][0];
const int* pb = &b[0][0];
int* pc = &c[0][0];

for(int i = 0; i < 3 * 4; ++i)
{
    *(pc + i) = *(pa + i) + *(pb + i);
}
