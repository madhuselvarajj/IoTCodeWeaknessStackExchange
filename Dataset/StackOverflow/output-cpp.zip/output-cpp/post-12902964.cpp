std::vector<std::vector<double>>
SimpleWav::something(const std::vector<double>& data, int N) {

    //How many blocks of size N can we get?
    int num_blocks = data.size() / N;

    //Create the vector with enough empty slots for num_blocks blocks
    std::vector<std::vector<double>> blocked(num_blocks);

    //Loop over all the blocks
    for(int i = 0; i < num_blocks; i++) {
        //Resize the inner vector to fit this block            
        blocked[i].resize(N);

        //Pull each sample for this block
        for(int j = 0; j < N; j++) {
            blocked[i][j] = data[i*N + j];
        }
    }

    return blocked;
}
