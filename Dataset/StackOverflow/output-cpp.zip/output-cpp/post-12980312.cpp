  for (int i = 0; i<=fieldIndex; i++)     // no semicolon
  {
     Serial.println(values[i]);
     values[i]= 0;
  }
