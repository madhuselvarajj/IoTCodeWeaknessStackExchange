struct phase {
  unsigned char r, g, b, delay;
};

unsigned long t_nextPhase;
volatile struct phase *forceMode = NULL;
struct phase *mode = blinkAll;
int nextPhase = 0;

struct phase blinkAll[] = {
  { 255, 255, 255, 17 },
  { 0, 0, 0, 17 },
  { 0, 0, 0, 255 } // loop sentinel
};

void lighting_kernel() {
    noInterrupts(); // ensure we don't race with interrupts
    if (forceMode) {
        mode = forceMode;
        forceMode = NULL;
        t_nextPhase = millis();
        nextPhase = 0;
    }
    interrupts();

    if (t_nextPhase > millis()) {
        return;
    }

    struct phase *cur_phase;
    do {
        cur_phase = mode[nextPhase++];
        if (cur_phase->delay == 255) {
            nextPhase = 0;
        }
    } while (cur_phase->delay == 255);

    analogWrite(red   , cur_phase->r);
    analogWrite(green , cur_phase->g);
    analogWrite(blue  , cur_phase->b);

    t_nextPhase = millis() + cur_phase->delay;    
}
