#ifndef SHIFTREG_H
#define SHIFTREG_H

class shiftreg
{
  // ...
};

#endif
