


    bool serialController::openPort(QString portName) {
        QString selectPort = QString("\\\\.\\%1").arg(portName);
        this->port = new QextSerialPort(selectPort,QextSerialPort::EventDriven);
        if (port->open(QIODevice::ReadWrite | QIODevice::Unbuffered) == true) {
            port->setBaudRate(BAUD38400);
            port->setFlowControl(FLOW_OFF);
            port->setParity(PAR_NONE);
            port->setDataBits(DATA_8);
            port->setStopBits(STOP_1);
            port->setTimeout(500);

            port->setDtr(true);
            port->setRts(true);
            Sleep(100);
            port->setDtr(false);
            port->setRts(false);

            connect(port,SIGNAL(readyRead()), this, SLOT(onReadyRead()));

            return true;
        } else {
            // Device failed to open: port->errorString();
        }
        return false;
    }

