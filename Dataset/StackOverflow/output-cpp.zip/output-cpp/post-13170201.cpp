class MyLibrary{
public:
   MyLibrary(uint8_t, uint8_t);
   //...
private:
   SoftwareSerial _serial;
   //...
};

MyLibrary::MyLibrary(uint8_t in, uint8_t out)
   : _serial(in, out)
{
   //do initialization
}
