struct X
{
    int x;
    int y;
};

X   valX[] = { {1,2}, {3,4}, {5,6}}; // initializes an array of X
                                     // first X is {1,2}
                                     // second X is {3,4}
                                     // etc
