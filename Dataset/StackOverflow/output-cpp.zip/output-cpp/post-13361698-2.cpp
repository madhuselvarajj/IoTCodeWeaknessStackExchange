namespace USART0
{
    void USART0_PutNChar(...);
    ...
}
