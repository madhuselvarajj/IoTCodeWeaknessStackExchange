// Using `struct` as there is no private or protected data/functions
struct USART0
{
    static void USART0_PutNChar(...);
    ...
};
