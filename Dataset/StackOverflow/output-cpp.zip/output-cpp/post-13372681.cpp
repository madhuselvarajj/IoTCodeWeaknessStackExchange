unsigned char* logo(int page)
{
  switch(page)
  {
    case 1:
       return impostazioni_logo_page1;
    break;
  }
  return NULL;
}
