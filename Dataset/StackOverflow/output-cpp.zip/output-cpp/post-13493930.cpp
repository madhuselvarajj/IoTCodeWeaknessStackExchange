...
class MPL3115A2 {
    public:
        float getPressure();
        // (and remember the constructor)
    private:    
        ...
}
