MPL3115A2::MPL3115A2()
{
    _p_msb = 0;
    _p_csb = 0;
    _p_lsb = 0;
    _tempp = 0;
    _tempa = 0;
    _tempt = 0;
    _decimalPress = 0;
    _decimalAlt = 0;
    _decimalTemp = 0;
    _ptot = 0;
}
