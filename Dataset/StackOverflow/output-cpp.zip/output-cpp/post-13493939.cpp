#ifndef MPL3115A2_h
#define MPL3115A2_h

#include "Arduino.h"

class MPL3115A2{
public:
  float getPressure(); // <- only change here
private:
  int m_i2c_address;
  byte _p_msb, _p_csb, _plsb;
  byte _tempp, _tempa, _tempt, _decimalPress, _decimalAlt, _decimalTemp;
  unsigned long _ptot;
};

#endif 
