TermSet::TermSet(float a, float b, float step, int setsSize){
this->a = a;
this->b = b;
this->step = step;
this->last = -1;

this->setsSize = size;
