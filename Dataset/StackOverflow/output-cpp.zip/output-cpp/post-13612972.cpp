#if !defined(_PTRDIFF_T) && !defined(_T_PTRDIFF_) && //... well, you get the idea
  #define _PTRDIFF_T
  #define _T_PTRDIFF_
  //...
  #ifndef __PTRDIFF_TYPE__
    #define __PTRDIFF_TYPE__ long int
  #endif
  typedef __PTRDIFF_TYPE__ ptrdiff_t;
#endif
