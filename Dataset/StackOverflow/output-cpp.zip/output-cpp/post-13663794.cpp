void foo(void) {

   // some code where neither reading variable is occupying memory

   {
      int yreadings[4];
      int zreadings[4];

      // here these variable are taking up memory

   }

   // other code where neither reading variable is occupying memory
}
