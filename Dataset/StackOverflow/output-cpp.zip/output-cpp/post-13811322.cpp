char align[100];
while(Serial.available() && i< 99) {
  align[i++] = Serial.read();
}
align[i++]='\0';
lcd.setCursor(atoi(align),0);
