/********************************************************************************
 * Test out for Stack Overflow question "Divide two integers in Arduino",       *
 * <http://stackoverflow.com/questions/13792302/divide-two-integers-in-arduino> *
 *                                                                              *
 ********************************************************************************/

// The setup routine runs once when you press reset:
void setup() {
    // Initialize serial communication at 9600 bits per second:
    Serial.begin(9600);

    //The question part, modified for serial print instead of LCD.
    {
        int l1 = 5;
        int l2 = 15;
        float test = 0;
        test = (float)l1 / (float)l2;

        Serial.println("Start...");
        Serial.println("");
        Serial.println(l1);
        Serial.println(l2);
        Serial.println(test);
        Serial.println(test, 14);
    }

} //setup()

void loop()
{
}
