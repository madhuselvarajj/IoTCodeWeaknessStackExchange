sprintf (timeStr, "%s%d/%s%d/%d %s%d:%s%d:%s%d",
    (monthDay < 10) ? "0" : "",
    monthDay,
    :
    and so on ...
