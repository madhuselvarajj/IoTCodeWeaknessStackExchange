int x=0;
int char_rev;

while(buf0[x]!='\r') {

    char_rev = oSerial.ReadData(buf0[x],1);
    if (char_rev==1) {
        x++;
    }
}
buf0[x]=0;
