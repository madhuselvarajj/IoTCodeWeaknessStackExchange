class Input {
public:
    Input() : upButton(NULL), downButton(NULL) {}
    void initializeMembers(byte sPin, byte rPin1, byte rPin2) {
        upButton = new CapacitiveSensor(sPin, rPin1);
        downbutton = new CapacitiveSensor(sPin, rPin2);
    }
    CapacitiveSensor *upButton;
    CapacitiveSensor *downButton;
};
