class CustomCapacitiveSensor : public CapacitiveSensor {
public:
    CustomCapacitiveSensor() {
        CapacitiveSensor(1, 2);
    }
};
