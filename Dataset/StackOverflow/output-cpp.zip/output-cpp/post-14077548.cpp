class Input {
public:
    Input(byte sPin, byte rPin1, byte rPin2)
        : upButton(CapacitiveSensor(sPin, rPin1))
        , downButton(CapacitiveSensor(sPin, rPin2))
    {}
    CapacitiveSensor upButton;
    CapacitiveSensor downButton;
};
