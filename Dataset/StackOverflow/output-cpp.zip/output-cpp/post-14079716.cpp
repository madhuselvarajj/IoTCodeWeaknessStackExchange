Input::Input(byte sPin, byte rPin1, byte rPin2) :
  upButton(sPin, rPin1), downButton(sPin, rPin2)
{
...
}
