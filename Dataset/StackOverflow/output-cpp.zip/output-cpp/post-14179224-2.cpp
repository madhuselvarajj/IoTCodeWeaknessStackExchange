unsigned int max = 1000000000L;
for (unsigned int i=0; i<max; i++)
    00FC1270  mov         eax,dword ptr ds:[00FC4430h]  
{
    n++;
}
std::cout << n;
    00FC1275  mov         ecx,dword ptr ds:[0FC3030h]  
    00FC127B  add         eax,3B9ACA00h  
    00FC1280  push        eax  
    00FC1281  mov         dword ptr ds:[00FC4430h],eax  
    00FC1286  call        dword ptr ds:[0FC3038h] 
