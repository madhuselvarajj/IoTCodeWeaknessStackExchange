for(i=0; i<1000000000; i++)
{
 n++;
}
Serial.println(n);
    d8: c8 01           movw    r24, r16
    da: 40 e0           ldi r20, 0x00   ; 0
    dc: 5a ec           ldi r21, 0xCA   ; 202
    de: 6a e9           ldi r22, 0x9A   ; 154
    e0: 7b e3           ldi r23, 0x3B   ; 59
    e2: 2a e0           ldi r18, 0x0A   ; 10
    e4: 30 e0           ldi r19, 0x00   ; 0
    e6: 0e 94 c4 04     call    0x988   ; 0x988 <_ZN5Print7printlnEli>
