unsigned int max = 1000000000L;
    011643BE  mov         dword ptr [max],3B9ACA00h  
for (unsigned int i=0; i<max; i++)
    011643C5  mov         dword ptr [ebp-14h],0  
    011643CC  jmp         main+37h (011643D7h)  
    011643CE  mov         eax,dword ptr [ebp-14h]  
    011643D1  add         eax,1  
    011643D4  mov         dword ptr [ebp-14h],eax  
    011643D7  mov         eax,dword ptr [ebp-14h]  
    011643DA  cmp         eax,dword ptr [max]  
for (unsigned int i=0; i<max; i++)
    011643DD  jae         main+4Eh (011643EEh)  
{
    n++;
    011643DF  mov         eax,dword ptr ds:[0116F218h]  
    011643E4  add         eax,1  
    011643E7  mov         dword ptr ds:[0116F218h],eax  
}
011643EC  jmp         main+2Eh (011643CEh)  
