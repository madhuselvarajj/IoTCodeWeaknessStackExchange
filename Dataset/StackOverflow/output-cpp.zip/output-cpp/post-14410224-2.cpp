MyClass::MyClass(int par) :
  B0(123), B1(456)
{
    B[0] = &B0;
    B[1] = &B1;
}
