Class MyClass {
public:
    MyClass(int par);
    SomeClass B0;
    SomeClass B1
    SomeClass* B[2];
