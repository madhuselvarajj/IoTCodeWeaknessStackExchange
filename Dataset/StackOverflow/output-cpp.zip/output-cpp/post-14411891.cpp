typedef struct rgb_t {
  byte r;
  byte g;
  byte b;
};

rgb_t gpsHoldArr[4][6][6] = {
