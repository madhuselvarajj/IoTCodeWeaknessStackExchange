struct Led{
    int r,g,b;
};

void toggleLights(Led lights[]){

Led gpsHoldArr[4][6][6] = 

set_color_led(i, lights[i].r, lights[i].g, lights[i].b);
