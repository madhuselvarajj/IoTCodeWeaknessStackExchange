void toggleLights(int lights[][3]){
  for(int i = 0; i < 6; ++i)
  {
    set_color_led(i, lights[i][0], lights[i][1], lights[i][2]);
  } 
}
