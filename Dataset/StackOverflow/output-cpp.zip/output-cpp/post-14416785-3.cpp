// set_color_led(i, lights[i][0], lights[i][1], lights[i][2]) for i = {0, ..., 5}
set_color_led(0, 255, 0, 0);
set_color_led(1, 0, 0, 0);
set_color_led(2, 0, 0, 0);
set_color_led(3, 0, 0, 0);
set_color_led(4, 0, 0, 0);
set_color_led(5, 0, 0, 0);
