// set_color_led(i, lights[i], lights[i], lights[i]) for i = {0, ..., 6}
set_color_led(0, 255, 255, 255);
set_color_led(1, 0, 0, 0);
set_color_led(2, 0, 0, 0);
set_color_led(3, 0, 0, 0);
set_color_led(4, 0, 0, 0);
set_color_led(5, 0, 0, 0);
set_color_led(6, 0, 0, 0); // bug here as noted by molbdnilo
