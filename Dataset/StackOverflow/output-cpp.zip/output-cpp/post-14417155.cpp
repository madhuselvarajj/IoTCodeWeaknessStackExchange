struct LED { int r, g, b; };

#define BLACK  {0, 0, 0}
#define RED    {255, 0, 0}

#define DEFAULT_LEDS \
  { {RED, BLACK, BLACK, BLACK, BLACK, BLACK},\
    {RED, RED,   BLACK, BLACK, BLACK, BLACK},\
    {RED, RED,   RED,   BLACK, BLACK, BLACK},\
    {RED, RED,   RED,   RED,   BLACK, BLACK},\
    {RED, RED,   RED,   RED,   RED,   BLACK},\
    {RED, RED,   RED,   RED,   RED,   RED}}

LED gpsHoldArr[4][6][6] = {
   DEFAULT_LEDS,
   DEFAULT_LEDS,
   DEFAULT_LEDS,
   DEFAULT_LEDS
};


void set_color_led(int index, const LED& led){
   Serial.println(index); //Which LED (or "pixel") is it?
   Serial.println(led.r); //What is the red value?
   Serial.println(led.g); //What is the green value?
   Serial.println(led.b); //What is the blue value? 
}

void toggleLights(LED (&leds)[6]){
  for(int i = 0; i < 6; ++i)  // You had a '<=' bug here.
  {
    set_color_led(i, leds[i]);
  } 
}

toggleLights(gpsHoldArr[0][0]); //Toggles lights on strip #1, step #1
