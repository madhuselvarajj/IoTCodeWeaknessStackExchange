class IInterupt{
 // other stuff common to all interupt classes
    void pollInterupt() = 0; // pure virtual force all inheriting classes to implement.   
}

class interuptButton : public IInterupt{ //bla bla }

 class node{
        public:
            node *next;
            node *prev;
        public:
            IInterupt*interupt;
    };
