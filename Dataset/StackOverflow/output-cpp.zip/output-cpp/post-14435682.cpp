struct baseIntertuptable
{
    virtual void pollInterrupt() = 0;
};

struct interruptHandler
{
private:
    struct node
    {
        // ...
        baseInterruptable* interrupt;
    };

public:
    void run()
    {
        // ...
        current->interrupt->pollInterrupt();
        // ...
    }
};

class interruptButton : public baseInterruptable
{
public:
    void pollInterrupt()
    {
        // ...
    }
};
