class ClassB {
public:
    void setUrl(char *url){strncpy(url_, url, 80);}
    char *getUrl(char *url){return url_;}
private:
    char[80] url_; 
};

class ClassA 
{ 
public:
   char *getUrl(){return classB.getUrl();}
private:
    ClassB classB; 
};

ClassA classA;

void setup()
{

}

void loop()
{
    char *url = classA.getUrl();
    Serial.println(url);
    delay(1000);
}
