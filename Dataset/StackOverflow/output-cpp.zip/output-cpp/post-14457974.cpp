 class ClassB
 {
 public:

    ClassB()
    {
        strcpy(_someString, "my_url");
    }

    void generateUrl(char *url)
    {
        strcpy(url, _someString);

        //char* someString = (char*) malloc(...);
        // something...
        //return someString;
    }
private:
    char _someString[80];
};

class ClassA{
public:
    void getMyUrl(char *url)
    {
        ClassB b;
        b.generateUrl(url);
        //return b.generateUrl();
    }
};

void developerMethod()
{
    ClassA a;
    //char* url = a.getMyUrl();
    char url[80];
    a.getMyUrl(url);
    print(url);
}
