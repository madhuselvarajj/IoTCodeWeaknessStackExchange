for(int i=1;;i++)
{
   String temp = "data";
   temp.concat(i);
   temp.concat(".csv");
   char filename[temp.length()+1];
   temp.toCharArray(filename, sizeof(filename));
   if(!SD.exists(filename))
   {
      datur = SD.open(filename,FILE_WRITE);
      break;
   }
}
