  char filename[temp.length()+1];
  temp.toCharArray(filename, sizeof(filename));
  if(!SD.exists(filename)) { 
   ...
  }
