byte GetFreeCell(short x, short y)
{
    byte possibleMoves[4];
    byte index = 0;
    if (y - 2 >= 0 && _grid[y - 2][x] == 0)
        possibleMoves[index++] = 1;
    if (x + 2 < WIDTH && _grid[y][x + 2] == 0)
        possibleMoves[index++] = 2;
    if (y + 2 < HEIGHT && _grid[y + 2][x] == 0)
        possibleMoves[index++] = 3;
    if (x - 2 >= 0 && _grid[y][x - 2] == 0)
        possibleMoves[index++] = 4;

    return index ? possibleMoves[random(index)] : 0;
}
