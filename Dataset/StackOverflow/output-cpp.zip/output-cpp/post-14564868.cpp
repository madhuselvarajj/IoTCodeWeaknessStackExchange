uint8_t relay_pin = LOW;
const char *lcd_text = "OFF";
if(inside_temp < target) {
    float limit = target + 1;
    if(outside_temp > limit) {
    }
    else {
      relay_pin = HIGH;
      lcd_text = "ON";
    }
}
digitalWrite(RELAY_PIN, relay_pin);
lcd.print(lcd_text);
