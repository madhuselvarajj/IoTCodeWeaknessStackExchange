Response = Status-Line
    *(( general-header        
   | response-header        
   | entity-header ) CRLF)  
   CRLF
   [ message-body ]   
