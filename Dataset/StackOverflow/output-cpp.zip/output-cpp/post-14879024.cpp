  com.drone_is_init = com.init_drone();

  Serial.println("One");
  Serial.println("Two");
  Serial.println("Three");

  Timer1.initialize(COMWDG_INTERVAL_USEC);
  Timer1.attachInterrupt(watchdog_timer);
