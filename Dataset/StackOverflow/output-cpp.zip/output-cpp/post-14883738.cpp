Marble marble;
Actor* children[2];
children[0] = &marble;

children[0]->speak();
