class Actor
{
  public:
    Actor();
    virtual void speak();  // virtual
  private:
};
