A(A const& rhs) 
: Base(rhs)
{
    memcpy(_data, rhs._data, sizeof(_data));
    setArray(_data);
}


A& operator=(A const& rhs) 
{
    if (this != &rhs) {
        static_cast<Base&>(*this) = rhs;
        memcpy(_data, rhs._data, sizeof(_data));
        setArray(_data);
    }
    return *this;
}
