float zpwm = 0;
byte var = 0;
float pwm = 0;
float result = 0;


float badactor() {
  *((long*)(&var+1)) = -1;
  return 3.45;
}

void setup() {
  Serial.begin(57600);
}

void loop() {

  zpwm += 0.5;
  pwm += 0.5;

  Serial.print("pwm=");
  Serial.print(pwm);
  Serial.print(" zpwm=");
  Serial.println(zpwm);

  result = badactor();
  pwm += result;
  zpwm += result;

  Serial.print("pwm=");
  Serial.print(pwm);
  Serial.print(" zpwm=");
  Serial.print(zpwm);
  Serial.print(" result=");
  Serial.println(result);

  uint8_t* ptr;
  ptr = (uint8_t*)&pwm;
  Serial.print((int)*(ptr));
  Serial.print("-");
  Serial.print((int)*(ptr+1));
  Serial.print("-");
  Serial.print((int)*(ptr+2));
  Serial.print("-");
  Serial.println((int)*(ptr+3));

  delay(1000);
}
