pwm=0.50 zpwm=0.50
pwm=0.00 zpwm=3.95 result=3.45
255-255-255-255
pwm=0.00 zpwm=4.45
pwm=0.00 zpwm=7.90 result=3.45
255-255-255-255
