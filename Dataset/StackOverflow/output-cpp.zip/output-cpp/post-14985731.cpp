// in myProject.ino
#include <arduinolib.h>
#include "MyLib.h"

// in Mylib.h
#include "./extra/SomeNiceFunctions.h"
