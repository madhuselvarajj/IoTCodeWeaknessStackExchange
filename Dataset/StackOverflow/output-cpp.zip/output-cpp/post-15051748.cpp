void function(int x)
{
    char response[64];

    sprintf(response, "GET /postTEST.php?first=%d", x);

    Serial.println(response);
}
