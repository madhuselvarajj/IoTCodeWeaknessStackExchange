#ifndef serialComms_h
#define serialComms_h

/* serialComms Class */
class serialComms
{
  public:
//       serialComms() {};
void init();
void readBytes(); // Will be used to create the array --> two variables for now...
void assignBytes();
    };

#endif
