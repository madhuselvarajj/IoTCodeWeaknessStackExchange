#include <Arduino.h>
#include <serialComms.h>

void serialComms::init()
{
  // This is where the constructor would be...right now we are too stupid to have one
}

void serialComms::readBytes()  // Target Pin,Values
{
  digitalWrite(11,HIGH);
  delay(250);
  digitalWrite(11,LOW);
  assignBytes();
}

void serialComms::assignBytes()
{
  for(int t  = 0;t<5;t++)
  {
    digitalWrite(10,HIGH);
    delay(250);
    digitalWrite(10,LOW);
  }   
}
