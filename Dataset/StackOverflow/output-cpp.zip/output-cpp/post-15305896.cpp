#include <serialComms.h>
serialComms testing;

void setup() {
  Serial.begin(9600);
}

void loop() {
}

void serialEvent()
{
  testing.readBytes();
  testing.assignBytes();
}
