int bin[4];
int bit = 8;
for(int i = 0; i < 4; i++)
{
    bin[i] = !!(num & bit);
    bit >>= 1;
}
