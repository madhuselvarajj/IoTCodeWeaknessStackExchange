 int bin[4] = {};

 bin[0] = !!(num & 8);
 bin[1] = !!(num & 4);
 bin[2] = !!(num & 2);
 bin[3] = !!(num & 1);
