std::unique_ptr<Base> myBase;

//Later...
myBase = new Derived;
myBase->myVirtualFunction();

//Automatically freed when the myBase smart pointer goes out of scope...
