Base *myBase = nullptr; //Or 'NULL' if you aren't using C++11
myBase = new Derived;

myBase->myVirtualFunction(); //Dereference the myBase pointer and call the function.

delete myBase; //Free the memory when you are finished.
