    void setup()
{

  Serial.begin(9600);
  char string_array[] = "hello";
  char data_array[] = {1,2,3,4,5,6};
  unsigned char data_array_uchar[] = {21,22,23,24,25,26};
  uint8_t uint8_array[] = {11,12,13,14,15,16};
  char alpha_array[] = {0x41,0x42,0x43,0x44,0x45,0x46};
  // take note that sizeof() is a precompile command... number of places/size of each place.

  updateUserPrint(string_array);
  updateUserWrite(data_array, sizeof(string_array));
  updateUserWriteUchar(data_array_uchar, sizeof(data_array_uchar));
  updateUserWriteUchar(uint8_array, sizeof(uint8_array));
  updateUserWriteUint(uint8_array, sizeof(string_array));
  updateUserAlpha(alpha_array, sizeof(string_array));
}
void updateUserPrint(char *s)
{  //note a string aka array of char's is ended with a null.
  Serial.print(s); // this can detect.
  Serial.println();
}
void updateUserWrite(char *t, size_t len)
{  //note an array of int's is not ended with a null. so you need to know how long it is.
  for (int n = 0; n < len ; n++) {
    Serial.print(t[n],DEC);
    Serial.print(",");
  }
  Serial.println();
}
void updateUserWriteUchar(unsigned char *t, size_t len)
{  //note an array of int's is not ended with a null. so you need to know how long it is.
  for (int n = 0; n < len ; n++) {
    Serial.print(t[n],DEC);
    Serial.print(",");
  }
  Serial.println();
}
void updateUserWriteUint(uint8_t *t, size_t len)
{  //note an array of int's is not ended with a null. so you need to know how long it is.
  for (int n = 0; n < len ; n++) {
    Serial.print(t[n],DEC);
    Serial.print(",");
  }
  Serial.println();
}
void updateUserAlpha(char *t, int len)
{  //note an array of int's is not ended with a null. so you need to know how long it is.
  for (int n = 0; n < len ; n++) {
    Serial.write(t[n]);
  }
  Serial.println();
}  
