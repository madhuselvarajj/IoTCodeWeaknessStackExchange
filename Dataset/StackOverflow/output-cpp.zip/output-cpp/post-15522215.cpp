class MyData {
public:
    A(size_t numShorts) : dataPtr(0) { dataPtr = malloc(numShorts * sizeof(short)); }
    ~A() { free(dataPtr); }
    operator short*() { return dataPtr; }
private:
    short* dataPtr;
}

MyData data(numShorts);
// do your stuff, you can still use data as you were before due the 'operator short*'
// allow the dtor to be called when you go out of scope
