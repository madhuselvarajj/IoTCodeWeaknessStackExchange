 void kilos(const std::vector<int> percentage,
            const std::vector<std::string> liquid);

// ...

kilos({40, 60}, {"water", "milk"});
