#define SERIALIDX_MIN   0
#define SERIALIDX_MAX   1

int idxSerialPortIndex = SERIALIDX_MIN;
char strSerialPort[oxFF];

while (true) {
   sprintf(strSerialPort, "/dev/ttyAMC%d", idxSerialPortIndex);
   arduino = open("/dev/ttyAMC0", O_RDWR | O_NOCTTY | O_NDELAY);
   if(arduino != -1) {
       fcntl(_arduino, F_SETFL, 0);
       ...  // read serial port here
   }
   if (++idxSerialPortIndex > SERIALIDX_MAX) 
       idxSerialPortIndex = SERIALIDX_MIN;
}
