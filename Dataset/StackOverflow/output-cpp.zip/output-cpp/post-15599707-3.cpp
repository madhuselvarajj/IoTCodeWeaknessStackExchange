template<typename T, void (T::*mf)()>
void adapter()
{
    (pX->*mf)();
}
