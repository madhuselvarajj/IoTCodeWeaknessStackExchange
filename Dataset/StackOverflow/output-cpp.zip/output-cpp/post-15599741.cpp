# include <boost/function.hpp>
# include <boost/bind.hpp>
class FunctionClass {
    private:
       double a_;
    public:
       FunctionClass (const double & a): a_(a ){}
       double multWithA (const double & x) const { return a_*x;}
       double operator ()(const double & x) const { return a_*x;}
};

FunctionClass myClass (2.0);
double x = 12.0;
boost :: function <double (FunctionClass *, double)> funcPtr , funcPtr1;
funcPtr =& FunctionClass :: multWithA;
funcPtr1 =& FunctionClass :: operator ();

std :: cout << myClass . multWithA (x) << std :: endl;
std :: cout << funcPtr (& myClass ,x) << std :: endl;
std :: cout << funcPtr1 (& myClass ,x) << std :: endl;

// Bind the function with the class instance
boost :: function <double (double)> funcPtrNew ;
funcPtrNew = boost :: bind (funcPtr ,& myClass ,_1);
std :: cout << funcPtrNew (x) << std :: endl;
