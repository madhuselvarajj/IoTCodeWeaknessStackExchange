#if defined(DEBUG)
    inline void debug(const char *s) { Serial.println(s); }
    inline void debug(const char *s, char *t) { Serial.print(s);Serial.println(t); }
#else
    inline void debug(const char *s) {  }
    inline void debug(const char *s, const char *t) { }
#endif
