struct Color
{
    unsigned char r;
    unsigned char g;
    unsigned char b;
};
