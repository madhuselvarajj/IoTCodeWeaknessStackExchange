#include <termios.h>

struct termios tio;
memset(&tio, 0, sizeof(tio));

// Open serial port in mode `8N1', non-blocking
tio.c_cflag = CS8 | CREAD | CLOCAL;
tio.c_cc[VMIN] = 1;
tio.c_cc[VTIME] = 5;

int fd = open(device, O_RDONLY);

cfsetospeed(&tio, B9600);
cfsetispeed(&tio, B9600);
tcsetattr(fd, TCSANOW, &tio);

while (1) {
    unsigned char byte;
    read(fd, &byte, 1);
    use_some_library_to_set_volume(byte);
}
