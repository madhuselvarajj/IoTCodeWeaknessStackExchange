#define POT_PIN 1

void setup()
{
    Serial.begin(9600); // 9600 baud is more than enough
}

void loop()
{
    int pot = analogRead(POT_PIN);
    unsigned char byte = (pot + 2) >> 2; // round and divide by 4
    Serial.write(pot);
    delay(100); // or do something useful
}
