#include <header.h> // which contatining some delay function
void blink(int pin)
{ 
    //Program the pin (which GPIO) to  high
    //delay function
    //Program the pin (which GPIO) to low
    //delay
    return 0;
}
main()
{
// to use Raspberry Pi board pin numbers  
GPIO.setmode(GPIO.BOARD)  //check this fun def and find out what it is doing and code it accordingly

// set up GPIO 11 as output channel  

// blink GPIO11 50 times  
for(i=0;i<50;i++)  
        blink(11);

GPIO.cleanup() ////check this fun def and find out what it is doing and code it
