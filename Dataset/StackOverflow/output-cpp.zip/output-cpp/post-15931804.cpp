char str[64];
strcpy(str, name);
strcat(str, ":");
strcat(str, data);
strcat(str, ",");
