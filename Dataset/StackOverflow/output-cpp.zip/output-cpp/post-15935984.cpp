namespace foo
{
    int val =1;
}

namespace bar
{
    int val =3;
}

using namespace foo;

int x = val; //Now x will be assigned with 1
