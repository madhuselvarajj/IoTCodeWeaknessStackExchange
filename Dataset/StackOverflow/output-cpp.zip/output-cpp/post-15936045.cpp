namespace foo
{
    int v =100;
}

namespace bar
{
    int v =500;
}
