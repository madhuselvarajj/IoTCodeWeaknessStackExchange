#include <iostream>

char mychar = 'k';
int ASCIItranslate(char ch) {
    return ch;
}

int main() {
    std::cout << ASCIItranslage(mychar);
    return 0;
}
