// if you get a connection, report back via serial:
if (client.connect("www.proxy.com", 8080)) {  // This is connecting to the proxy
Serial.println("connected");

// Make a HTTP request through proxy:
client.println("GET http://www.actualserver.com/search?q=arduino HTTP/1.0");
client.println();
