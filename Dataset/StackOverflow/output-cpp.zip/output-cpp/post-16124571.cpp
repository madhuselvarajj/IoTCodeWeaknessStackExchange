static int cnt = 0;

if (brightness2 == 0 || brightness2 == 255) {
    fadeAmount2 = -fadeAmount2 ; 
}

delay(30);
cnt = (cnt + 1) % 33;
if (cnt == 0) {
    Serial.println((byte)tempC);
}
