#include <cstdlib>  
int getNumber(char* pMsg){
    //assuming format is always R#
    return std::atoi((char*)(pMsg+1));
}
