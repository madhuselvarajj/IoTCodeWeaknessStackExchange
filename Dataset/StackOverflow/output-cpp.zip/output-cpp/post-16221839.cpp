    /* sscanf example */
    #include <cstdlib>

    int getNumber(char* pMsg){
        int result;
        ...
        sscanf (pMsg,"R%d",&result);  
        return result;
    }
