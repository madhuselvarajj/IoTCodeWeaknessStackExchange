typedef struct{ //maybe stick this in a union, depending on what the compiler does to it.
    unsigned char r:2;
    unsigned char g:2;
    unsigned char b:2;
}color;
const int numOfColors = 3;
color colors[numOfColors] = {
    {2,0,0},//r
    {1,1,0},//o
    {0,2,0}//g
};

for(int i = 0 ; 1 ; i++)
{
    color c = colors[i%numOfColors];
    //set color
    //update
    //wait
}
