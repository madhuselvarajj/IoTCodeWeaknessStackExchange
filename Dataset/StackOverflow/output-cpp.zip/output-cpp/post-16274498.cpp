char buf[1024];
char * cur = buf;

void * operator new(std::size_t n)
{
    char * res = cur;
    std::size_t inc = (n + 15) / 16 * 16;

    if (std::distance(cur, buf + sizeof(buf)) < inc)
        throw std::bad_alloc();

    cur += inc;

    return res;
}

void operator delete(void * p) noexcept
{
}
