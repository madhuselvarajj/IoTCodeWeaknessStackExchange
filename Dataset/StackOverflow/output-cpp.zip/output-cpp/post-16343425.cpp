/********************************************************/
/*      File:       abc.h                               */
/*      Author:     J. Kanze                            */
/*      Date:       02/05/2013                          */
/* ---------------------------------------------------- */

#ifndef abc_h_20130502O481MBxFZeAzz4dgIb7iC4Q9
#define abc_h_20130502O481MBxFZeAzz4dgIb7iC4Q9

#endif
