 template<typename Base>
 class Foo : public Base
 {
      //your code
 };
