SdFile file;
char filename[13];
sd.chdir("/",true);
uint16_t count = 1;
while (file.openNext(sd.vwd(),O_READ))
{
  file.getFilename(filename);
  Serial.print(count);
  Serial.print(F(": "));
  Serial.println(filename);
  count++;
}
file.close();
