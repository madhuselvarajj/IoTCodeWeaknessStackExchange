String myStrings[3] = {"a", "b", "c"};

for (int i = 0; i < 3; i++) {
    Serial.print(myStrings[i]);
}
