 Wire.begin();
 Wire.beginTransmission(DEV_ID);           //I am talking to you
 Wire.send(0xA1);                          //I want to change TH
 Wire.send(0x19);                          //Value of 25
 Wire.endTransmission();

 Wire.beginTransmission(DEV_ID);           //I am talking to you
 wire.send(0xA2);                          //I want to change TL
 Wire.send(0x19);                          //value of 25                      
 Wire.endTransmission();
