#ifndef Foo_H
#define Foo_H

int AAA();

#endif
