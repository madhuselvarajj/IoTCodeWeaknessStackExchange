#ifndef Foo_H
#define Foo_H

int AAA(void);  // Just the prototype, not the function body

#endif
