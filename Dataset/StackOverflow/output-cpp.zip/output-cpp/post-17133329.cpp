 WebServer &operator <<(WebServer &server,const prog_uchar *str)
 { server.printP(str); return server;}

 template<class T>
 inline WebServer &operator <<(WebServer &obj, T arg)
 { obj.print(arg); return obj; }
