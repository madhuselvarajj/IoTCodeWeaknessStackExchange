Motor motor1;
Motor motor2;

onSomethingChanged() {
  static int in1aprev, in1bprev;
  static int in2aprev, in2bprev;
  int in1a, in1b;
  int in2a, in2b;
  in1a = digitalRead(....
  same for other in's

  if( (in1a!=in1alast) || (in1b!=in1blast)) {
    motor1.encoderInput(in1a,in1b);
    in1alast = in1a;
    in1blast = in1b;
  }

  if( (in2a!=in2alast) || (in2b!=in1blast)) {
    motor2.encoderInput(in2a,in2b);
    in1a2ast = in2a;
    in1b2ast = in2b;
  }

  return;
} 
