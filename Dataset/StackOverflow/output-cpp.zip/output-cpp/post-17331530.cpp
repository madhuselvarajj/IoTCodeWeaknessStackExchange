void receiveMsg(MESSAGE_STRUCT* message)
{
  // receive bytes and put them back as integers
  intByte code_word, checksum;

  // receive byte by byte, wait for it if need be
  while( Serial.available() < 1 ) {delay(10);}
  message->start_byte = Serial.read();
  while( Serial.available() < 1 ) {delay(10);}
  message->length = Serial.read();
