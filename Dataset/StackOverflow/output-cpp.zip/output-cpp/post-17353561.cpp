fade = 0;
step = 1;
while(1)
   {
   step = fade == 0 ? 1 : (fade == 255 ? -1 : step);
   fade += step;
   analogWrite(redPin, fade);
   delay(30);
   analogWrite(greenPin, fade );
   delay(30);
   analogWrite(bluePin, fade);
   delay(30);
   }
