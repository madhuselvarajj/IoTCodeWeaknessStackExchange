int timekeeper=0;
while (1) 
{
    do_fade(timekeeper);
    if (timekeeper%100==0) {
      do_blink_off();
    }
    if (timekeeper%100==50) {
      do_blink_on();
    }
    delay(10);
    timekeeper++;
}
