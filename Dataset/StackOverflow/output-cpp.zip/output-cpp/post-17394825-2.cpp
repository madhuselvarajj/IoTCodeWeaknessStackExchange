const prog_char* fmt_error(int code) {
    switch (code) {
        case (1000): return F("Error XXX");
        case (1042): return F("Error which code is not contiguous");
        case (2042): return F("Another error");
    }
}
