typedef struct
{
    int code;
    prog_char* message;
} error_code;

const error_type error_codes[] =
{
    {0000, F("Unknown error code")},
    {1000, F("Error foo")},
    {1001, F("Error bar")},
    {2000, F("Error foobar")}
    ...
};

const prog_char* fmt_error(int code) {
    for (int i=0; i<sizeof(error_codes);++i)
        if (error_codes[i].code == code)
            return error_codes[i].message;
    return error_codes[0];
}
