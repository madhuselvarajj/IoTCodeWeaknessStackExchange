const prog_char* fmt_error(int code) {
    return error_code[code/1000][code%1000];
}

void loop()
{
   int result = device.GetStatus();
   Serial.println(fmt_error(result));
}
