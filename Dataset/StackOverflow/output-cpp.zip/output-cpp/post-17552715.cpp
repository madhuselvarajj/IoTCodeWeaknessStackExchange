double str_to_double(const char *data, size_t len)
{
    double d = 0.0;
    bool neg = false;
    int index = 0;

    if (data[index] == '-')
    {
    index++;
    neg = true;
    }

    while(data[index] != '.' && index < len)
    {
    if (isdigit(data[index]))
    {
        d = d * 10 + (data[index] - '0');
        index ++;
    }
    else 
    {
        // Handle "bad input" ... 
        return -1;
    }
    }
    if (data[index] == '.')
    {
    index ++;
    double div = 10.0;
    while(index < len)
    {
        if (isdigit(data[index]))
        {
        d += (data[index] - '0') / div;
        div *= 10;
        index++;
        }
        else
        {
        // Handle bad input
        return -1;
        }
    }
    }
    // Flip sign if need be. 
    if (neg)
    {
    d = -d;
    }
    return d;
}
