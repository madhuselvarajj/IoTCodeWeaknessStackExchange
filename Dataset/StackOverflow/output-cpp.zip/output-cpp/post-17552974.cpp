float result = 0;
float scale = 10;
bool pastDecPoint = false;
while(buff != '\n') {
    if(isdigit(buff){
          if(pastDecPoint) 
          {
             result = result + (buff / scale);
             scale = scale * 10;

           }
           else
           {
             result = (result * 10.0) + atoi(buff);
           } 
    } else if (buff == '.') {

        pastDecPoint = true;
    }
    buff = theSettings.read();
};
Serial.println(result);

}
