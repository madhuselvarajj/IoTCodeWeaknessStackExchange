// global scope
cv::Mat img1, img2, diffImage;

void yourFunction()
{
   ...
   if(condition)
   {
      img1 = cv::imread("/home/pi/test/Gray_2Image1.jpg", 0);
   }
   else
   {
      img2 = cv::imread("/home/pi/test/Gray_2Image2.jpg", 0);
   }
   ...
   diffImage = abs(img1-img2); // make sure img1 and img2 are loaded first
   ...
}
