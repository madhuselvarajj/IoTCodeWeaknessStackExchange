// global scope
cv::Mat img1, img2, diffImage;

void yourFunction()
{
   ...
   if(condition)
   {
      // wrong: you are creating a local variable that shadows the global one
      cv::Mat img1 = cv::imread("/home/pi/test/Gray_2Image1.jpg", 0);
   }
   ...
   diffImage = abs(img1-img2); // img1 is the global variable and not the local one in the previous if block!
   ...
}
