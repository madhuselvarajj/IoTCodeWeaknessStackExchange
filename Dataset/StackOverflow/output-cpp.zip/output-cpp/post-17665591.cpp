// global scope
cv::Mat img1, img2, diffImage;

void yourFunction()
{
   ...
   img1 = cv::imread("/home/pi/test/Gray_2Image1.jpg", 0);
   img2 = cv::imread("/home/pi/test/Gray_2Image2.jpg", 0);
   diffImage = abs(img1-img2);
   ...
}
