#ifndef VIEW_H
#define VIEW_H

#include "VG/openvg.h"
#include "VG/vgu.h"
#include "fontinfo.h"
#include "shapes.h"

class View{
private:
    int width, height;

public:
    View();
    int getWidth();
    int getHeight();
        void drawBackground();
        void initialize();
        void show();
};

#endif
