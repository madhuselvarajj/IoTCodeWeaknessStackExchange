#include "view.h"

View::View(){
int width, height;
    VGfloat w2, h2, w;
}

int View::getWidth(){
return width;
}

int View::getHeight(){
return height;
}

void View::drawBackground(){

Background(0,0,0);
Stroke(255,255,255,1);
Fill(255,0,0,1.0);
Circle(width/2, height/2, 100);
}

void View::initialize(){
init(&width, &height);
Start(width, height);
}

void View::show(){
End();
}
