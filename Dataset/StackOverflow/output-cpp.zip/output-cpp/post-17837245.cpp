std::vector<int> func()
{
    std::vector<int> r;
    r.push_back(42);
    r.push_back(1337);
    return r;
}
