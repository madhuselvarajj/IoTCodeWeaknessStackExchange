char compileDate[] = __DATE__;

int year = get4DigitInt(compileDate, 7);
int day = getInt(compileDate, 4);          // First character may be space
int month;
switch(compileDate[0]+compileDate[1]+compileDate[2]) {
    case 'J'+'a'+'n': month=1; break;
    case 'F'+'e'+'b': month=2; break;
    case 'M'+'a'+'r': month=3; break;
    case 'A'+'p'+'r': month=4; break;
    case 'M'+'a'+'y': month=5; break;
    case 'J'+'u'+'n': month=6; break;
    case 'J'+'u'+'l': month=7; break;
    case 'A'+'u'+'g': month=8; break;
    case 'S'+'e'+'p': month=9; break;
    case 'O'+'c'+'t': month=10; break;
    case 'N'+'o'+'v': month=11; break;
    case 'D'+'e'+'c': month=12; break;
}
std::tm time = { 0, 0, 0, day, month - 1, year - 1900 };
std::mktime(&time);
int day_of_week = time.tm_wday;   // 0=Sun, 1=Mon, ...

std::cout << "Time: " << hour << ":" << minute << ":" << second << std::endl;
std::cout << "Date: " << year << "-" << month << "-" << day << std::endl;
std::cout << "Day:  " << day_of_week << std::endl;
