#include<iostream>
#include <locale>

int main()
{
    setlocale(LC_CTYPE,"");
    wchar_t a=L'\u1234';
    std::wcout << a << std::endl;
    return 0;
}
