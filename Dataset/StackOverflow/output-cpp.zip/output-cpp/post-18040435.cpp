#include<iostream>
using namespace std;

int main()
{
    wchar_t a = L'\u1234';
    wcout << a << endl;
}
