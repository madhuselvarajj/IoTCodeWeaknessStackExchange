switch (c)
{
    case L'Λ':
    /* handle capital lambda */
    break;

    case L'Α':
    /* handle capital A */
    break;

    /* ... */
}
