 // always exec this:
 if (stopWhen == x)
 {
    stopWhen = -1;
    // stop beeping.
 }
