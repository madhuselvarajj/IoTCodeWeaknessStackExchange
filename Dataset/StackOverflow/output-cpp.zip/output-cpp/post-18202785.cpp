 if (stopwWhen = -1)
 {
    stopWhen = x;
    // beep etc.
 }
