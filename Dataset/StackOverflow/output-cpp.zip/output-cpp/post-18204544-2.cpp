// int bright - increment line - must load and store 2 bytes
// 18 bytes of code

    bright += 1;
 18a:   80 91 02 01     lds r24, 0x0102
 18e:   90 91 03 01     lds r25, 0x0103
 192:   01 96           adiw    r24, 0x01   ; 1
 194:   90 93 03 01     sts 0x0103, r25
 198:   80 93 02 01     sts 0x0102, r24
