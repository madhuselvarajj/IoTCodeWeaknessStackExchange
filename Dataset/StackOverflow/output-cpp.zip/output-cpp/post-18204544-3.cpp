// int8_t bright - increment line - only load and store 1 byte
// 10 bytes of code

   bright += 1;
 18a:   80 91 02 01     lds r24, 0x0102
 18e:   8f 5f           subi    r24, 0xFF   ; 255
 190:   80 93 02 01     sts 0x0102, r24
