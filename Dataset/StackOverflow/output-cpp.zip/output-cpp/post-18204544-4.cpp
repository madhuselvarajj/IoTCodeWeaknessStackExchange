// int - needs no type conversion, can directly load value 
// from addresses 0x0102 and 0x0103 and call
// 16 bytes code

 // apply current light level
  analogWrite(13,bright);
 1b0:   20 91 02 01     lds r18, 0x0102
 1b4:   30 91 03 01     lds r19, 0x0103     

 1b8:   8d e0           ldi r24, 0x0D   ; 13
 1ba:   b9 01           movw    r22, r18
 1bc:   0e 94 87 02     call    0x50e   ; 0x50e <analogWrite>
