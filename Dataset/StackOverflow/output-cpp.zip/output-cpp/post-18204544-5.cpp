// int8_t - needs a type conversion before call
// 20 bytes code
 
  // apply current light level
  analogWrite(13,bright);
 1a0:   80 91 02 01     lds r24, 0x0102
 1a4:   28 2f           mov r18, r24
 1a6:   33 27           eor r19, r19
 1a8:   27 fd           sbrc    r18, 7
 1aa:   30 95           com r19
 
 1ac:   8d e0           ldi r24, 0x0D   ; 13
 1ae:   b9 01           movw    r22, r18
 1b0:   0e 94 76 02     call    0x4ec   ; 0x4ec <analogWrite>
