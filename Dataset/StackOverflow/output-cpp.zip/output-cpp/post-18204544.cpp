boolean fadein = true;
int bright = 0;   // we will change this data type int <-> int8_t

void loop() {

  // adjust brightness based on current direction
  if(fadein) {
    bright += 1;
  }
  else {
    bright -= 1;
  }

  // apply current light level
  analogWrite(13,bright);
