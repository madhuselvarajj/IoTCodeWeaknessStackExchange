#include <string>

using namespace std;

template <class T>
class LinkedListItem {

  public:
    LinkedListItem(T value);
    T getValue();
    LinkedListItem<T>* getPreviousItem();
    void setPrevious(LinkedListItem<T>* previous);
    LinkedListItem<T>* getNextItem();
    void setNext(LinkedListItem<T>* next);

  private:
    LinkedListItem<T>* _previous;
    LinkedListItem<T>* _next;
    T _value;
};

template <class T>
LinkedListItem<T>::LinkedListItem(T value) {
  _value = value;
}

template <class T>
T LinkedListItem<T>::getValue() {
  return _value;
}

template <class T>
LinkedListItem<T>* LinkedListItem<T>::getPreviousItem() {
  return _previous;
}

template <class T>
void LinkedListItem<T>::setPrevious(LinkedListItem<T>* previous) {
  _previous = previous;
}

template <class T>
LinkedListItem<T>* LinkedListItem<T>::getNextItem() {
  return _next;
}

template <class T>
void LinkedListItem<T>::setNext(LinkedListItem<T>* next) {
  _next = next;
}

int main()
{
    LinkedListItem<string>* _list;
    return 0;
}
