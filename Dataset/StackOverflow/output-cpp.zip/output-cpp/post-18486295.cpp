std::string t;
t.push_back((hours/10) + '0');
...

return t;
