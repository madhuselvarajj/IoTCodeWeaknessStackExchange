#include <avr/io.h>
#include <util/delay.h>

int main()
{
    UCSR0B = 0;
    DDRD = 0b11111111;

    unsigned char upDown=1; // start going with the ports up
    unsigned char cylon=0;  // says which LED is on

    for(;;)
    {
        if(upDown==1){
            cylon++;
            if(cylon>=7) upDown=0;      // Reached the last LED
        }
        else {
            cylon--;
            if(cylon==0) upDown=1;      // Reached min LED
        }
            PORTD = 1 << cylon;
            _delay_ms(100);             // a little wait
    }
}
