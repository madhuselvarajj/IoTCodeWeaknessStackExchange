char SystemLogging::logBuff[BUF_LENGTH] = {};
char SystemLogging::logname[9] = {};
uint32_t SystemLogging::length = 0;
int SystemLogging::lineCount = 0;
int SystemLogging::data = 0;
