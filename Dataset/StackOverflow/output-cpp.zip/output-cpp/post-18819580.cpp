// in your .cpp file add:
char     SystemLogging::logBuff[BUF_LENGTH];
char     SystemLogging::logname[9];
uint32_t SystemLogging::length;
int      SystemLogging::lineCount;
int      SystemLogging::data;
