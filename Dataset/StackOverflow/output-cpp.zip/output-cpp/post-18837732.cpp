#include <vector>
#include <string>

std::vector<std::string> myFiles;
std::string file;
bool done = false;
char character;
while (!done)
{
  if (Serial.available())
  {
    character = Serial.read();
    if ((character == '\n') || (character == '\r'))
    {
      done = true;
    }
    else if (character == ',')
    {
      myfiles.push_back(file);
      file = "";
    }
    else
    {
      file += character;
    }
  }
}

Serial.println(myFiles[0].c_str());
