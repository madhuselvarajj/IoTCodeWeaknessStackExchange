    #include<iostream>
    #include<vector>
    using namespace std;

    enum trigger_status {ON, OFF, NON_STICKY};

    int main(){
       vector<trigger_status> sticky_triggers(251, trigger_status::OFF); // you can add element to it dynamically, default all to off

       sticky_triggers[0] = trigger_status::ON;
       sticky_triggers[9] = trigger_status::ON;

       sticky_triggers.push_back(trigger_status::ON); // sticky_triggers[251] = true, now u have 252 elements
    }
