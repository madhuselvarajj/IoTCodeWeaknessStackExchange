#define ARRAY_SIZE 10
#define BOOL unsigned int
#define TRUE 1
#define FALSE 0

int main()
{
  BOOL stickyTriggers[ARRAY_SIZE] = { FALSE };

  stickyTriggers[1] = TRUE ;
  stickyTriggers[9] = TRUE ;

  return 0;

}
