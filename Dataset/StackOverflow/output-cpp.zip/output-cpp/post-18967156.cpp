#include <iostream>

using namespace std;

int main()
{
   bool b[5] = {true, false, true, false, true};
   cout << "Hello World" << endl; 

   for (int i=0; i < 5; i++) {
       if (b[i]) {
           cout<< "Index " << i << " is true" <<endl;
       } else {
           cout<< "Index " << i << " is false"<<endl;
       }
   }

   return 0;
}
