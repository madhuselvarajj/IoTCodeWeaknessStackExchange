#include <HashMap.h>

const byte HASH_SIZE = 5; 
HashType<int,boolean> hashRawArray[HASH_SIZE]; 
HashMap<int,boolean> hashMap = HashMap<int,boolean>(hashRawArray, HASH_SIZE); 

void setup() {

    Serial.begin(9600);                                 

    hashMap[0](1,true);
    hashMap[1](2,false);
    hashMap[2](3,false);
    hashMap[3](4,false);
    hashMap[4](9,true);

    Serial.println(hashMap.getValueOf(1));
    Serial.println(hashMap.getValueOf(2));
    Serial.println(hashMap.getValueOf(9));

}
