// bitmapped booleans
const int IntBits = 16;
const int NumTriggers = 256;
const int idxSticky = 0;
const int idxDown = 1;
unsigned int TriggerMap[NumTriggers/IntBits][2];

void setup() {
  Serial.begin(9600);
  clearTriggerMap; // set all to not sticky and not down
  // tests
  setStickyTrigger(1, true, true);
  setStickyTrigger(2, true, false);
  setStickyTrigger(3, true, false);
  setStickyTrigger(9, true, true);
  setStickyTrigger(30, true, true);
  setStickyTrigger(128, true, true);
  setStickyTrigger(255, true, true);
}

void loop() {
  // tests
  Test(0);
  Test(1);
  Test(2);
  Test(3);
  Test(9);
  Test(30);
  Test(128);
  Test(255);
  delay(5000);
}
void Test( int ATrigger) {
  // testing
  if (IsStickyTrigger(ATrigger)) {
    Serial.print( "Trigger ");
    Serial.print(ATrigger);
    Serial.print(" is sticky");
    if (IsStickyTriggerDown(ATrigger)) {
      Serial.print(" and it is down");
    }
    }
  Serial.println();
}


void clearTriggerMap() {
  for (int i = 0; i < NumTriggers/IntBits; i++) {
    for (int j = 0; j < 2; j++){
      TriggerMap[i][j] = 0;
    }
  }
}

void setStickyTrigger(int AIndex, boolean ASticky, boolean IsDown) {
  unsigned int o;
  unsigned int b = 1;
  o = AIndex / IntBits;
  b = b << (AIndex % IntBits);
 if (ASticky) {
    TriggerMap[o][idxSticky] = TriggerMap[o][idxSticky] | b;
  } else {
    b = ~b;
    TriggerMap[o][idxSticky] = TriggerMap[o][idxSticky] & b;
  }
  if (IsDown) {
    TriggerMap[o][idxDown] = TriggerMap[o][idxDown] | b;
  } else {
    b = ~b;
    TriggerMap[o][idxDown] = TriggerMap[o][idxDown] & b;
  }

}

boolean IsStickyTrigger(int AIndex) {
  unsigned int b = 1;
  b = b << (AIndex % IntBits);
  return (TriggerMap[AIndex / IntBits][idxSticky] & b) != 0;
}

boolean IsStickyTriggerDown(int AIndex) {
  unsigned int b = 1;
  b = b << (AIndex % IntBits);
  return (TriggerMap[AIndex / IntBits][idxDown] & b) != 0;
}
