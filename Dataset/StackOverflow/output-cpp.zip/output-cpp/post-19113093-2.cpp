struct set {
  char variable1[10];
  char variable2[10];
  char variable3[10];
} mySet = {{0}, {0}, {0}};
