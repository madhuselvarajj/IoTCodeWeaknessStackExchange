set()
: variable1({0})
, variable2({0})
, variable3({0}) {
}
