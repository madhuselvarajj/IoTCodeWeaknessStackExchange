struct set
{
    //  ...
    set() { /* ... */ }
};
