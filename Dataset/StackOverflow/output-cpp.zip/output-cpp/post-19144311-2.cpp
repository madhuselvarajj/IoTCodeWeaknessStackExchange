#include "SD_c_iface.h"

#include "SD.h"

struct _SD_File
{
  File f;
};

size_t SD_File_write(SD_File* file, const uint8_t *buf, size_t size)
{
  return (file) ? file->f.write(buf, size) : 0;
}

boolean SD_begin(uint8_t csPin)
{
  SD.begin(csPin);
}

void SD_open(const char *filename, uint8_t mode, SD_File** file)
{
  if (!file)
    return;
  *file = new _SD_File();
  (*file)->f = SD.open(filename, mode);
}

// TODO Add more function wrappers
