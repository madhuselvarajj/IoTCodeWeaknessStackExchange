#ifndef SD_C_IFACE_H
#define SD_C_IFACE_H

#include <Arduino.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Wrapper around File type */

typedef struct _SD_File SD_File;

size_t SD_File_write(SD_File* file, const uint8_t *buf, size_t size);

/* TODO Wrap all required File functions */

/* Wrapper around SD type */

boolean SD_begin(uint8_t csPin);

void SD_open(const char *filename, uint8_t mode, SD_File** file);

/* TODO Wrap all required SD functions */

#ifdef __cplusplus
}
#endif
#endif
