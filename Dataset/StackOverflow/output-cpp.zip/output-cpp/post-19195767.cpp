class Foo {
  void method() {
    x = 5;
  }
  int x;
}
