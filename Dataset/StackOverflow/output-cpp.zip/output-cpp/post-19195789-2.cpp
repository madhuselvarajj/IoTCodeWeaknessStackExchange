class velocity
{
 public:
    velocity()
    {
    }

    static void functionISR_name()
    {
      // Do whatever needed.
    }

   // … Your methods
};

velocity YourOneAndOnlyInstanceOfThisClass;

void functionISR_name_delegation()
{
  YourOneAndOnlyInstanceOfThisClass.functionISR_name();
}

void setup()
{
  attachInterrupt(functionISR_name_delegation);

  // …other stuff…
}
