class velocity
{
    static velocity *pThisSingelton;
 public:
    velocity()
    {
      pThisSingelton=this;
    }

    static void functionISR_name()
    {
      pThisSingelton->CallWhatEverMethodYouNeeded();
      // Do whatever needed.
    }

   // … Your methods
};

velocity *velocity::pThisSingelton;
velocity YourOneAndOnlyInstanceOfThisClass;

void setup()
{
  attachInterrupt(&velocity::functionISR_name);

  // …other stuff…
}
