uint8_t dataHeader = 0xff;
uint8_t numberOfData;
uint8_t rgb[3];
uint8_t redPin, greenPin, bluePin;

void setup(){

    Serial.begin(9600);

    // INITIALIZE YOUR PINS AS YOU NEED
    //
    //


}

void loop(){

    if (Serial.available() > 1) {

        uint8_t recievedByte = Serial.read();

        if (recievedByte  == dataHeader) { // read first byte and check if it is the beginning of the stream

            delay(10);
            numberOfData = Serial.read(); // get the number of data to be received.

            for (int i = 0 ; i < numberOfData ; i++) {
                delay(10);
                rgb[i] = Serial.read();
            }

        }

    }

    analogWrite (redPin, rgb[0]);
    analogWrite (greenPin, rgb[1]);
    analogWrite (bluePin, rgb[2]);

}
