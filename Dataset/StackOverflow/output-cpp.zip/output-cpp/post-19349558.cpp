char *c = malloc(sizeof(long) + 1);

if (!c) {
  // handle ENOMEM
}

strncpy(c, (const char *)&GMT, 4);

c[sizeof(long)] = '\0';
