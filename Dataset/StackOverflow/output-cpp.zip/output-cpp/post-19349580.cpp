char buf[0x100];
int n = snprintf(buf, sizeof buf, "%ld", GMT);
if (n > 0) {
    modem.write((const uint8_t *)buf, n)
}
