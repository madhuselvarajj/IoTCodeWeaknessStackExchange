CommunicationModuleTCPIP::CommunicationModuleTCPIP(/*...*/)
    :ServerObject(5000)
{
   /* code */
}
