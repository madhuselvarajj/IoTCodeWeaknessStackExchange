class CommunicationModuleUSB
{
    //Other stuff
    static void SendBuffer(uint8_t * Buffer, int Size);
    //Other stuff
}
