#define STATIC_STRING "Hi there"

void testfunc(char**outStr){
    *outStr=STATIC_STRING;
}

int main(){
   char*myStr;
   testfunc(&myStr);
   //From now on, myStr is a string using preallocated memory.
}
