void loop()
{
    int CurrentState = analogRead(AccPin);
     if(CurrentState > ThresHold || CurrentState < ThresHold)
     {boolean IsNoding = CheckForNoding();} 
     if(IsNoding)
     {
         //Do Whatever You Want
     }
     else
     delay(TimeInterVal); 
}

boolean CheckForNoding()
{ 
  Count = 0;
  boolean State = false;
  while(Count<MinToConsiderNode) // Your Case 100?!
  {
      int CurrentState = analogRead(AccPin);
      if(CurrentState > ThresHold || CurrentState < ThresHold)
      {
          int Count ++;
          delay(TimeInterval) // What you Think Should Be The Time Period Between each => Head Going Up or Down
          State = true;
      }
      else 
        {
            State = false;
            break;
        }
  }

    return State;
}
