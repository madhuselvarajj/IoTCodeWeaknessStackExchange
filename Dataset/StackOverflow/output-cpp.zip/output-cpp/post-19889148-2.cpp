  #include <iostream>

  const int NR_OF_CODES = 4;
  const int RADIO_ONOFF = 0;
  const int CODE_LENGTH = 11;

  const unsigned char RADIO_ONOFF_ARR[] = { 180,99,33,11,22,33,55, 22,22,33, 10};

  int main()
  {
    unsigned char codes[CODE_LENGTH][NR_OF_CODES] = {
                                                   {0},
                                                  };
    std::cout << "Before:\n";

    for(int x = 0; x < CODE_LENGTH; x++)
    {
      std::cout << static_cast<int>(codes[RADIO_ONOFF][x]) << ", ";
    }

    codes[RADIO_ONOFF][3] = 3;

    std::cout << "\nAfter:\n";

    for(int x = 0; x < CODE_LENGTH; x++)
    {
      std::cout << static_cast<int>(codes[RADIO_ONOFF][x]) << ", ";
    }

    // or try memcpy 
    memcpy(codes[RADIO_ONOFF], RADIO_ONOFF_ARR, sizeof RADIO_ONOFF_ARR);

    std::cout << "\nAfter Memcpy:\n";

    for(int x = 0; x < CODE_LENGTH; x++)
    {
      std::cout << static_cast<int>(codes[RADIO_ONOFF][x]) << ", ";
    }

    char c;
    std::cin >> c;
    return 0;
  }
