string SerialComm::read_data() {
    int receivedbyte = 0;

    while (true) {
        receivedbyte = read(fd, buffer, BUFFER_SIZE - 1);
        if (receivedbyte > 0) 
        {
            buffer[receivedbyte] = '\0';
            return string( buffer );
        }
    }
}
