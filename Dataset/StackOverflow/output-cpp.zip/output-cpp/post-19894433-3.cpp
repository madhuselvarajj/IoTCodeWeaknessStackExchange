string SerialComm::read_data()
{
    while (true)
    {
        size_t pos = received.find_first_of('\n', 0);
        if (pos != string::npos)
        {
            string result = received.substr(0, pos);
            received.erase(0, pos);
            return result;
        }

        int receivedbytes;
        do
        {
            receivedbytes = read(fd, buffer, BUFFER_SIZE - 1);
        } while (receivedbytes == 0);

        if (receivedbytes < 0)
            abort();  // error... you might want to handle it more cleanly, though

        buffer[receivedbytes] = 0;
        received += string( buffer );
    }
}            
