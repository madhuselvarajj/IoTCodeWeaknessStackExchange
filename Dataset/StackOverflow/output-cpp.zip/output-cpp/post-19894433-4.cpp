string SerialComm::read_data()
{
    while (true)
    {
        size_t pos = received.find_first_of('\n', 0);
        if (pos != string::npos)
        {
            string result = received.substr(0, pos);
            received.erase(0, pos);
            return result;
        }

        int receivedbytes = read(fd, buffer, BUFFER_SIZE - 1);

        if (receivedbytes < 0)
            abort();  // error... you might want to handle it more cleanly, though

        if (receivedbytes == 0)
            return string();  // nothing to see yet

        // Add received data to buffer and loop to see if we have a newline yet.           
        buffer[receivedbytes] = 0;
        received += string( buffer );
    }
}            
