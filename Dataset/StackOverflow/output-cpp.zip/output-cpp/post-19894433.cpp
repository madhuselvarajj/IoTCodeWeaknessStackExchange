string SerialComm::read_data() {
    int state = 1;
    int receivedbyte = 0;  // never used!

    while (true) {
        state = read(fd, buffer, BUFFER_SIZE);
        if (state > 0) 
        {
            return string( buffer );
        }
    }
    buffer[receivedbyte + 1] = '\0';  // never reached!  And "off-by-one" if it were...
}
