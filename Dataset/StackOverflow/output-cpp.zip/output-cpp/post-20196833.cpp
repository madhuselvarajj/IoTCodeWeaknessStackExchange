if (rxChardata == ':') {
    // Consume the ':'
    rxCharData = TinyWireS.receive();
    int n = 0;
    while (isdigit(rxCharData)) {
        n = n * 10 + (rxCharData - '0');
        rcCharData = TinyWireS.receive();
    }
    Serial.println(n);
}
