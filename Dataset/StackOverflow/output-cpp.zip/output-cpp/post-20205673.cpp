bool getDispPixel(uint8_t x, uint8_t y, uint8_t num) __attribute__((noinline));
bool getDispPixel(uint8_t x, uint8_t y, uint8_t num)
{
    // body of the function here
}

void setDispPixel(uint8_t x, uint8_t y, uint8_t num, bool state) __attribute((noinline));
void setDispPixel(uint8_t x, uint8_t y, uint8_t num, bool state)
{
    // body of the function here
}
