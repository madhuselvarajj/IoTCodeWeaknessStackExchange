for (int n=0;n<5;n++)
{
    double x = pow(2,n);
    Serial.print(n); 
    Serial.print(" ");
    Serial.print(x);
    Serial.print(" ");
    Serial.println((int)x); // cast as int here
}
