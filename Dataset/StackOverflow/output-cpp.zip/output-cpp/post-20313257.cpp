void setup() {
  // initialize the pushbutton pins as an input:
  pinMode(foodPin, INPUT); 
  pinMode(painPin, INPUT);
  pinMode(ucsPin, INPUT);
  pinMode(csPin, INPUT);
  pinMode(lightPin, INPUT);
  Serial.begin(9600);
  int ix=0;

  // define behavioral methods
  void mody (int ix, int brain[], int stimulus[])
