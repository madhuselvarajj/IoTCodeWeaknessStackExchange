 String inString = "08000AE23BDB ";

  if (inString != null) {
    inString = trim(inString);

    String[] data = split(inString, ",");

    if (data.length >=1) 
    {
      //direction1 = data[0];
    }
    println(unhex(data[0]));
  }
