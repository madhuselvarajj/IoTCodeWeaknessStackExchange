class MenuMgr
{
private:
   buffer _buf;
public:
   void set_displaybuff(buffer &buffer)
  {
     _buf= buffer;     
  }
};
