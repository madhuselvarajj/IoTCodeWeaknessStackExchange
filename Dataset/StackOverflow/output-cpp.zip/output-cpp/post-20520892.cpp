//incommeing: jsj123456asklfj654321faskl
int x,y;
x=Serial.parseInt();
y=Serial.parseInt();

Serial.println(x);//123456
Serial.println(y);//654321
