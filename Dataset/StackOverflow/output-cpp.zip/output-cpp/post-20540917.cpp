float highestTemperature(float temperaturearray[]) {
  int arraylength = 5; //knows how large the array is
  int currentlargestindex = 0; //Assume first item is hottest one
  for(int i = 1; i < arraylength; i++) {//Don't need to check 0 again, check just 1, ...!
    if(temperaturearray[i] > temperaturearray[currentlargestindex]) {
      currentlargestindex = i; 
      //hottest=temperaturearray[i]; //Not needed, same as temperaturearray[currentlargestindex]
    }
  }
  //This is a float returning function, so return it!
  return temperaturearray[currentlargestindex];
}
