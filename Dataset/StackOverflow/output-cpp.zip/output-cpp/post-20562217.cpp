while (1) 
{ 
    ClearCommError(hPort,&dwErrors,&commStatus); 
    if (commStatus.cbInQue != 0) break; 
    Sleep(10); 
} 
ReadFile(hPort,&data,1,&dwBytesRead,NULL);
