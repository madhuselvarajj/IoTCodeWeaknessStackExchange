char* make_ssid(char const* value) {
    static std::unique_ptr<char[]> memory;
    std::size_t n = strlen(value);
    memory.reset(new char[n + 1]);
    strncpy(memory.get(), value, n + 1);
    return memory.get();
}
char* ssid = make_ssid(WLAN_SSID);
