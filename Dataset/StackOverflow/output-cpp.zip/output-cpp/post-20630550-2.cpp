digitalWrite(3, !switchL            );
digitalWrite(4,  switchL && !switchR);
digitalWrite(5,  switchL &&  switchR);
digitalWrite(6, !switchL &&  switchR);
digitalWrite(7,             !switchR);
