ADS1X15::ADS1X15() {
    m_test = 99;
}

void ADS1X15::begin(uint8_t i2cAddress) {
    m_i2cAddress = i2cAddress;
}
