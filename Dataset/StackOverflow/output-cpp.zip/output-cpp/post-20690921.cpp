    if (switchL == HIGH && switchR == LOW) { //When the left button is pressed but the right button is not
  digitalWrite(4, HIGH);
  digitalWrite(3, LOW);
} else {
  digitalWrite(4, LOW);
  digitalWrite(3, HIGH); 
}
 if (switchR == HIGH && switchL == LOW) { //When the right button is pressed but the left button is not
  digitalWrite(6, HIGH);
  digitalWrite(7, LOW);       
} else {
  digitalWrite(6, LOW);
  digitalWrite(7, HIGH); 
}
