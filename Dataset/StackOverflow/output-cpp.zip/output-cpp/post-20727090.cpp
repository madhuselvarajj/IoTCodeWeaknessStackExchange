#ifndef FOOBAR_GENERALPURPOSEIO_H
#define FOOBAR_GENERALPURPOSEIO_H

namespace Foobar
{
   class FOOBAR_EXPORT GeneralPurposeIO
   {
       public:

           enum Direction {
               Input,
               Output
           };

           explicit GeneralPurposeIO(quint32 gpioNumber = 0);
           ~GeneralPurposeIO();

           int gpioExport();
           int gpioUnexport();
           bool isGpioExported();

           quint32 gpioNumber() const;
           void setGpioNumber(quint32 gpioNumber);

           Direction direction() const;
           int setDirection(Direction direction);

           qint32 value() const;
           int setValue(qint32 value);

       private:

           class Private;
           Private *const d;
   };
}

#endif // FOOBAR_GENERALPURPOSEIO_H
