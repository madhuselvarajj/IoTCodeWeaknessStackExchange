  End=content.length();
  yindex= content.indexOf("y");

  x=content.substring(1,yindex);
  y=content.substring(yindex+1, End);

  Serial.print("x = "); Serial.println (x);
  Serial.print("y = "); Serial.println (y);

  char xbuf[10] = "";
  x.toCharArray(xbuf, 10);
  xt = atof(xbuf);
  Serial.print("xt = "); Serial.println(xt);

  char ybuf[10] = "";
  y.toCharArray(ybuf, 10);
  yt = atof(ybuf);
  Serial.print("yt = "); Serial.println(yt);
