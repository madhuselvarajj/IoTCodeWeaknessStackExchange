  content="";
  while (Serial.available() < 1) {}
  while (Serial.available()) 
  {
    character = Serial.read();
    content += character;
    delay(10);
  }

  Serial.print("content = "); Serial.println (content);
