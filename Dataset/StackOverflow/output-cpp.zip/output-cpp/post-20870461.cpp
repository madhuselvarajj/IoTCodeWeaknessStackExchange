# See: http://code.google.com/p/arduino/wiki/Platforms

##############################################################

myArduino11MgHz.name=Arduino 11MgHz

myArduino11MgHz.vid.0=0x2341
myArduino11MgHz.pid.0=0x0043
myArduino11MgHz.vid.1=0x2341
myArduino11MgHz.pid.1=0x0001

myArduino11MgHz.upload.tool=avrdude
myArduino11MgHz.upload.protocol=arduino
myArduino11MgHz.upload.maximum_size=32256
myArduino11MgHz.upload.maximum_data_size=2048
myArduino11MgHz.upload.speed=115200

myArduino11MgHz.bootloader.tool=avrdude
myArduino11MgHz.bootloader.low_fuses=0xFF
myArduino11MgHz.bootloader.high_fuses=0xDE
myArduino11MgHz.bootloader.extended_fuses=0x05
myArduino11MgHz.bootloader.unlock_bits=0x3F
myArduino11MgHz.bootloader.lock_bits=0x0F
myArduino11MgHz.bootloader.file=optiboot/optiboot_atmega328.hex

myArduino11MgHz.build.mcu=atmega328p
myArduino11MgHz.build.f_cpu=11059200L
myArduino11MgHz.build.board=AVR_myArduino11MgHz
myArduino11MgHz.build.core=arduino:arduino
myArduino11MgHz.build.variant=arduino:standard

##############################################################
