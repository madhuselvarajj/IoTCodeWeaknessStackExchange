int bytesToRead = 0;
int currBytePtr = 0;

int RGB[9];
while (9 > currBytePtr) { // we need 9 bytes of data
    if (0 < (bytesToRead = Serial.available())) { // have something to read
        for (int i = 0; i < bytesToRead; ++i ) {
            RGB[currBytePtr++] = Serial.read();
            if (9 == currBytePtr) { // we have enough data
                break;
            }
        }
    } else {
        delay(1000); // sleep a bit
    }
} // while

// process data received
...
