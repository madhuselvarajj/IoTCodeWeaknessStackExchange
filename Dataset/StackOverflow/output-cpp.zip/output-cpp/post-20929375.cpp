char buffer[10];
int index=0;
while (Serial.available()){
    buffer[index++]=Serial.read();
    if (index>8) {
        ProcessData(buffer);
        index=0;
    }
}
