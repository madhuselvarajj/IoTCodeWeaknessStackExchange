uint16_t sample_it() {
    const uint16_t sample = analogRead(...);
    const uint16_t result = do_somehting(sample);
    return result;
}
