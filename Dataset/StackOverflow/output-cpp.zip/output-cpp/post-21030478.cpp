if(myStr[i - 2] == '1')
//                 ^^^ single quotes to specify character value.
{
    digitalWrite(int(i), HIGH);
}
else
{
    Serial.println(myStr[i - 2]);
}
