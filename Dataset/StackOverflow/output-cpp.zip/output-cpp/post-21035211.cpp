int sensorPin = 0;
const int buzzerPin = 2;
const int sensorValue = analogRead(sensorPin);
//const int songLength = 16; // used sizeof() function below
//const int numNotes= 8;     // dido
const int tempo = 100;
const int off = LOW;
const int on = HIGH;

char names[] =     {'c', 'd', 'e', 'f', 'g', 'a', 'b', 'C'};
const int freq[] = {262, 294, 330, 349, 392, 440, 494, 523};

const int beat[] = {1,1,1,1,1,1,4,4,2,1,1,1,1,1,1,4,4,2};
char notes[] = "cd fda ag cdf dg gf "; // Note length of notes[] should equal length of beat[]

void setup()
{  
  pinMode(buzzerPin, OUTPUT);
  pinMode(13, INPUT);
  pinMode(12, INPUT);
  pinMode(11, INPUT);
  pinMode(10, INPUT);
  pinMode(9, INPUT);
  pinMode(8, INPUT);
  pinMode(6, INPUT);
  pinMode(5, INPUT);
  pinMode(4, INPUT);
  pinMode(0, INPUT);
}

void loop() 
{  
  int i, duration;
  for (i = 0; i < sizeof(beat); i++) 
  {
    duration = beat[i] * tempo;                                 
    if (notes[i] == ' ')          
    {
      delay(duration);           
    }
    else                          
    {
      tone(buzzerPin, frequency(notes[i]), duration);
      delay(duration);            
    } 


    delay(tempo/10);      
  }
  while(true){
  }
}
int frequency(char note) 
{
  int i;   


  for (i = 0; i < sizeof(notes); i++)  
  {
    if (names[i] == note)         
    {
      return(freq[i]);     
    }
  }

}
