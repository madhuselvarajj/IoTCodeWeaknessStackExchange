switch(mode){
     case MODE_PRESSURE: mode = MODE_ALT; 
             break; 

     case MODE_ALT: mode = MODE_PRESSURE; 
             break;
}
