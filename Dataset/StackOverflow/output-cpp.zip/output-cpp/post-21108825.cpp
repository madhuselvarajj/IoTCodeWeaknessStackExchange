#include <stdio.h>

const int BTN_MODE = 0;
const int MODE_PRESSURE = 1;    // display pressure and temp
const int MODE_ALT = 2; // display altitude relative to sea level
int mode;   // stores the current mode

void setup()
{
    mode = MODE_PRESSURE;
}

void loop()
{

    // Read mode button and set mode accordingly
    // int buttonPressed = readButtons();
    int buttonPressed = BTN_MODE;

    switch (buttonPressed)
    {
        case 0:
            if (mode == MODE_PRESSURE)
            {
                mode = MODE_ALT;
                break;
            }
            if (mode == MODE_ALT)
            {
                mode = MODE_PRESSURE;
                break;
            }
            //Serial.println(mode); // <<-- always prints 1 ?!
            break;
    }
    printf(" The mode value is : %d\n", mode);
}

void main()
{
    setup();
    loop();
}
