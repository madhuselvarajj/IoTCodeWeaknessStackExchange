void readAllThePots(struct Pot * pot, int potCount) {
    for(int i = 0; i < potCount; i++) {
        int reading = map(analogRead(pot[i].pin), 0, 664, 0, 200);

        if(abs(reading - pot[i].lastReading) >= pot[i].threshold) {
            pot[i].currentReading = (reading/2);
            Serial.println(pot[i].currentReading);
            pot[i].lastReading = reading;
        }
    }
}

void loop() {
    readAllThePots(pots, 2);
    delay(10);
}
