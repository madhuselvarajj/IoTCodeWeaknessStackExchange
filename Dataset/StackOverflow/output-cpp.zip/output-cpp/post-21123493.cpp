struct Pot {
    byte pin;
    int threshold;
    int lastReading;
    int currentReading;
};

// defining an array of 2 Pots, one with pin A0 and threshold 2, the
// other with pin A2 and threshold 3. Everything else is automatically
// initialized to 0 (i.e. lastReading, currentReading). The order that
// the fields are entered determines which variable they initialize, so
// {A1, 4, 5} would be pin = A1, threshold = 4 and lastReading = 5
struct Pot pots[] = { {A0, 2}, {A2, 3} };

void rePot(struct Pot * pot) {
    int reading = map(analogRead(pot->pin), 0, 664, 0, 200);

    if(abs(reading - pot->lastReading) >= pot->threshold) {
        pot->currentReading = (reading/2);
        Serial.println(pot->currentReading);
        pot->lastReading = reading;
    }
}

void setup(){
    Serial.begin(9600);
}

void loop() {
    rePot(&pots[0]);
    rePot(&pots[1]);
    delay(10);
}
