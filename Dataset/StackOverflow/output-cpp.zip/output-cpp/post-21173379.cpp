    snd_seq_event_t ev;
    snd_seq_ev_clear(&ev);
    snd_seq_ev_set_direct(&ev);

    /* either */
    snd_seq_ev_set_dest(&ev, 64, 0); /* send to 64:0 */
    /* or */
    snd_seq_ev_set_subs(&ev);        /* send to subscribers of source port */

    snd_seq_ev_set_noteon(&ev, 0, 60, 127);
    snd_seq_event_output(seq, &ev);

    snd_seq_ev_set_noteon(&ev, 0, 67, 127);
    snd_seq_event_output(seq, &ev);

    snd_seq_drain_output(seq);
