-- snip --
00000096 <main>:
-- snip --
  a0:   cd b7           in  r28, 0x3d   ; 61
  a2:   de b7           in  r29, 0x3e   ; 62
  a4:   86 e0           ldi r24, 0x06   ; 6
  a6:   e0 e0           ldi r30, 0x00   ; 0
  a8:   f1 e0           ldi r31, 0x01   ; 1
  aa:   de 01           movw    r26, r28
  ac:   11 96           adiw    r26, 0x01   ; 1
  ae:   01 90           ld  r0, Z+
  b0:   0d 92           st  X+, r0
  b2:   8a 95           dec r24
  b4:   e1 f7           brne    .-8         ; 0xae <main+0x18>
  b6:   be 01           movw    r22, r28
  b8:   6f 5f           subi    r22, 0xFF   ; 255
  ba:   7f 4f           sbci    r23, 0xFF   ; 255
  bc:   80 e0           ldi r24, 0x00   ; 0
  be:   90 e0           ldi r25, 0x00   ; 0
  c0:   0e 94 63 00     call    0xc6    ; 0xc6 <strcpy>
-- snip --
000000c6 <strcpy>:
  c6:   fb 01           movw    r30, r22
  c8:   dc 01           movw    r26, r24
  ca:   01 90           ld  r0, Z+
  cc:   0d 92           st  X+, r0
  ce:   00 20           and r0, r0
  d0:   e1 f7           brne    .-8         ; 0xca <strcpy+0x4>
  d2:   08 95           ret
