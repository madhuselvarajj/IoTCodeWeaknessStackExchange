#include <string.h>
int main(void) {
    char p[] = "hello";
    strcpy(0, p);
    while(1);
}
