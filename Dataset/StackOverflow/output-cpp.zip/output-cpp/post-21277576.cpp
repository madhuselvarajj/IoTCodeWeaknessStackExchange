class LEDLamps
{
    ...
    std::vector<Wave> waveVector;
};

...

LedLamps::LEDLamps(...)
    : waveVector(numberOfWaves, Wave(10,2,25,150,100))
{
}
