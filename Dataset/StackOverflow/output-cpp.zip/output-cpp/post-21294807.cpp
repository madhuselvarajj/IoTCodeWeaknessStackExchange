int sensorValue = analogRead(A0);
float voltage = sensorValue * (5.0 / 421.0);
std::ostringstream oss;
oss << std::fixed << std::setw(6) << std::setprecision(2) << voltage;
std::string v = oss.str();
std::string _outbuffer = "VL" + v;
Serial.println(v.c_str());
Serial.println(_outbuffer.c_str());
