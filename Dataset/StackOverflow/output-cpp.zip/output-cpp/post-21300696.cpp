char v[15 + 1];
v[15] = 0;
dtostrf(voltage, 6, 2, v);
strcpy(_outbuffer, "VL");
strcat(_outbuffer, v);
