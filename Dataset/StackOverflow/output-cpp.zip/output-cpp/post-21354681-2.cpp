class RGBMixer {
    uint8_t _red, _green, _blue;
    public:
        RGBMixer();
        void begin(uint8_t r_pin, uint8_t g_pin, uint8_t b_pin) {
            _red = r;
            _green = g;
            _blue = b;
            pinMode(r, OUTPUT);
            pinMode(g, OUTPUT);
            pinMode(b, OUTPUT);
        }        
        void mix(uint8_t r, uint8_t g, uint8_t b) {
            analogWrite(_red, r);
            analogWrite(_green, g);
            analogWrite(_blue, b);
        }      
} rgb_mixer;

void setup() {
    rgb_mixer.begin(10, 11, 12);
}

void loop() {
    rgb_mixer.mix(128, 128, 128);
}
