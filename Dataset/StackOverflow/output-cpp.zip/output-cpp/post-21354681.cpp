#define LED_RED_PIN 12
#define LED_GREEN_PIN 11
#define LED_BLUE_PIN 10

void setup_leds() {
    pinMode(LED_RED_PIN, OUTPUT);
    pinMode(LED_GREEN_PIN, OUTPUT);
    pinMode(LED_BLUE_PIN, OUTPUT)
}

void rgb_mixer(uint8_t r, uint8_t g, uint8_t b) {
    analogWrite(LED_RED_PIN, redvalue);
    analogWrite(LED_GREEN_PIN, greenvalue);
    analogWrite(LED_BLUE_PIN, bluevalue);
}

void setup() {
    setup_leds();
}

void loop() {
    rgb_mixer(128, 128, 128);
}
