char STX = '\02'

if (inputString.charAt(0) == STX) {
  doSomething();
}
