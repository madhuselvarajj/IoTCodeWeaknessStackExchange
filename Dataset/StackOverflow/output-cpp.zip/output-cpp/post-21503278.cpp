String finaldata = "";
void loop()
{

    while (Serial.available()) {
        char recv = Serial.read();
        if (recv != 0x00) finaldata += recv;
        if(finaldata.indexOf('}') > 1){
            int firstBracket = finaldata.indexOf('{');
            int secondBracket = finaldata.indexOf('}');
            finaldata = finaldata.substring(firstBracket, secondBracket);
            Serial.print(finaldata);
            break;
        }
        delay (10);
    }
}
