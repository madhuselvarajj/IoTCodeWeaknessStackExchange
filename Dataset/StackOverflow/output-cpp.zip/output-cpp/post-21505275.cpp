//============================================================================
// Name        : gcc-proxy.cpp
// Copyright   : Use as you want
// Description : Based on http://stackoverflow.com/questions/5846934/how-to-pass-a-vector-to-execvp
//============================================================================

#include <unistd.h>

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main(int argc, char *argv[]) {
    vector<string> arguments;
    vector<const char*> aptrs;

    // Additional options, one per line
    ifstream cfg((string(argv[0]) + ".ini").c_str());
    if (cfg.bad())
        cerr << "Could not open ini file (you're using proxy for some reason, er?)" << endl;

    string arg;
    while (cfg) {
        getline(cfg, arg);
        if(arg == "\r" || arg == "\n")
            continue;
        arguments.push_back(arg);
    }

    for (const string& arg : arguments)
        aptrs.push_back(arg.c_str());

    for (int i = 1; i < argc; ++i)
        aptrs.push_back(argv[i]);

    // Add null pointer at the end, execvp expects NULL as last element
    aptrs.push_back(nullptr);

    // Pass the vector's internal array to execvp
    const char **command = &aptrs[0];

    return execvp(command[0], command);
}
