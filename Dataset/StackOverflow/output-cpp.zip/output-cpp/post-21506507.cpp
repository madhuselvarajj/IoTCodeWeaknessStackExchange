class output_control{

public:
  void  output_on(){
    digitalWrite(_pin,HIGH);  //Just an example 
  }
  void  setPin(int p){
    _pin = p;
  }

  private:
   int _pin;
};


output_control device[10]; // declare the array of objects

void setup(){
  //init the variables
  device[0].setPin(6);
  device[1].setPin(7);
}

void loop(){
 // do some stuff


}
