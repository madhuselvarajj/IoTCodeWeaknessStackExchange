void loop() {
   const int BufferMaxChars = 100-1;
   static int i = 0;
   static int count = 0;
   static char tmp[BufferMaxChars];

   if (wifly.avaible()) {
      char c = wifly.read();
      Serial.print(c);
      tmp[i] = c;
      i++;
      if (c == '"')
         count++;
      if (i >= BufferMaxChars || count == 2)
      {
         Serial.print("Received : ");
         Serial.println(tmp);
      }
   }
}
