void loop(){
  ...

 //total= total - readings[index];
 //you don't need the array here anymore
 //readings[index] = analogRead(EchoPin);
 //total = total + readings[index];
 total = total + analogRead(EchoPin);
 index = index + 1;

 if (index >= numReadings)
 {
   index = 0;

   average = total / numReadings;

   Serial.print("Dist_avg = ");
   Serial.print(average);
   Serial.println("mm");
   delay(100);

   if (average > 400)
     digitalWrite(LedPin, HIGH);   // turn the LED on (HIGH is the voltage level)
   else
     digitalWrite(LedPin, LOW);    // turn the LED off by making the voltage LOW

   total = 0;
 }
