static int redpin[4];
...

int rgbInitiate(int ledID, int redpin, int greenpin, int bluepin) {   
   redpin[ledID] = redpin;
   ...
}

void rgbMixer(int ledID, int redvalue, int greenvalue, int bluevalue) {   
  analogWrite(redpin[ledID], redvalue);
  ...
}
