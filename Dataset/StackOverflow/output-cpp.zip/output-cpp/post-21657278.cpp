// somefile.cpp
static int redpin;
static int greenpin;
static int bluepin;

int rgbInitiate(int redpin, int greenpin, int bluepin) {   
  redpin = redpin;
  greenpin = greenpin;
  bluepin = bluepin;
  ...
}

void rgbMixer(int redvalue, int greenvalue, int bluevalue) {   
  analogWrite(redpin, redvalue);
  analogWrite(greenpin, greenvalue);
  analogWrite(bluepin, bluevalue);
}
