char Comp(char* This) {

while(Serial.available()) {
  inChar = Serial.read();
  inData.concat(inChar);
 }

  strcpy(inData2, inData.c_str());
   token = strtok(inData2, s);
        strcpy(x1,token);

            token = strtok(NULL, s);
          strcpy(x2,token);

              token = strtok(NULL, s);
              strcpy(x3,token);

if (strcmp(x1,This)  == 0) {

Serial.println(x1);
Serial.println(x2);
Serial.println(x3);

   inData = "";
   inChar = '\0';
    return(0);
}
else {
return(1);
}

}
