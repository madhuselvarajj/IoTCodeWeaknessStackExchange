  unsigned int hex_num;
  hex_num =  uidByte[0] << 24;
  hex_num += uidByte[1] << 16;
  hex_num += uidByte[2] <<  8;
  hex_num += uidByte[3];
