bool addItem(Item* obj) {
    if (writeIndex >= SUB_LENGTH)
        return false;
    items[writeIndex] = *obj;
    writeIndex++;
    return true;
}
