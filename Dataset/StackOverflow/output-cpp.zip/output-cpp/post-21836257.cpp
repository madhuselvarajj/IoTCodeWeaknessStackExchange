Item i1, i2, i3, i4;
i1.set(4);
i2.set(5);
i3.set(6);
i4.set(7);

// Sub()
Item * items;
int writeIndex;
writeIndex = 0;
// s.addItem(&i1)
items[writeIndex] = &i1;
writeIndex++;
// s.addItem(&i2)
items[writeIndex] = &i2;
writeIndex++;
// s.addItem(&i3)
items[writeIndex] = &i3;
writeIndex++;
// s.addItem(&i4)
items[writeIndex] = &i4;
writeIndex++;
