#include <iostream>
using namespace std;

int main() 
{
   int x = -1;
   int y = 1;
   int z = 2;

   // x += z corresponds to a
   // y corresponds to b

   if ( x += z && y ) std::cout << "( x += z && y ) is equal to true" << std::endl;
   else std::cout << "( x += z && y ) is equal to false" << std::endl;

   x = -1;

   if ( ( x += z  ) && ( y ) ) std::cout << "( ( x += z  ) && ( y ) ) is equal to true" << std::endl;
   else std::cout << "( ( x += z  ) && ( y ) ) is equal to false" << std::endl;

   return 0;
}
