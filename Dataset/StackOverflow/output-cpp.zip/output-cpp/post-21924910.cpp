void Metro::reset() {
  unsigned long previous_millis;
  previous_millis = millis(); // will assign to local variable
  this->previous_millis = millis(); // will assign to class member
}
