char *tmp;
int i = 0;
tmp = strtok(readString, ",");
while (tmp) {
   ArrayKey[i++] = atoi(tmp);
   tmp = strtok(NULL, ",");
}
