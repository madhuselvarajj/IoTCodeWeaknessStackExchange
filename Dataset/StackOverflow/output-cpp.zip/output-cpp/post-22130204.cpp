#include <Time.h> 
void Device::checkTimedEvent() {
    if(::hour() == hour[timedIndex]) {
    // ^^ fully qualified name using scope operator 
        Serial.println("TIME!!!!!: ");
    }
}
