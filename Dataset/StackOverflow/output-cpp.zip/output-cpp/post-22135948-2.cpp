Test t;
int someNumber;

void setup()
{
    someNumber = 27;
    t.doSomething(someNumber);
}
