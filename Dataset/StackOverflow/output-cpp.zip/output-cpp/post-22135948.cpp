class Test
{
public:
    void doSomething(int v);

private:
    int myValue;
};

void Test::doSomething(int v)
{
     myValue = v;
}
