class Test
{
public:
    void SetMyValue(int v);
    int  GetPublicValue();
    int  GetPrivateValue();
    int  myPublicValue;

private:
    int myPrivateValue;
};

void Test::SetMyValue(int v)
{
     myPublicValue = v;
     myPrivateValue = v;
}

int  Test::GetPublicValue()
{
     return myPublicValue;
}

int  Test::GetPrivateValue()
{
     return myPrivateValue;
}

Test t;
int someNumber;

void setup()
{
    someNumber = 27;
    t.SetMyValue(someNumber);         // set both private and public via Setter Function
    t.myPublicValue = someNumber;     // set public attribute directly.
    someNumber = t.GetPublicValue();  // read via Getter
    someNumber = t.GetPrivateValue();
    someNumber = t.myPublicValue;     // read attribute directly

}

void loop() {
  // put your main code here, to run repeatedly:
}
