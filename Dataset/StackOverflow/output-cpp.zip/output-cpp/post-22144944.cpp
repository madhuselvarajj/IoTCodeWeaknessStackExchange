const char *myStrings[26] = {"password", "123456", "12345678",
    "1234", "qwerty","12345","password", "dragon", "pussy",
    "baseball", "football","monkey", "letmein", "696969",
    "abc123", "mustang","michael", "shadow", "master",
    "jennifer", "harley","1234567", "jordan",
    "2000", "111111",
    "COMMON PASSWORDS EXHAUSTED: ATTEMPTING BRUTE FORCE"};
