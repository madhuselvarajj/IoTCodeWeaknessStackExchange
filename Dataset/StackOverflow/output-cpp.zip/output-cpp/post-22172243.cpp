   main()
    {
    do
     {
      function();
      printf("welcome to mAIN");
     }
     while(button!=NONE);
    }
