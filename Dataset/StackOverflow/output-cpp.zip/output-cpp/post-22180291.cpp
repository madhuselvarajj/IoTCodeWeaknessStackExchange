if(Day==0)
    wsk = &Pon;
if(Day==1)
    wsk = &Wt;
if(Day==3)
if(Day==4)
if(Day==5)
if(Day==6)
