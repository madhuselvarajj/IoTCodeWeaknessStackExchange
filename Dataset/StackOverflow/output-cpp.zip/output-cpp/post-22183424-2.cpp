switch(Day)
{
    case 0: { wsk = &Pon; break; }
    case 1: { wsk = &Wt; break; }
    case 3: { wsk = &Sr; break; }
    case 4: { wsk = &Czw; break; }
    case 5: { wsk = &Pia; break; }
    case 6: { wsk = &So; break; }
    default: break;
}
