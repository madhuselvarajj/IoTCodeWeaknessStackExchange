if(Day==0)
    wsk = &Pon;
else if(Day==1)
    wsk = &Wt;
else if(Day==3)
    wsk = &Sr;
else if(Day==4)
    wsk = &Czw;
else if(Day==5)
    wsk = &Pia;
else if(Day==6)
    wsk = &So;
