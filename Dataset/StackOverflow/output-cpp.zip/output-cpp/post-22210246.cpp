typedef struct mytype_ {
    int f1;
} mytype_t;

void myfunc(struct mytype_ * xxx) {
    xxx->f1 = 1;
}
