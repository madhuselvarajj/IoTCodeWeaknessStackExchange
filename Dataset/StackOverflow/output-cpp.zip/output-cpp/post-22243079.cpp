void Action_UP()
{   
    if(display_screen_type >=DISPLAY_TYPE_MAX)
        display_screen_type=DATE_TIME
    else
        display_screen_type++; 
}

void Action_DOWN()
{    
    if(display_screen_type <= DATE_TIME)
        display_screen_type=SET_PARAMETER
    else
        display_screen_type--; 
}
