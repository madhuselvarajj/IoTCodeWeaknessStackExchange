string scratchencode(string cmd)
{
    int cmdlength; // holds the length of cmd
    string combind; // used to store the concatenated Packet
    string mgsSize; // used to store Message size

    cmdlength = cmd.length(); // length of CMD

    //convert intiger to a  4 byte 32-bit big-Endian number, using bit shifting.
    mgsSize = (cmdlength >> 24);
    mgsSize += (cmdlength >> 16);
    mgsSize += (cmdlength >> 8);
    mgsSize += cmdlength;

    combind = mgsSize + cmd; // concatenate mgsSize and cmd producing a structure of  [size][size][size][size][string CMD (size bytes long)]
    return combind; // return the string
}
