int PSPin = 13;
int DurationTime = 25; // best to have same type as compare or cast it later, below.

int Counter() {
    int i = 0;
    unsigned long StartTime = millis();
    unsigned long PrvTime = StartTime ;
    while ( PrvTime - StartTime < (unsigned long) DurationTime ) {
        if ( digitalRead(PSPin) == HIGH ) {
            i=i+1;
            while ( digitalRead(PSPin) == HIGH); // BLOCK the function until cycles
        }
        PrvTime = millis();
    }
    return i;
}
