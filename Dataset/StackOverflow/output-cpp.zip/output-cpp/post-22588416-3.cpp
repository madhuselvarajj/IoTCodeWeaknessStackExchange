#include<iostream>
#include<wiringPi.h>
#include<errno.h>
#include<string.h>
#include<stdint.h>       //for uint32_t
using namespace std;
uint32_t time1=0,time2=0;
uint32_t time_diff=0;
float Range_cm=0;
volatile int flag=0;
void show_distance(void);

void myInterrupt(void)
 {
    if(flag==0)
      {
            time1=micros();
            flag=1;

      }
    else
      {
            time2=micros();
            flag=0;
            time_diff=time2-time1;
            Range_cm=time_diff/58;
            show_distance();

       }

  }
void show_distance()
  {
    cout<<"distance= "<<time1<<" "<<time2<<" "<<time_diff<<" "<<Range_cm<<" cm\n";
    cout.flush();
    delay(1000);
    digitalWrite(2,0);
    delayMicroseconds(1);
    digitalWrite(2,1);
    delayMicroseconds(10);
    digitalWrite(2,0);

  }

int main(void)
  {
    if(wiringPiSetup()<0)
     {
       cout<<"wiringPiSetup failed !!\n";
     }
    pinMode(2,OUTPUT);
    pinMode(3,INPUT);
    pullUpDnControl(3,PUD_DOWN);
    if(wiringPiISR(3,INT_EDGE_BOTH,&myInterrupt) < 0)
            {
            cerr<<"interrupt error ["<<strerror (errno)<< "]:"<<errno<<endl;
            return 1;
            }
    digitalWrite(2,0);
    delayMicroseconds(1);
    digitalWrite(2,1);
    delayMicroseconds(10);
    digitalWrite(2,0);

    while(1)
    {
    }
    return 0;
 }
