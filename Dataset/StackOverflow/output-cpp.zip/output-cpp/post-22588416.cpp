pinMode(2,OUTPUT);
pinMode(3,INPUT);
pullUpDnControl(3,PUD_DOWN);
digitalWrite(2,0);
delayMicroseconds(1);
digitalWrite(2,1);
delayMicroseconds(10);
digitalWrite(2,0);
if(wiringPiISR(3,INT_EDGE_BOTH,&myInterrupt) < 0)
  {
    cerr<<"interrupt error ["<<strerror (errno)<< "]:"<<errno<<endl;
    return 1;
   }
