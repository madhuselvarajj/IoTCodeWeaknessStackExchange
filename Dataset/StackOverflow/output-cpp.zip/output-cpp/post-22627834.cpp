strncat(outBuf,...,127);
... request is fully constructed

if(client.connect(ipBuf,thisPort)) {
  client.write(outBuf);
  client.println(" HTTP/1.1");
  client.println("Host: 192.168.1.3");
...
