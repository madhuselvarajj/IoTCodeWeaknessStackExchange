void DataGathering::newData()
{
    QByteArray rMsg;
    for(;;) {
        char buf[256]; // read data in this size chunks
        qint64 len = m_serial->read(buf, sizeof buf);
        if (len <= 0) {
            if (len < 0) {
                qDebug() << "newData() read error" << m_serial->errorString();
            }
            break; // for(;;)
        }
        rMsg.append(buf, len);
    }
    qDebug() << "newData() got byte array" << rMsg.size() << ":" << rMsg;
}
