#include"glob.h"

int c = 20;
extern int a;

void loop()
{
  if(c>a)
  {
    Serial.printf("welcome");
  }
}
