for (int i=0;i<strlen(tag); i++){
    if ( (tag[i] >= 'a' && tag[i] <= 'z') || (tag[i] >= 'A' && tag[i] <= 'Z') || (tag[i] >= '0' && tag[i] <= '9'){
        //this char is OK
    }else{
        return;
    }
}
//if you are here tag is valid
