char c = client.read();
while (client.connected()) {
  while (client.available()) {
   char c = client.read();
  }
}
Serial.println("Closing connection");
client.close();
