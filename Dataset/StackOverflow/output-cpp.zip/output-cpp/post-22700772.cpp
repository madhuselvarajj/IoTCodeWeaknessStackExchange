string buffer;
int counter = 0;
while (client.connected()) {
  while (client.available()) {
   buffer[counter++] = client.read();
  }
}
Serial.println("Closing connection");
Serial.println("Buffer value is: " + buffer);
client.close();
