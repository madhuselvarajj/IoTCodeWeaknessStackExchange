enum Directions {
    Center,
    Left,
    Right,
    Up,
    Down
}

const int threshold = 100;

int getJoyStick() 
{
    // get the X,Y coordinates with 0,0 the centre
    int x = analogRead(xAxis) - 500;
    int y = analogRead(yAxis) - 500;

    /check if we are in the middle.  Both X and Y need to be small for this to happen
    if (abs(x) < threshold && abs(y) < threshold) return Center;

    //to detect up, down, left, right draw diagonals at 45 degrees from the centre
    //if we are more to the right than we are up or down, then it is Right.  This
    //is to cope if it isn't exactly horizonal or vertical
    //so y big might mean up, but if x is bigger, than it is actually to the right
    if (x>y) {
      if (x>-y) return Right; else return Down;
    }
    else {
      if (x>-y) return Up; else return Left;
    }
}
