uint32_t num = 12345;
uint32_t *p1 = &num;

uint8_t *p2 = reinterpret_cast<uint8_t*>(p1);

// Access the individual bytes:
uint8_t byte0 = p2[0];
uint8_t byte1 = p2[1];
uint8_t byte2 = p2[2];
uint8_t byte3 = p2[3];
