char what[] = "\r\n\r\n";
String ris = "";
int eq = 0;
while (client.connected()) {
    while (client.available()) { //we assume all data to be in a single TCP packet.
        buffer = client.read();
        if (eq == 4){
            ris += buffer;
        }else{
            if (buffer == what[eq]){
                eq++;
            }else{
                eq = 0;
            }
        }
    }
    Serial.print("readed: ");
    Serial.println(ris);
    //here send answer
    client.close();
}
