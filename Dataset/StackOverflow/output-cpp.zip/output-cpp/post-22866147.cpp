const int sensorPin = A0;   
void setup()
{
    pinMode(2, INPUT);//the switch

    for (int pinNumber = 3; pinNumber < 7; ++pinNumber)
    {
        pinMode(pinNumber, OUTPUT);//four leds
    }

    pinMode(7, OUTPUT);//green led
    pinMode(8, OUTPUT);//red led
}

void loop()
{
    for (int pinNumber = 3; pinNumber < 7; ++pinNumber)
    {        
        if (digitalRead(2) == LOW)
        {
            //if the switch is off the 4 leds are off
            digitalWrite(pinNumber, LOW);
        }
        else
        {
            //if the switch is open the 4 leds are opened
            digitalWrite(pinNumber, HIGH);
        }
    }

    int sensorVal = analogRead(sensorPin);
    float voltage = (sensorVal / 1024.0);
    float temperature = (voltage - 0.5) * 100;
    if (temperature < 40)
    {
        digitalWrite(7, HIGH);
        digitalWrite(8, LOW);
    }
    else
    {
        digitalWrite(7, LOW);
        digitalWrite(8, HIGH);
    } 
}
