const char* VAL="{\"lightstatus\":"

int parse_value(char c) {
    static int val_idx=0;
    // end of parsing condition, the index reached string length
    if (strlen(VAL) == val_idx) {
        // if the value is '1', return >0, if the value is '0', return 0
        if ('1' == c) return 1;
        else if ('0' == c) return 0;
    }
    // otherwise let's check if we're still in string
    if (c == VAL[val_idx]) {
        // if we do, increment the index variable
        ++val_idx;
    } else {
        // or reset it
        val_idx = 0;
    }
    // return -1 while we're still parsing the string
    return -1;
}
