if ('{' == client.read())
  if ('"' == client.read())
    if ('l' == client.read())
      if ('i' == client.read())
        if ('g' == client.read())
          if ('h' == client.read())
            if ('t' == client.read())
              if ('s' == client.read())
                if ('t' == client.read())
                  if ('a' == client.read())
                    if ('t' == client.read())
                      if ('u' == client.read())
                        if ('s' == client.read())
                          if ('"' == client.read())
                            if (':' == client.read()) {
                               char c = client.read();
                               if (c == '1')
                                 // TURN LIGHT ON
                               else if (c == '0')
                                 // TURN LIGHT OFF
                            }
