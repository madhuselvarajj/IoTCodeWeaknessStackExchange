Private _input As Integer = 0

Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
    'set the bit of the required input
    Select Case e.KeyCode
        Case Keys.Right
            _input = SetBit(_input, 0) '0001
        Case Keys.Left
            _input = SetBit(_input, 1) '0010
        Case Keys.Up
            _input = SetBit(_input, 2) '0100
        Case Keys.Down
            _input = SetBit(_input, 3) '1000
    End Select
    SerialPort1.Write(Convert.ToChar(_input))
End Sub

Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
    'clear the bit of the de-selected input
    Select Case e.KeyCode
        Case Keys.Right
            _input = ClearBit(_input, 0)
        Case Keys.Left
            _input = ClearBit(_input, 1)
        Case Keys.Up
            _input = ClearBit(_input, 2)
        Case Keys.Down
            _input = ClearBit(_input, 3)
    End Select
    SerialPort1.Write(Convert.ToChar(_input))
End Sub

Private Function SetBit(value As Integer, bit As Integer) As Integer
    ' Create a bitmask with the 2 to the nth power bit set:
    Dim mask As Integer = CInt(2 ^ bit)
    ' Set the nth Bit:
    value = value Or mask
    Return value
End Function

Private Function ClearBit(value As Integer, bit As Integer) As Integer
    ' Create a bitmask with the 2 to the nth power bit set:
    Dim mask As Integer = CInt(2 ^ bit)
    ' Clear the nth Bit:
    value = value And Not mask
    Return value
End Function
