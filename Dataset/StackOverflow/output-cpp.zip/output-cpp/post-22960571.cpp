<FlagsAttribute()> _
Enum ctrl As Byte
    stp = 0 'stop is no bits set
    frwd = 1 << 0 '1
    back = 1 << 1 '2
    left = 1 << 2 '4
    rght = 1 << 3 '8
    mask = 255
End Enum

Private _control(0) As ctrl

Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
    Select Case e.KeyCode
        Case Keys.Right
            _control(0) = _control(0) Or ctrl.rght
        Case Keys.Left
            _control(0) = _control(0) Or ctrl.left
        Case Keys.Up
            _control(0) = _control(0) Or ctrl.frwd
        Case Keys.Down
            _control(0) = _control(0) Or ctrl.back
    End Select
    'SerialPort1.Write(_control, 0, 1)
    Debug.WriteLine(_control(0))
End Sub

Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
    Select Case e.KeyCode
        Case Keys.Right
            _control(0) = _control(0) And (ctrl.mask Xor ctrl.rght)
        Case Keys.Left
            _control(0) = _control(0) And (ctrl.mask Xor ctrl.left)
        Case Keys.Up
            _control(0) = _control(0) And (ctrl.mask Xor ctrl.frwd)
        Case Keys.Down
            _control(0) = _control(0) And (ctrl.mask Xor ctrl.back)
    End Select
    'SerialPort1.Write(_control, 0, 1)
    Debug.WriteLine(_control(0))
End Sub
