int Serialbaud=19200;
int byteCount;
uint8_t message[] = {0x06, 0x01, 0x08, 0x01, 0xF0, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01};

// Test the transmission of our message (uint8_t array)
void testFunc(uint8_t *MSG, int len) {

  //uint32_t len= sizeof(MSG)/sizeof(uint8_t);

  Serial.println();
  Serial.println("After passing to function the message is " + String(len) + " bytes:");
  for(int i=0; i<len; i++) {
    Serial.print(MSG[i]);
    Serial.print(", ");
  }
  Serial.println();

}//end function

//--------SETUP------------------
void setup()
{
 delay(3000);//Give yourself time to open up the serial monitor 
 Serial.begin(Serialbaud);  //Begin serial ommunication with Serial Monitor

 //Report the original length and content of the message to the serial monitor
 uint32_t len= sizeof(message)/sizeof(uint8_t); 
 Serial.println("Original message before passing to function is " + String(len) + " bytes:");
 for(int i=0; i<len; i++) {
    Serial.print(message[i]);
    Serial.print(", ");
  }
  Serial.println();

 //Pass the message to the test function
 testFunc(message, sizeof(message)/sizeof(uint8_t));

}

//--------MAIN LOOP-------MAIN LOOP-------MAIN LOOP-------MAIN LOOP-------MAIN LOOP-------MAIN LOOP--
void loop()
{

}//END LOOP-------------------
