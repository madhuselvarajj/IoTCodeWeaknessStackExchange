unsigned long red = 0xffUL;
unsigned long green = 0xffUL;
unsigned long blue = 0xffUL;
unsigned long color = (red << 16)
                    | (green << 8)
                    | (blue << 0);
