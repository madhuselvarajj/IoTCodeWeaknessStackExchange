int *readPot() ///read potentiometer value
{
   int tempValue = analogRead(A0);
   int *potValue = &tempValue;
   return potValue;
}
