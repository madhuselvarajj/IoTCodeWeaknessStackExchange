int array_items = sizeof(ns) / sizeof(*ns); // this will gives you the amount of items stored in your array
int i;
int j;
for (i = 0; i < array_items; ++i) {
   size_t strSize = strlen(ns[i]); // strSize now contains, if ns[i] contained the example of apple, 5
    for (j = 0; j < strSize; ++j) {
        printf("%c", ns[i][j]);
    }
  printf("\n");
}
