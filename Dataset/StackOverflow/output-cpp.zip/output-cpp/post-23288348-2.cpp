class Animation
{
public:
    Animation() : currentFrame(0)
    {
        for (int i = 0; i != 8; ++i) {
            for (int j = 0; j != 4; ++j) {
                frames[i][j] = 0xFFFF;
            }
        }
    }

    uint16_t frames[8][4];
    uint8_t currentFrame;
};
