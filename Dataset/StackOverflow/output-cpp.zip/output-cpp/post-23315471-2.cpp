#include <stdio.h>

typedef char byte;

int main(void)
{
    byte circle0[7] = { 0, 1, 40, 44, 43, 42, 41 };
    byte circle1[7] = { 1, 2, 39, 45, 44, 41, 40 };
    byte circle2[7] = { 2, 3, 38, 46, 45, 40, 39 };
    byte circle3[7] = { 3, 4, 37, 47, 46, 39, 38 };
    byte circle4[7] = { 4, 5, 36, 48, 47, 38, 37 };

    byte (*circleArray[])[7] = { &circle0, &circle1, &circle2, &circle3, &circle4};

    size_t circleArrayLength = sizeof(circleArray)/sizeof(circleArray[0]);

    for (size_t i = 0; i < circleArrayLength; i++) {
        for (size_t c = 0; c < 7; c++) {
            printf("circleArray[%zu][%zu] = %d\n", i, c, (*circleArray[i])[c]);
        }
    }
}
