Class Base {
public:
  boolean receiveByte();  // the accessors are public
protected:
  uint8_t buffer[ 20 ];  // the data is encapsulated
  uint8_t bufferLength;
}

boolean MyClass::receiveByte() {
  if( Serial.available() > 0 )  {
    bufferLength++;
    // you would insert protection against overflow here
    buffer[bufferLength] = Serial.read();
    return( true );
  }
  return( false );
}

Class MyClass : public Base {
public:
  void execute( void );
}

void MyClass::execute( void )  {
  if( receiveByte() == true ) {
    // Do something
  }
}
