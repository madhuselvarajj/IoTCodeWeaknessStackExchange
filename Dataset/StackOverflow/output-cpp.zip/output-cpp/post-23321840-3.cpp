if( control_task_delay.time() >= _speedVar )
{
    // Some function

    control_task_delay.zero()      // Restart delay
}
