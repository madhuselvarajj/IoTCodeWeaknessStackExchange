if( Serial.available() )
{
    _speedVar = Serial.read();
}

if( control_task_delay.time() >= _speedVar )
{
    switch( state )
    {
        case STATE_A :
            // Some function

            control_task_delay.zero()      // Restart delay
            state = STATE_B ;              // Next state
        break ;

        case STATE_B :
            // Some function

            control_task_delay.zero()      // Restart delay
            state = STATE_A ;              // Next state
        break ;
    }
}
