class cElapsedTime
{
    cElapsedTime()
    {
       zero() ; 
    }

    void zero()
    {
        timestamp = millis() ;
    }

    bool time()
    {
        return millis() - m_timestamp ;
    }
} ;

enum
{
    STATE_A,
    STATE_B
}  state = STATE_A;

cElapsedTime control_task_delay ;
