// Dancer.h
class Dancer {
  public:
    Joint* joint;
    void setJoint(Joint& newJoint);
    void animate();
}

// Dancer.cpp
Dancer::setJoint(Joint& newJoint) {
  joint = &newJoint;
}
Dancer::animate() {
  joint->moveTo(random(90));
}

// MainArduinoSketch.ino
Joint frontLeftJoint;
void setup() {
  dancer.setJoint(frontLeftJoint);
}
