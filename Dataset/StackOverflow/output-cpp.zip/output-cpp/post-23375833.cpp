valuesStruct test;
test.valA = 0;
test.valB = 0;
test.valC = 0;

//Section 2: not working
exampleLibObj.processPacket(test);

//Section 3: working
exampleLibObj.processPacket(&test);
