   SHA256_CTX ctx;
   u_int8_t results[SHA256_DIGEST_LENGTH];
   char *buf;
   int n;

   buf = "abc";
   n = strlen(buf);
   SHA256_Init(&ctx);
   SHA256_Update(&ctx, (u_int8_t *)buf, n);
   SHA256_Final(results, &ctx);

   /* Print the digest as one long hex value */
   printf("0x");
   for (n = 0; n < SHA256_DIGEST_LENGTH; n++)
           printf("%02x", results[n]);
   putchar('\n'); 
