union {
    char c[sizeof(float)];
    float f;
} pun;

pun.f = 3.14;
send_bytes(pun.c, sizeof float); // another hypotetical function
