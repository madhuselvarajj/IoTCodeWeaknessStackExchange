bool serial_is_configured() {
    return (_BV(TXEN0) & UCSRB == _BV(TXEN0));
} 
bool serial1_is_configured() {
    return (_BV(TXEN1) & UCSRB == _BV(TXEN1));
} 
// ...
