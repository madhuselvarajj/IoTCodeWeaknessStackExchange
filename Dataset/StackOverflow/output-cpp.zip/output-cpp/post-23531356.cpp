HardwareSerial *possible_ports[] = {
#if defined(UBRRH) || defined(UBRR0H)
&Serial,
#endif
#if defined(UBBR1H)
&Serial1, 
#endif
#if defined(UBBR2H)
&Serial2,
#endif
#if defined(UBBR3H)
&Serial3
#endif
};
