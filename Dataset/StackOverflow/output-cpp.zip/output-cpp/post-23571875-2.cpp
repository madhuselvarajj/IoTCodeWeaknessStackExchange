char c;
String cmd = "";

void loop(){
    while (Serial.available()) {
        c = Serial.read();
        Serial.println(c);
        cmd.concat(c);
    }
}
