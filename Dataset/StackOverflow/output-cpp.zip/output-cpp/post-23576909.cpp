void parse_hex(char* a, char* b, char* c, const char* string) {
    //certainly not the most elegant way. Note that we start at 1 because of '#'
    a[0] = string[1];
    a[1] = string[2];
    b[0] = string[3];
    b[1] = string[4];
    c[0] = string[5];
    c[1] = string[6];
}
