string hexstring = "#FF3Fa0";

// Get rid of '#' and convert it to integer
long number = strtol( &hexstring[1], NULL, 16);

// Split them up into r, g, b values
long r = number >> 16;
long g = number >> 8 & 0xFF;
long b = number & 0xFF;
