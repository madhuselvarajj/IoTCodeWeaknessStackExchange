long long number = strtoll( &hexstring[1], NULL, 16);

// Split them up into r, g, b values
long long r = number >> 16;
long long g = number >> 8 & 0xFF;
long long b = number & 0xFF;
