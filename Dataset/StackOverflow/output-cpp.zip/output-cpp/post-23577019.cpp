string hexstring = "#FF3Fa0";

// Get rid of '#' and convert it to integer
int number = (int) strtol( &hexstring[1], NULL, 16);

// Split them up into r, g, b values
int r = number >> 16;
int g = number >> 8 & 0xFF;
int b = number & 0xFF;
