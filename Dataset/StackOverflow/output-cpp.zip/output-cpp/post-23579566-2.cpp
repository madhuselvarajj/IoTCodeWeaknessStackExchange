int main( int argc, char** argv )
{
open_port();
    int wr;


    char* msg ="Ciao Mondo!";

    /* Write to the port */
    send_string(fd, msg);

    // or use lenght parameter
    write(fd, msg, strlen(msg));

    close(fd);
  }
