void send_string(int fd, char* s)
{
    while( *s++ )
        write(fd, *s, 1);
}
