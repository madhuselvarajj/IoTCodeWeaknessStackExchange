Boolean once; // declare this with your other int variables 
if(lightLevel > 800 && lightLevel < 1000 && once==True)
  {
    myservo1.writeMicroseconds(1300);delay(1000);
    myservo1.writeMicroseconds(1500);delay(1000);
    once = False;
  }
 else if(lightLevel<800 && once == False)
  {
    myservo1.writeMicroseconds(1700);delay(5000);
    myservo1.writeMicroseconds(1500);delay(1000);
    once = True;
   }
