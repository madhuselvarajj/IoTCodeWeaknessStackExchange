void myfprintf_(int fd,int nargs, ...){ 
   va_list ap; va_start(ap, nargs); static char *s; const char *fmt; 
   fmt=va_arg(ap, char *); 
   int i=0,p; 
   char buf[80]; 
while (fmt[i]){ 
   p=0; 
   while (fmt[i]!='%' && fmt[i]!=0) buf[p++]=fmt[i++]; 
   if (p != 0) write(fd,buf,p); 
   if (nargs-->0){ 
      switch (fmt[++i]) { 
      case 's': s=va_arg(ap, char *); break; 
      case 'd': s=dtos(va_arg(ap, int)); break; 
      case 'x': s=dtox(va_arg(ap, int),'a'); break; 
      case 'X': s=dtox(va_arg(ap, int),'A' ); break; 
      case 'f': s=ftos(va_arg(ap, double)); break; 
      case 'c': buf[0]=(va_arg(ap, int));buf[1]=0;s=buf;break; 
      case '%': s="%"; break; 
      default : s="";break; 
      } write(fd,s,strlen(s)); 
   } 
i++; 
} 
va_end(ap); 
}
