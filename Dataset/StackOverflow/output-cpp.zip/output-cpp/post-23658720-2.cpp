class Wheel::Stepper
{
public:
    void accelerate() {}
};

Wheel::Wheel()
    : _pStepper( new Stepper() )
{
    stepper().accelerate();
}
