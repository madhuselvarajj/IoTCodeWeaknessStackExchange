class Wheel
{
public:
    class Stepper; // Forward declaration of embedded class

    Wheel();
    Stepper& stepper() { return *_pStepper; }

private:

    Stepper* _pStepper;
};
