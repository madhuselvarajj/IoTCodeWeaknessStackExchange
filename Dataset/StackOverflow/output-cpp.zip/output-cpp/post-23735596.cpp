int motor_forward = 10;
int motor_reverse = 9;
int motor2_forward = 13;
int motor2_reverse = 12;
int edgeDec1 = 7;
//int edgeDec2 = 6;
int indicator; // pulled this out of your loop - askchipbug

String repeatstring; //debugging variable, stops a debug string from repeating in Serial monitor when watching a loop - askchipbug

//the setup routine runs once when you press reset;
void setup(){
  Serial.begin(9600);           // set up Serial library at 9600 bps, using SerialMonitor to debug - askchipbug
  //initialize the digital pin as an output.
  pinMode(motor_forward, OUTPUT);
  pinMode(motor_reverse,OUTPUT);
  pinMode(motor2_forward,OUTPUT);
  pinMode(motor2_reverse,OUTPUT);
  pinMode(edgeDec1,INPUT_PULLUP); // set this high so it doesn't float about - askchipbug
  // you can use the internal 20k pullups with INPUT_PULLUP which means 1 = off, 0 = on
  // or you have to use external pulldown resistors to have 1 = on, 0 = off
  pr("setup completed"); // askchipbug

}
//the loop routine runs over and over again forever
void loop(){
  randomSeed(analogRead(0)); // seeds the random() function with a different number each time the loop runs - askchipbug
  indicator = random(2);  
  pr("indicator: " + String(indicator)); // askchipbug
  pr("5 second delay");
  delay(5000);//5 second delay
  //loop to prevent another 5 second delay
  while(true){
    if (indicator == 0){ //you had this set as indicator = 0 - askchipbug
      pr("indicator: " + String(indicator)); // askchipbug
      for(int x = 0; x < random(200); x++){
        Forward();
        EdgeDec();
        delay(10);
      }
    }
    else if ( indicator = 1){
      pr("indicator: " + String(indicator)); //askchipbug
      for(int x = 0; x < random(200); x++){
        TurnLeft();
        EdgeDec();
        delay(10);
      }
    }
    else if ( indicator = 2){
      pr("indicator: " + String(indicator));// askchipbug
      for(int x = 0; x < random(200); x++){
        TurnRight();
        EdgeDec();
        delay(10);
      }
    }
  }

}
void Forward(){
   //right motor
  pr("forward"); //askchipbug
  digitalWrite(motor_forward,1);//terminal d1 will be high
  digitalWrite(motor_reverse,0);//terminal d2 will be low

  //left motor
  digitalWrite(motor2_forward,1);//terminal d1 will be high
  digitalWrite(motor2_reverse,0);//terminal d2 will be low
}
//going in reverse
void Reverse(){
  pr("reverse"); //askchipbug
  //right motor
  digitalWrite(motor_forward,0);//terminal d1 will be low
  digitalWrite(motor_reverse,1);//terminal d2 will be high

  //left motor
  digitalWrite(motor2_forward,0);//terminal d1 will be low
  digitalWrite(motor2_reverse,1);//terminal d2 will be high
}
//rotating left
void TurnLeft(){
  pr("turn left"); //askchipbug
  //right motor
  digitalWrite(motor_forward,0);//terminal d1 will be high
  digitalWrite(motor_reverse,1);//terminal d2 will be low

  //left motor
  digitalWrite(motor2_forward,1);//terminal d1 will be high
  digitalWrite(motor2_reverse,0);//terminal d2 will be low
}
void TurnRight(){
  pr("turn right"); //askchipbug
  //right motor
  digitalWrite(motor_forward,1);//terminal d1 will be high
  digitalWrite(motor_reverse,0);//terminal d2 will be low

  //left motor
  digitalWrite(motor2_forward,0);//terminal d1 will be high
  digitalWrite(motor2_reverse,1);//terminal d2 will be low
}
void EdgeDec(){
  pr("edge detector: " + String(digitalRead(edgeDec1))); // read pin 7 - askchipbug
  if(digitalRead(edgeDec1) == LOW){ // remember we're using the internal pullups so LOW = on - askchipbug
    pr("edge detected!"); // askchipbug
    Reverse();
    delay(700);
    TurnLeft();
    delay(1000);
    Forward();
  }
}

//simple debug technique - use pr("something"); in your code - askchipbug
void pr(String txt){
  if(repeatstring != txt){
    //if the debug text is different, print it
    Serial.println(txt); //prints the text and adds a newline
    Serial.flush(); //waits for all the data to be printed
    delay(1000); //just pauses the scrolling text for 1 second, make bigger if you want a longer pause
    repeatstring = txt;
  }
}
