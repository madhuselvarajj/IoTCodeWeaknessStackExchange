int buttonArray[3] = {7,15,3}; //Or on whatever pins your buttons are

// Setup code and anything else you need goes here

void loop() {
    for(int x = 0; x <= 3; x++) {
         int buttonState = digitalRead(buttonArray[x]);
         digitalWrite(ledPin,buttonState);
    }
}
