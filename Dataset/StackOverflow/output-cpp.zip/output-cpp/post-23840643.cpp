/* First open the command for reading. */
FILE * file = popen("/bin/ls /etc/", "r");

char output[100];
/* Read the output line by line */
while (fgets(output, 100, file) != NULL) 
{
    printf("%s", output); /* show the result */
}

/* close */
pclose(file);
