QProcess avrDudeProcess;
avrDudeProcess.setProcessChannelMode(QProcess::MergedChannels);
avrDudeProcess.start("avrdude", optionList);
if (!avrDudeProcess.waitForStarted())
    return false;

if (!avrDudeProcess.waitForFinished())
    return false;

QByteArray output = avrDudeProcess.readAll();
myLabel.setText(output);
