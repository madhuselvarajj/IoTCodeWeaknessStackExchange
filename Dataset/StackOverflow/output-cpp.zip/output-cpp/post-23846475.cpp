const int myButton1 = 7;
const int myButton2 = 15;
const int myButton3 = 3;
const int myButton4 = 27;
const int myButton5 = 22;
const int myButton6 = 18;
const int myButton7 = 23;
const int myButton8 = 11;

const int myOutput1 = 8;
const int myOutput2 = 16;
const int myOutput3 = 4;
const int myOutput4 = 28;
const int myOutput5 = 24;
const int myOutput6 = 19;
const int myOutput7 = 25;
const int myOutput8 = 12;
