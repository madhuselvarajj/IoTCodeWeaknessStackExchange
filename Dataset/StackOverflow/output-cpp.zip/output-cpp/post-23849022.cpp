char s[1] = {'2'};

cout << s << endl;
cout << (int)s << endl;
cout << atoi(s) << endl;
