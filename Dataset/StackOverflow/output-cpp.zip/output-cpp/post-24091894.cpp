void setup() {
  Serial.begin(9600);
  // Confirm observations from question
  char a = 0x70;
  char b = 0x80;

  long aPrint = Serial.println(a, BIN); // Should print  1110000
  long bPrint = Serial.println(b, BIN); // Should print 10000000

  // Output println results (Ben comment #1)
  Serial.print("aPrint: ");
  Serial.println(aPrint);
  Serial.print("bPrint: ");
  Serial.println(bPrint);

  // Explicit cast from char
  Serial.print("(int)b: ");
  Serial.println((int)b);

  // Via unsigned char
  Serial.print("(unsigned char)b: ");
  Serial.println((unsigned char)b);
  // And print in binary
  Serial.println((unsigned char)b, BIN);
}

void loop() {
}
