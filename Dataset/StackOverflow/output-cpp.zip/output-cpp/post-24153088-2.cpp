String input = "";
String result = "";
while (Serial.available() > 0)
{
  char temp = Serial.read();
  if (temp == '\n')
  {
    result = input;
    input = "";
    break; 
  }
  else
  {
    input += temp; 
  }
}
