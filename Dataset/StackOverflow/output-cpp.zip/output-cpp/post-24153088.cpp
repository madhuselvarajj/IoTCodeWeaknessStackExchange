const int rightCW = 6, leftCW = 11, rightCCW = 5, leftCCW = 10;

void setup()
{
  Serial.begin(9600);
  initMotors();

}

void loop()
{
  delay(10);
  analogWrite(rightCW,255);     
}

void initMotors()
{
  //initialize motors
  pinMode(rightCW, OUTPUT);
  pinMode(leftCW, OUTPUT);
  pinMode(rightCCW, OUTPUT);
  pinMode(leftCCW, OUTPUT);
}
