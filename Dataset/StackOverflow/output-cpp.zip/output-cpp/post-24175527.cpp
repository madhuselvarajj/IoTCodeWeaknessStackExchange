#include <cstring>

if (std::strcmp(inData, "1") == 0) {
}
else if (std::strcmp(inData, "2") == 0) {
}
//...
else if (std::strcmp(inData, "10") == 0) {
}
