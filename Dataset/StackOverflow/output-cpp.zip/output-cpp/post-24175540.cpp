switch(inData[0]) {
  case '1':
    switch(inData[1]) {
       case 0:
         // This would be '1'
         break;
       case '0':
         // This will be 10
         break;
    }
    break;
  case '2':
     break;
}
