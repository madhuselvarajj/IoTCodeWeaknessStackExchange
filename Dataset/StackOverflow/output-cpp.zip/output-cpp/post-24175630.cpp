std::string inData; // Allocate some space for the string

// Replace this:
// inData[index] = c;
// index++;
// inData[index] = '\0';   

// with
inData += c;

if (inData == "10") {   // Test for a specific string.
