int Serial::waitForResponse()
{
    const int buffSize = 1024;
    char bufferChar[buffSize] = {'\0'};
    int counter = 0;
    std::string wholeAnswer = "";

    int noDataTime = 0;

    while(wholeAnswer.find("Done") == std::string::npos) //Done string was found.
    {
        if(noDataTime > 10000)
        {
            std::cout << "timeout" << std::endl;
            return -1;
        }
        counter = read(this->hSerial, bufferChar, buffSize - 1);

        if(counter > 0)
        {
            noDataTime = 0;
            bufferChar[counter] = '\0';
            wholeAnswer += std::string(bufferChar);
        } else
        {
            noDataTime++;
            usleep(1000);
        }
    }
    if(!wholeAnswer.empty())
    {
        return 1;
    } else
    {
        return -1;
    }
