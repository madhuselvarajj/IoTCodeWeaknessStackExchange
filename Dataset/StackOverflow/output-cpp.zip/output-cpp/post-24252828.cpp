class Mutex{
  pthread_mutex_t m; 
public:
  Mutex(){
    pthread_mutex_init(&m,NULL); 
  }
  ~Mutex(){
    pthread_mutex_destroy(&m);  
  }
  void wait() {
    pthread_mutex_lock(&m);
  }
  void signal() {
    pthread_mutex_unlock(&m);
  }
} ;
