#ifndef MyClassName_cpp //the _cpp is just to delineate between the two files  
#define MyClassName_cpp
#include "MyClassName.h"
void MyClassName::get_computer_msg(boolean echo_cmd) { //Receive message from computer
  int index = 0;
  String msg = "";
  String echo_msg = "";
  if(Serial.available()) {
    while(Serial.available()) {
      char cChar = Serial.read();
      msg += cChar;
      echo_msg += cChar;
      index++;
    }
    if(echo_cmd) Serial.println("Computer sent " + echo_msg + "+CRLF");
    first_char = msg.charAt(0);
    computer_msg = msg;
  }
}
#endif
