#ifndef MyClassName_h //If MyClassName_h "Not" DEFined
#define MyClassName_h //Then define MyClassName_h
class MyClassName{
  public:
    void get_computer_msg(boolean echo_cmd = false);
    String computer_msg;
    char first_char;
};
#endif //End if

#include "MyClassName.cpp" //Same as first answer recommends
