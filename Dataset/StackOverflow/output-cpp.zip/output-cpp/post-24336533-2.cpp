ROL <value>:
    # Carry Register = 8th bit of the given value
    # value = value << 1
    # 1st bit of the value = Previous Carry Register)

ROL 0b10000001 # Result = 0b00000010 and Carry = 1
ROL 0b10000001 # Result = 0b00000011 and Carry = 1
ROL 0b00000001 # Result = 0b00000011 and Carry = 0
ROL 0b00000001 # Result = 0b00000010 and Carry = 0
