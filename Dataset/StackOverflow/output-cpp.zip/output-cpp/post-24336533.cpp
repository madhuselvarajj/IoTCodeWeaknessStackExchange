asm ("rol %0" : "=r" (pixelData[16][0]) : "0" (pixelData[16][0]));
asm ("rol %0" : "=r" (pixelData[16][1]) : "0" (pixelData[16][1]));
asm ("rol %0" : "=r" (pixelData[16][2]) : "0" (pixelData[16][2]));
asm ("rol %0" : "=r" (pixelData[16][3]) : "0" (pixelData[16][3]));
asm ("rol %0" : "=r" (pixelData[16][4]) : "0" (pixelData[16][4]));
