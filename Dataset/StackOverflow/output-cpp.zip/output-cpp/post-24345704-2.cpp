/*
 Node.h
*/
#ifndef Node_h
#define Node_h

#include <vector>
class Node
{
  public:
      Node();
      ~Node();
      std::vector<int> test;
};

#endif
