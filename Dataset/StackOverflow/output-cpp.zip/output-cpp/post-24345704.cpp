/*
 Main.ino (or whatever your main sketch file is called)
*/

#include <StandardCplusplus.h>
#include "Node.h"

// ...

void setup()
{
}

void loop()
{
}
