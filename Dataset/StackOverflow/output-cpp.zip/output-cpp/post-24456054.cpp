if (serial.isOpen() && serial.isWritable())
            {

                QByteArray ba("R");
                serial.write(ba);
                serial.flush();
                qDebug() << "data has been send" << endl;
                serial.close();
            }
