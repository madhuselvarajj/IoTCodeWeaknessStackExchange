int last_state = -1;   // impossible state so change is noticed the first time
for (;;)  // do forever
{
       int state = get_gpio (THE_EVENT);
       if (state == last_state)
       {
            sleep (100);
            continue;
       }
       do_loader_stuff();
       last_state = state;
}
