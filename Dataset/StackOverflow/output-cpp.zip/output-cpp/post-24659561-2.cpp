void InitializeInputs()
{
    inputs[0] = GeneralInput(0,0,true,false,NULL,10);
    ...
}
