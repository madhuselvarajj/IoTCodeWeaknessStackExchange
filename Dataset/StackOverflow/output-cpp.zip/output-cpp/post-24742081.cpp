void setup()
{
  int index;

  for(index = 0; index <= 9; index++)
  {
    pinMode(ledPins[index],OUTPUT);
    // ledPins[index] is replaced by the value in the array.
    // For example, ledPins[0] is 2
  }
  pinMode(switchPin, INPUT);    // Set the switch pin as input
  buttonState = digitalRead(switchPin);   // read the initial state
  /* RGB */
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  /* RGB */
  for ( int i = 0; i < PIN_COUNT; i++ ) {
    pinMode(ledPins[i], OUTPUT);
    states[i] = 0;
  }
}
