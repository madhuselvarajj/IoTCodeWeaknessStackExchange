void get_command() 
{
    char received;

    if (Serial.available() > 0) {
        delay(100); // let the buffer fill up
        int index = 0;

        while (Serial.available() > 0) {

            if (index < BUFFER_SIZE -1) {
                received = Serial.read();
                if (received != '\n') {
                    buffer[index] = received;
                    index++;
                } else {
                    buffer[index] = '\0';
                    parse_command(buffer);
                }
            } else {
                Serial.println('666'); // buffer overflow
            }
        }
    }
}
