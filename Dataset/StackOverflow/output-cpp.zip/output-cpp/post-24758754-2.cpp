class ADC {
public:
    ADC () { }
    float read () { }
} ;

class LEDs {
public:
    LEDs () { }
    void set (int) { }
} ;
