class MyBoard : public Board <5> { // Let's assume it's connect to 5 bits
public:
    MyBoard (std::array <GPIOPin, N> const& pins) : Board<5>(pins) {
        // Here you can initialize what you want
    }
} ;
