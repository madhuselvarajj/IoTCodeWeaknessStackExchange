class AD7813 : public ADC {
    Board <5> _board ;
public:
    AD7813 (Board <5> *board) : ADC(), _board(board) { }
} ;

// Same for the LED
