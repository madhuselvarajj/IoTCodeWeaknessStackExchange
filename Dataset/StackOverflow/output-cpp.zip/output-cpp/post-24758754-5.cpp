class ADC {
public:
    static ADC *getInstance () {
        if (_instance == nullptr) {
            _instance = new ADC () ;
        }
        return _instance ;
    }
private:
    ADC () ;
};
