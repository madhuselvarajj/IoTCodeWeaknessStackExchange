class GPIOs {
protected:
    GPIOs () {
        if (!GPIOs::_init) {
            /* Do what you want. */
            GPIOs::_init = true ;
        }
    }
private:
    static bool _init ;
} ;

bool GPIOs::_init = false ;
