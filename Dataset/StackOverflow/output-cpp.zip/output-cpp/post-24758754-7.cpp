class ADC : public GPIOs {
public:
    ADC *getInstance () { /* ... */ }
private:
    ADC () : GPIOs () { } // Call constructor
} ;
