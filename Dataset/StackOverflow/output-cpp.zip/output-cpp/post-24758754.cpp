template <int N>
class Board {
protected:
    Board (std::array <GPIOPin, N> const& pins) : _pins(pins) { }
    std::array <GPIOPin, N> _pins ;
};
