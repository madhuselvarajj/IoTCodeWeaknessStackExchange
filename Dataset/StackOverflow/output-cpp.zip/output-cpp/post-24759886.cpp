using ports = uint64_t; // some suitable unsigned bit-maskable type.

// Used to control the IO.
struct DeviceDescriptor {
    ports    in_mask,  // Which pins does this device use for input
             out_mask, // Which pins does this device use for output
             init,     // Initial state of the pins.
             shutdown; // State to send when device should power down.
};

class GPIOPort {
    static const ports ALL_PORTS = ~static_cast<ports>(0);
    std::vector<Device> devices; 
public:
    // Initialize the devices.
    GPIOPort( std::vector<Device> & devices ) : devices(devices) { 
        ports used_ports = 0, init = 0;
        for ( auto & device : devices ) {
              init |= device.init;

              // Assert no overlapping ports
              ports partition = device.init | device.in_mask | device.out_mask | device.shutdown;
              if ( used_ports & partition){
                 // Signal overlapping ports.
              } else {
                 used_bits |= current;
              }
          }
          set_bits(init, ALL_PORTS); // Actually sets the output.
      }

      // Read the input of device number 'dev'
      ports read_state( int dev, ports mask = ALL_PORTS ) {
          return read_bits( devices.at(dev).input_mask & mask );
      }

      // etc...

      ~GPIOPort() {
           ports shutdown;
           for ( auto & device : devices ) {
              shutdown |= device.shutdown;
           }
           set_bits(shutdown, ALL_PORTS);
      }
};
