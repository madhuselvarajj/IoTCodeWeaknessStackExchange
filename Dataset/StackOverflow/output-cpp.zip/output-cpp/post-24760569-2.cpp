int main(void)
{
   auto device = std::make_shared<Device>(DeviceDescriptor());
   LEDBoard led1(device);
   ADCBoard adc1(device);
   //Your stuff...
}
