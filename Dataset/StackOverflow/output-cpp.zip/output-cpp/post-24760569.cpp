struct DeviceDescriptor
{
  int portNumber;
  // add additional variables to identify the device
}

class Device
{
  Device(DeviceDescriptor descriptor)
  {
    //Insert your initialization...
    //You can maintain a static vector of already opened Devices to throw an
    //error if an allready opened device is reopened
  }
  ~Device()
  {
    //Deinit device
  }

  // A device should not be copyable
  Device(const& Device) = delete;
  //TODO do the same for copy assignment
  //TODO implement move ctr and move assignment operator

  //TODO add needed mamber variables
}

class LEDBoard
{
  LEDBoard(std::shared_ptr<Device> device) : m_device(device)
  {
    //Do init stuff
  }

  //Your functions

  private:
  std::shared_ptr<Device> m_device;
}

 //ADCBoard is analog to LEDBoard
