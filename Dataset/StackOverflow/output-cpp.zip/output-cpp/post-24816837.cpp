#include <SPI.h>
#include <Ethernet.h>
#include <Xively.h>

// MAC address for your Ethernet shield
byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };

// Your Xively key to let you upload data
char xivelyKey[] = "[Put your Key here]";

// Define a datastream textual name 
char sensorId[] = "TEMP_001";

// Create as many datastreams you need (one in this case)
XivelyDatastream datastreams[] = {
  XivelyDatastream(sensorId, strlen(sensorId), DATASTREAM_FLOAT),
};

// Finally, wrap the datastreams into a feed
XivelyFeed feed([put your feed number here], datastreams, 1); // Where 1 is the number of datastreams we are wrapping

// Create a Etherent client
EthernetClient client;

// Let Xively know about the Ethernet client
XivelyClient xivelyclient(client);


// Run all the setup you need
void setup(void) {
  Serial.begin(9600);
  while (Ethernet.begin(mac) != 1){
    Serial.println("Error getting IP address via DHCP, trying again...");
    delay(15000);
  }
}


// Loop over
void loop(void) {

  // Read your sensor
  float celsius = [put your sensor reading value here];

  // Copy sensor reading to the apropriate datastream
  datastreams[0].setFloat(celsius);

  // Ask Xively lib to PUT all datastreams values at once
  int ret = xivelyclient.put(feed, xivelyKey);

  // Printout PUT result
  Serial.print("xivelyclient.put returned ");
  Serial.println(ret);

  // Wait 10 sec.
  delay(10000);  
}
