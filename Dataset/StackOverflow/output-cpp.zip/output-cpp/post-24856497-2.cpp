#ifdef DEPLOY
#include "defs_deploy.h"
#else
#ifdef HOME
#include "defs_home.h"
#else
#error Neither DEPLOY nor HOME is defined
#endif /* HOME */
#endif /* DEPLOY */
