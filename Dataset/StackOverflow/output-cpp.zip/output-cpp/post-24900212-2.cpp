char * foo1() {
  static char buf[BUF_SIZE+1];
  int copiedBytes = 0;
  while (copiedBytes<BUF_SIZE && buf[copiedBytes++] = getByteFromSerial());
  buf[copiedBytes] = '\0';
  return buf;   // Note that when you call foo() again, this will be destroyed.
}
