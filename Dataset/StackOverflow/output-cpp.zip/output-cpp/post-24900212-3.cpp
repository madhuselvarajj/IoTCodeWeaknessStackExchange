char * foo2() {
   static char buf[BUF_SIZE+1];
   // do all the stuff from the previous version
   char * retval = malloc(copiedBytes);
   strcpy(retval, buf);
   return retval;
 }
