void someFunction() {
  char buf[BUFF_SIZE+1];
  fillMyBuffer(buf, BUFF_SIZE);
  doSomethingWithMyBuffer(buf);
}
