void foo0(char * buf, int maxBufferSize) {
  while(maxBufferSize && *buf = getByteFromSerial()) { //assumes getByte returns 0 for done
    maxBufferSize--;
  }
}  // If you really feel like it, you can alter this to return the original buf
