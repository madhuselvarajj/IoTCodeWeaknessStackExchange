void setup() {
    pinMode(2, INPUT_PULLUP);
}

void loop() {
  if (digitalRead(2) == LOW)  // NOTE THAT PULLUPS REVERSE YOUR LOGIC
  {
    delay(1000);  //wait 1 second
    digitalWrite(13, HIGH);
    delay(1000);                
    digitalWrite(13, LOW);  
  }
}
