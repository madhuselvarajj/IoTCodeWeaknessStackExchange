 struct timespec ts = {0,0};
 struct tm tm = {};
 char timbuf[64];
 if (clock_gettime(CLOCK_REALTIME, &ts))
    { perror("clock_gettime"), exit(EXIT_FAILURE);};
 time_t tim = ts.tv_sec;
 if (localtime(&tim, &tm))
    { perror("localtime"), exit(EXIT_FAILURE);};
 if (strftime(timbuf, sizeof(timbuf), "%D %T", &tm))
     { perror("strftime"), exit(EXIT_FAILURE);};
 printf("%s.%03d\n", timbuf, (int)(ts.tv_nsec/1000000));
