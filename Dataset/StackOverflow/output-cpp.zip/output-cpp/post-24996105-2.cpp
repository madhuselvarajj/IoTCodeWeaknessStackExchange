#include <stdio.h>

int main(int argc, char *argv[])
{
   unsigned int uValue;
   unsigned int uNibble;

   char sHexByte[3];
   sHexByte[2] = '\0';

   for (uValue = 0; uValue < 256U; uValue++)
   {
      uNibble = (uValue & 0xFFU) >> 4U;
      sHexByte[0] = (uNibble < 10) ? uNibble + '0' : uNibble + ('A' - 10U);
      uNibble = (uValue & 0x0FU);
      sHexByte[1] = (uNibble < 10) ? uNibble + '0' : uNibble + ('A' - 10U);

      if (uValue > 0) putchar(':');
      fputs(sHexByte,stdout);
   }
   putchar('\n');

   /* Dummy code to have no warnings on build. */
   if(argv[0][1] == ' ') return argc;
   return 0;
}
