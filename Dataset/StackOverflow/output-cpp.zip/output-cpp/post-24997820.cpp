int main(void)
{
    char byte[10]={2,23,76,125,43,65,78,37,19,84};
    char string[160];
    int i;
    for(i=0;i<sizeof(byte)/sizeof(*byte);i++)
    {
        printf("0x%02x, ", byte[i]);
    }
    printf("\n");

    //Placing elements into a string:  
    sprintf(string, "Null Terminated String:\n0x%02x, 0x%02x, 0x%02x,0x%02x, 0x%02x,"
                    "0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x\n",
                     byte[0], byte[1], byte[2], byte[3], byte[4],
                     byte[5], byte[6], byte[7], byte[8], byte[9]);
    printf("%s", string);//null terminated string
    getchar();
    return 0;   
}  
