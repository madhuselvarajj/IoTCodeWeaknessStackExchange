String trackName = "track";
track += currentTrack;
if (currentTrack < 9) {
    track += currentTrack;
}
else {
    track += "0";
    track += currentTrack;
}
track += ".mp3";
playMP3(trackName);
