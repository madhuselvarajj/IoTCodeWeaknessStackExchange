unsigned char firstNibble=0U;  // a Nibble is 4 bits, half a byte, one hexadecimal character
char firstHexChar=0;
unsigned char initialByte;  //initialize this to the byte you want to print
unsigned char secondNibble=0U;
char secondHexChar=0;


firstNibble=(initialByte>>4);  // isolate first 4 bits

if(firstNibble<10U)
{
     firstHexChar=(char)('0'+firstNibble);
}
else
{
     firstNibble-=10U;
     firstHexChar=(char)('A'+firstNibble);
}

secondNibble=(initialByte&0x0F);  // isolate last 4 bits

if(secondNibble<10U)
{
     secondHexChar=(char)('0'+secondNibble);
}
else
{
     secondNibble-=10U;
     secondHexChar=(char)('A'+secondNibble);
}

printf("%c%c\n", firstHexChar, secondHexChar);
