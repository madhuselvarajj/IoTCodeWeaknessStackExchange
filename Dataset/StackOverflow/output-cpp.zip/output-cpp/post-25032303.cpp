void Motor::runMotor()
{
       if(_firstRun == true)
       {
           _startTime = millis();
           _firstRun = false;
       }

       ...your code...

       _currentTime = millis() - _startTime;

       ...your code...
}
