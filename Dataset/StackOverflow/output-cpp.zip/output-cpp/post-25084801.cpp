#include <stlport.h>
#include <Eigen30.h>

using Eigen::MatrixXd;

MatrixXd m(2, 2);

void setup()
{
     Serial.begin(115200);

  /* add setup code here */
     m(0, 0) = 3;
     m(1, 0) = 2.5;
     m(0, 1) = -1;
     m(1, 1) = m(1, 0) + m(0, 1);

}

void loop()
{

  /* add main program code here */
     Serial.println(m(1,1));
     delay(2000);
}
