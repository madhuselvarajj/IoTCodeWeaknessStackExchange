void create_msg_(const char* name, uint8_t buff, size_t size)
{
  // populate buff with the message
}

void send_msg(const char* name)
{
  size_t size = strlen(name) + 2;
  uint8_t buff[size]; // VLA extension, not std C++
  create_msg_(name, buff, size);
  BTLEserial.write(buff, size);
}
