int one[] = {1,2};
int four[] = {1,2,3,4};
int* pins = nullptr; // use NULL if your compiler doesn't support C++11.
size_t pinslen = 0;

switch (num) {
case 1:
    pins = one;
    pinslen = sizeof one;
    break;
case 4:
    pins = four;
    pinslen = sizeof four;
    break;
}
