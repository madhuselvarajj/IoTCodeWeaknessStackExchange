const int c_one[] = {1, 2};
const int c_four[] = {1, 2, 3, 4};
std::vector<int> one(c_one, c_one + 2);
std::vector<int> four(c_four, c_four + 4);
std::vector<int>* pins = 0;// or NULL
switch (num) {
    case 1: pins = &one; break;
    case 4: pins = &four; break;
}
