const int one[] = {1, 2};
const int four[] = {1, 2, 3, 4};
std::vector<int> pins;
switch (num) {
    case 1: pins.assign(one, one + 2); break;
    case 4: pins.assign(four, four + 4); break;
}
