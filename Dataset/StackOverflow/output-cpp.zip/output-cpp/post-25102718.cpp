std::vector<int> one = {1, 2};
std::vector<int> four = {1, 2, 3, 4};
std::vector<int>* pins = nullptr;
switch (num) {
    case 1: pins = &one; break;
    case 4: pins = &four; break;
}
