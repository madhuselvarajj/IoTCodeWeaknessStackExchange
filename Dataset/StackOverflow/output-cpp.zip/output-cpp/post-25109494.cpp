char *bigPacket = malloc(25);
bigPacket[0] = bigpacket[1] = 72;

strcpy( bigpacket+2, "Hello, World");

print( bigPacket );
