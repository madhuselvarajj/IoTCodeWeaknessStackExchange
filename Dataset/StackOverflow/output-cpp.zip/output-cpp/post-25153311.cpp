//Inside Header
class runningAverage{
    private:
        byte n;
        float *array; // <= correct type
    public:
        runningAverage(byte);
        ~runningAverage(); // <= you'll need a destructor to cleanup
    private:
        runningAverage(const runningAverage &);
        runningAverage & operator = (const runningAverage &);
};

//Inside .cpp
runningAverage::runningAverage(byte a){
    array = new float[n]; // <= allocate array
    n = a;
    for (byte i = 0; i<n; i++) {
        array[i] = 0;
    }
}

// clean up
runningAverage::~runningAverage(){
    delete[] array;
}
