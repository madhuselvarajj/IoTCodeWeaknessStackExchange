template < int SIZE >
class runningAverage
{
    float array [ SIZE ];
};

runningAverage < 10 > ra;
