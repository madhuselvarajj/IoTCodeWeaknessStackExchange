// in the main loop
if(iteratorVariable >= 5){
  iteratorVariable = 0;
  // take your windreading and implement logic here
} else {
  iteratorVariable++;
}
