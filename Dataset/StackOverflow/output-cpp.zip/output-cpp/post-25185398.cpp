private: 
    uint8_t array1[WIDTH][HEIGHT];
    uint8_t array2[WIDTH][HEIGHT];
    uint8_t (*nextState)[WIDTH][HEIGHT];
    uint8_t (*prevState)[WIDTH][HEIGHT];
