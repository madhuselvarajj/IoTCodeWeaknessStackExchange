int lastRead = -1; // init to value outside of possible range

void setup()
{
  Serial.begin(9600);
}

void loop() {

  // get current value
  int currentRead = analogRead(0);

  //compare and only print if !=
  if (currentRead != lastRead){
   lastRead = currentRead; // store
   Serial.println(lastRead);
  }
}
