int g_lastValue = 0;

void loop() {

  int nowValue = analogRead(A0);

  if (nowValue != g_lastValue) {
    Serial.println(nowValue);
    g_lastValue = nowValue;
  }
  ...
}
