#include <iostream>

// Example Foo class (instantiated with foo[0-8]).
class Foo
{
    public:

        Foo(int x)
        {
            bar = x;
        }

        void FooMethod()
        {
            std::cout << bar << std::endl;
        }

    private:

        int bar;
};

int main(int argc, char* argv[])
{
    // Instantiate foo[0-8].
    Foo foo0 = Foo(0);
    Foo foo1 = Foo(1);
    Foo foo2 = Foo(2);
    Foo foo3 = Foo(3);
    Foo foo4 = Foo(4);
    Foo foo5 = Foo(5);
    Foo foo6 = Foo(6);
    Foo foo7 = Foo(7);
    Foo foo8 = Foo(8);

    // Declare Foo group arrays of, type Foo*.
    Foo* group0[] = { &foo0, &foo1, &foo2 };
    Foo* group1[] = { &foo3, &foo4, &foo5 };
    Foo* group2[] = { &foo6, &foo7, &foo8 };

    // Declare Foo* group array to hold Foo groups, of type Foo**.
    Foo** groups[] = { group0, group1, group2 };

    // Iterate through Foo groups and over each individual Foo object.
    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            // Do something with Foo (i.e. invoke its member method).
            groups[i][j]->FooMethod();
        }
    }
}
