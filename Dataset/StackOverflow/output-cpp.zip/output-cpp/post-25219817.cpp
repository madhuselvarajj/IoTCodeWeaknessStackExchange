Foo** list[] = {group0, group1, group2};
Foo** pGroup;

for(int i = 0; 3 < i; ++i)
{
  pGroup = list[i]; // Ptr to one of the groups
}
