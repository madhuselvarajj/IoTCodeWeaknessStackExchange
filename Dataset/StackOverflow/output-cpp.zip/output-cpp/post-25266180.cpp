#include <stdio.h>

int
main() {
    printf("%d\n", (int) sizeof("FROM: <" ">\r\n"
                                "TO: <" ">\r\n"
                                "SUBJECT: " "\r\n"));
}
