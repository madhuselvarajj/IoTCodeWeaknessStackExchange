#include <iostream>
#include <algorithm>
#include <string>
#include <list>
using namespace std;

int main() {
    list<string> l = {"aab", "aac", "abb", "123", "aaw", "wws"};
    list<string> whiteList = {"aa", "ab"};
    auto end = remove_if(l.begin(), l.end(), [&whiteList](string item)
        {
            for(auto &s : whiteList)
            {
                auto res = mismatch(s.begin(), s.end(), item.begin());
                if (res.first == s.end()){
                    return false; //found allowed prefix
                }
            }
            return true; 
        });
    for (auto it = l.begin(); it != end; ++it){
        cout<< *it << endl;
    }
    return 0;
}
