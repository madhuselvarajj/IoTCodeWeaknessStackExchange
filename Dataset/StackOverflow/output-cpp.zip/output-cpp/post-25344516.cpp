struct led
{
    int fade;
};

led led1;

// put this in a header file Scenario.h
class Scenario
{

public:
    int byte; // byte of the eeprom
    static int* link[6]; // array of pointers (DECLARATION)

    Scenario(int byteI) // constructor of the class
    {

        byte = byteI;
        link[0] = &led1.fade;
    }
};

// put this in a source file Scenario.cpp
int* Scenario::link[6]; // (DEFINITION)

// make sure you link Scenario.o along with your main object file
int main()
{
    Scenario s(4);
}
