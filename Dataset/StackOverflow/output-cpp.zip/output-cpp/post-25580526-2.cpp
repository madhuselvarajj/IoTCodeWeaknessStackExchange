#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* getLat();

int main(int argc, char **argv)
{
    char test[20] = {0};
    char *heapBuffer = getLat();
    strncpy(test,heapBuffer,10);
    fprintf(stdout, "%s\n", test);
    //delete[] heapBuffer; // C++ deallocation; prevents memory leak.
    free(heapBuffer);    // C deallocation; prevents memory leak.

    return 1;
}


char* getLat(){
  //char *buffer = new char[10]; // C++ allocation
  char *buffer = (char*)malloc(10); // C allocation - to be a C purist.

  memset(buffer,0,sizeof(buffer));
  strcpy(buffer, "Testycole");
  // dtostrf(flat, 3, 6, buffer);
  // Serial.write(buffer);
  // Serial.print(" ");
  return buffer;
}
