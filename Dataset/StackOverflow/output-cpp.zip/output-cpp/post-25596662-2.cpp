std::string packetBufferString(packetBuffer);

//

packetBufferString  = packetBuffer;
