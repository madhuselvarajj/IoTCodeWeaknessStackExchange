std::string packetBufferString(packetBuffer);

//

packetBufferString.assign(packetBuffer);
