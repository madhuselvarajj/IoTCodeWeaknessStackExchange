if(ixHead >= 0) {
  do something with pool[ixHead]
  ixHead += 1;
  ixHead = ixHead % sizePool;
  // detect if head = tail and mark q empty
}
