struct OMessage {
  int scoutId;
  char message[50];
  int messageKey;
};

const int sizePool = 10;
OMessage pool[10];
int ixNext = 0;
int ixHead = -1;
