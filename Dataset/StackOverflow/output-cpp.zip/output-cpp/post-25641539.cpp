std::pair<byte*, std::size_t> tests[] = {
    {A, sizeof(A)},
    {B, sizeof(B)},
    {gamma, sizeof(gamma)}
};
