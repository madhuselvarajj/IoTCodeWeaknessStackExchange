int handle_byte(int byteGPS) {
buf[counter1] = byteGPS;
//Serial.print((char)byteGPS);
counter1++;
if (counter1 == 300) {
  return 0;
}

if (byteGPS == ',') {
    counter2++;
    offsets[counter2] = counter1;
    if (counter2 == 13) {
      return 0;
    }   }   if (byteGPS == '*') {
    offsets[12] = counter1;   }

  // Check if we got a <LF>, which indicates the end of line   if (byteGPS == 10) {

    // Check that we got 12 pieces, and that the first piece is 6 characters
    if (counter2 != 12 || (get_size(0) != 6)) {
      return 0;
    }

    // Check that we received $GPRMC
    // CMD buffer contains $GPRMC
    for (int j=0; j<6; j++) {

      if (buf[j] != cmd[j]) {
        return 0;
      }
    }

    // Check that time is well formed
    if (get_size(1) != 10) {

      return 0;
    }

    // Check that date is well formed
    if (get_size(9) != 6) {
      return 0;
    }

    SeeedOled.setTextXY(7,0);
    for (int j=0; j<6; j++) {
      SeeedOled.putChar(*(buf+offsets[1]+j));
    }
    SeeedOled.setTextXY(7,7);

    for (int j=0; j<6; j++) {
      SeeedOled.putChar(*(buf+offsets[9]+j));
    }

    // TODO: compute and validate checksum

    // TODO: handle timezone offset

      return 0;   }   
return 1; }
