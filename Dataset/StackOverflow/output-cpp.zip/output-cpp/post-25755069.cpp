   if (Serial.peek()==13) {      // check if CR (without reading)
       Serial.read();            // read and ignore 
       if (Serial.peek()==10)    // then check if LF (without reading)
          Serial.read(); 
       } 
