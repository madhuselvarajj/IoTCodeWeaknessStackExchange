AT DISPLAY BUFFER:
1 
1 
1 
1 
1 
1 
1 
1 
1 
[...] // It prints 1 until now 
1

END DISPLAY BUFFER
