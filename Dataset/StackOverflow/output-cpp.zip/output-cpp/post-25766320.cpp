#include <SoftwareSerial.h>

int baud_rate = 9600;
int pin_gsm = 3;
int pin_gps = 4;
int pin_power = 5;
//int pin_dtr = 6;
boolean debug = true;
boolean raedy_to_go = false;

// Reading String
#define BUFFERSIZE 200
char buffer[BUFFERSIZE];
char inChar;
int index;

void setup()
{
  Serial.begin(baud_rate);
  delay(5000);                         // Wait for 5sec after begin

  if(debug)
  {
    Serial.println(F("\n****************************"));
    Serial.println(F("STARTING SYSTEM Read AT stream"));
    Serial.println(F("******************************"));
  }
  pinMode(pin_gsm,OUTPUT);            // Set the pins
  pinMode(pin_gps,OUTPUT);
  pinMode(pin_power,OUTPUT);

  powerUpSim908:
  if(powerUpSim908())
  {
    delay(1000);

    if(gps_power()){

      gsm_enable();
      raedy_to_go = true;

      if(debug)
      {
        Serial.println(F("\n****************************"));
        Serial.println(F("READY TO GO\n"));
        Serial.println(F("****************************\n"));
      }  
    }
    else
    {
      raedy_to_go = false;
      if(debug)
      {
       Serial.println(F("\nNOT READY TO GO.\nGPS could not be power\nRestart the module\nor/and check the battery level.\n"));
      }
      goto powerUpSim908;
    }
  }
  else
  {
    raedy_to_go = false;
    if(debug)
    {
      Serial.println(F("\nNOT READY TO GO.\nCheck the battery level.\n"));
    } 
  };
}

void loop()
{
  /*
   if (Serial.available())
   {
     Serial.print("Character received: ");
     Serial.write(Serial.read());
     Serial.println("");
   }
   */
    if(raedy_to_go)
    {

       read_AT_string("AT",5000);
       delay(10000);

    }  

}

char read_AT_string(char* command, int timeout)
{
  unsigned long previous;
  previous = millis();


  Serial.println(F("\nDISPLAY BUFFER:"));
  index=0;

  Serial.println(command);
  do
  {
    if(Serial.available() > 0) // Don't read unless
    // there you know there is data
    {
      Serial.println("1");
      if (Serial.peek() == 13)           // check if CR (without reading)
      {      
        Serial.println("13");
        if(Serial.available() > 0)
        {
        Serial.read();                // read and ignore 
        if (Serial.peek()==10)        // then check if LF (without reading)
         {
           Serial.println("10");
           if(index < Serial.readBytesUntil(13, buffer, BUFFERSIZE-1))   // One less than the size of the buffer array
            {
              Serial.println("b");
              inChar = Serial.read();  // Read a character
              buffer[index] = inChar;  // Store it
              index++;                 // Increment where to write next
              buffer[index] = '\0';    // Null terminate the string
            }
          }
         }
      }
    }
  }while(((millis() - previous) < timeout));

  Serial.println(buffer);
  buffer[0]='\0';
  Serial.println(F("END DISPLAY BUFFER"));
}

/* FUNCTION */

boolean powerUpSim908(void)
{
  if(debug)
  {
    Serial.println(F("Powering up SIM908"));  
  }
  boolean turnedON = false;
  //uint8_t answer=0;
  int cont;

  for (cont=0; cont<3; cont++)
  {
    digitalWrite(pin_power,HIGH);
    delay(1500);
    digitalWrite(pin_power,LOW);

    Serial.println(F("Checking if the module is up"));
    if(sendATcommand("AT", "OK", 5000))
    {
    cont = 4; // Leave the loop
    turnedON = true;
    }
    else
    {
      turnedON = false;
      if(debug)
      {
    Serial.println(F("\nTrying agin to turn on SIM908"));  
      }
    };
  }

  if(turnedON)
  {
    if(debug)
    {
      Serial.println(F("Module is tunrned up\n"));
    }
  }
  else
  {
      if(debug)
      {
    Serial.println(F("Module is NOT tunrned ON\n"));  
      }
   }    
    return turnedON;
}

boolean sendATcommand(char* ATcommand, char* expected_answer, unsigned int timeout)
{
    uint8_t x=0;
    bool answer=false;
    //åchar response[100];
    //buffer[0]='\0';
    unsigned long previous;

    //memset(response, '\0', 100);    // Initialice the string
    //Serial.println(response);

    delay(100);

    while( Serial.available() > 0) Serial.read();    // Clean the input buffer

    if (ATcommand[0] != '\0')
    { 
        Serial.println(ATcommand);    // Send the AT command   
    }

    x = 0;
    previous = millis();

    index=0;
    do
    {
      if(Serial.available() > 0) 
      // there you know there is data
      {
        if(index < BUFFERSIZE-1) // One less than the size of the array // Same as buffer size
        {
          inChar = Serial.read(); // Read a character
          buffer[index] = inChar; // Store it
          index++; // Increment where to write next
          //Serial.println(index);
          buffer[index] = '\0'; // Null terminate the string
        }
      }
    }while(((millis() - previous) < timeout));


    if(strstr(buffer,"NORMAL POWER DOWN") != NULL)
    {
       answer = false;
    }
    else if (strstr(buffer, expected_answer) != NULL)    // check if the desired answer (OK) is in the response of the module
    {

      /*
      Serial.println(F("### BUFFER")); 
      Serial.println(buffer);
      Serial.println(F("### END BUFFER"));
      */
       answer = true;
    }
    else
    {
      answer = false;
    }   

    if(debug)
        {
          if(answer)
          {
            //Serial.println(F("Expected answer : OK!\n"));
          }
          else
          {
            //Serial.println(F("Expected answer : KO!\n"));
          };
  }     
  return answer;
}


void gps_enable(void)
{
  if(debug)
  {
    Serial.println(F("\nEnabling GPS ..."));
  }
  digitalWrite(pin_gps,LOW);                //Enable GPS mode
  digitalWrite(pin_gsm,HIGH);                //Disable GSM mode
  delay(2000);
}



void gsm_enable(void)
{
  if(debug)
  {
    Serial.println(F("\nEnabling GSM ..."));
  }
  digitalWrite(pin_gsm,LOW);                //Enable GSM mode
  digitalWrite(pin_gps,HIGH);               //Disable GPS mode
  delay(2000);
}


/* UTILISTIES */


/* GPS */

boolean gps_power(void)                            //turn on GPS power supply
{
  /*
  Serial.println("AT");  
  delay(2000);
  */

  boolean gpspwr = false;
  boolean gpsrst = false;


  if(sendATcommand("AT+CGPSPWR=1","OK",2000))
  {
    gpspwr = true;
     if(debug)
    {
      Serial.println("turn on GPS power supply => OK");
    }
  }
  else
  {
    if(debug)
    {
      Serial.println("turn on GPS power supply => KO");
    }
  }; 
  //delay(1000);

  if(sendATcommand("AT+CGPSRST=1","OK",2000))
  {
    gpsrst = true;
    if(debug)
    {
      Serial.println("reset GPS in autonomy mode => OK");
    }
  }
  else
  {
    if(debug)
    {
      Serial.println("reset GPS in autonomy mode => KO");
    }
  };   //reset GPS in autonomy mode

  delay(1000);

  if(gpspwr && gpsrst)
  {
    return true;
  }else
  {
    return false;
  }
}
