char* gps_read (void) {

  if(strstr(read_AT_string("AT+CGPSINF=2",3000),"OK") != NULL)
  {
    Serial.println(F("------- Show buffer------"));
    Serial.println(buffer);
    Serial.println(F("-------------------------\n"));

    char fix[BUFFERSIZE];

    int z = 0;
    int y = 0;
    int w = 0;

    for(y=0; y < BUFFERSIZE; y++)
    {
      if(buffer[y]==',') z++;

      if(z > 0){
        if(buffer[y] == '\n'){
          fix[w-1]='\0';
          break;
        }

        fix[w] = buffer[y+1];
        w++;
      }

    }
    Serial.println(F("------- Show Fix------"));
    Serial.println(fix);
    Serial.println(F("----------------------"));

    return fix;
  }
  else
  {
    return "Error : no fix";
  }
}
